import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { 
  Plane, 
  Users, 
  Calendar, 
  Clock, 
  MapPin, 
  Edit3, 
  UserPlus, 
  UserMinus, 
  ArrowLeft,
  Save,
  X,
  CheckCircle,
  AlertCircle,
  User
} from 'lucide-react';
import axios from 'axios';
import moment from 'moment';
import { toast } from 'react-toastify';
import LoadingSpinner from '../components/LoadingSpinner';
import UserAllocationModal from '../components/UserAllocationModal';

const FlightDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [editingBriefing, setEditingBriefing] = useState(false);
  const [briefingForm, setBriefingForm] = useState({});
  const [allocationModal, setAllocationModal] = useState({ 
    isOpen: false, 
    roleIndex: null, 
    roleName: '' 
  });

  const { data: flight, isLoading, error } = useQuery(
    ['flight', id],
    () => axios.get(`/api/flights/${id}`).then(res => res.data),
    {
      refetchOnWindowFocus: false,
      refetchInterval: 30000
    }
  );

  const { data: authData } = useQuery('auth', 
    () => axios.get('/api/auth/me').then(res => res.data),
    {
      retry: false,
      refetchOnWindowFocus: false
    }
  );

  const allocateMutation = useMutation(
    ({ roleIndex, userId }) => 
      axios.post(`/api/flights/${id}/allocate-user`, { roleIndex, userId }),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(['flight', id]);
        toast.success('User allocated successfully');
      },
      onError: (error) => {
        toast.error(error.response?.data?.message || 'Failed to allocate user');
      }
    }
  );

    const unallocateMutation = useMutation(
    ({ roleIndex, userId }) =>
      axios.delete(`/api/flights/${id}/unallocate-user`, { data: { roleIndex, userId } }),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(['flight', id]);
        toast.success('User unallocated successfully');
      },
      onError: (error) => {
        toast.error(error.response?.data?.message || 'Failed to unallocate user');
      }
    }
  );

  const selfAllocateMutation = useMutation(
    (roleIndex) => 
      axios.post(`/api/flights/${id}/allocate`, { roleIndex }),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(['flight', id]);
        toast.success('Successfully allocated to flight');
      },
      onError: (error) => {
        toast.error(error.response?.data?.message || 'Failed to allocate to flight');
      }
    }
  );

    const selfUnallocateMutation = useMutation(
    () =>
      axios.delete(`/api/flights/${id}/unallocate`),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(['flight', id]);
        toast.success('Successfully unallocated from flight');
      },
      onError: (error) => {
        toast.error(error.response?.data?.message || 'Failed to unallocate from flight');
      }
    }
  );

  const updateFlightMutation = useMutation(
    (data) => 
      axios.put(`/api/flights/${id}`, data),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(['flight', id]);
        setEditingBriefing(false);
        toast.success('Flight updated successfully');
      },
      onError: (error) => {
        toast.error(error.response?.data?.message || 'Failed to update flight');
      }
    }
  );

  const updateStatusMutation = useMutation(
    (status) => 
      axios.put(`/api/flights/${id}/status`, { status }),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(['flight', id]);
        toast.success('Flight status updated');
      },
      onError: (error) => {
        toast.error(error.response?.data?.message || 'Failed to update status');
      }
    }
  );

  if (isLoading) return <LoadingSpinner />;
  if (error) return <div className="alert alert-danger">Flight not found</div>;
  if (!flight) return <div className="alert alert-danger">Flight not found</div>;

  const canEdit = authData?.user && (
    flight.dispatcher._id === authData.user.userId || 
    (authData.user.groupRank && authData.user.groupRank.rankId >= 247)
  );

  const canChangeDispatcher = authData?.user && 
    authData.user.groupRank && authData.user.groupRank.rankId >= 247;

  const isDispatcher = authData?.user && flight.dispatcher._id === authData.user.userId;
  const canEditStatus = (isDispatcher || (authData?.user?.groupRank && authData.user.groupRank.rankId >= 247)) && flight.status !== 'CONCLUDED';
  const isLocked = flight.status === 'CONCLUDED' && (!authData?.user?.groupRank || authData.user.groupRank.rankId < 247);

  const getStatusBadgeClass = (status) => {
    const classes = {
      'SCHEDULED': 'badge-secondary',
      'AVAILABLE': 'badge-success',
      'BRIEFING': 'badge-warning',
      'IN PROGRESS': 'badge-info',
      'CONCLUDED': 'badge-primary',
      'CANCELLED': 'badge-danger',
      'LOGGED': 'badge-success'
    };
    return classes[status] || 'badge-secondary';
  };

  const handleEditBriefing = () => {
    setBriefingForm({
      flightCode: flight.flightCode,
      route: flight.route,
      aircraft: flight.aircraft,
      gate: flight.gate || '',
      scheduledDate: moment(flight.scheduledDate).format('YYYY-MM-DDTHH:mm'),
      times: {
        staffJoining: moment(flight.times.staffJoining).format('YYYY-MM-DDTHH:mm'),
        passengerJoining: moment(flight.times.passengerJoining).format('YYYY-MM-DDTHH:mm'),
        boarding: moment(flight.times.boarding).format('YYYY-MM-DDTHH:mm')
      },
      serviceCategory: flight.serviceCategory || '',
      notes: flight.notes || ''
    });
    setEditingBriefing(true);
  };

  const handleSaveBriefing = () => {
    updateFlightMutation.mutate({
      ...briefingForm,
      scheduledDate: new Date(briefingForm.scheduledDate),
      times: {
        staffJoining: new Date(briefingForm.times.staffJoining),
        passengerJoining: new Date(briefingForm.times.passengerJoining),
        boarding: new Date(briefingForm.times.boarding)
      }
    });
  };

  const getUserRoleInFlight = (userId) => {
    for (let i = 0; i < flight.roles.length; i++) {
      const assignment = flight.roles[i].assigned.find(a => a.user._id === userId);
      if (assignment) return { roleIndex: i, role: flight.roles[i] };
    }
    return null;
  };

  const userRole = authData?.user ? getUserRoleInFlight(authData.user.userId) : null;

  const openAllocationModal = (roleIndex, roleName) => {
    setAllocationModal({ isOpen: true, roleIndex, roleName });
  };

  const closeAllocationModal = () => {
    setAllocationModal({ isOpen: false, roleIndex: null, roleName: '' });
  };

  return (
    <div className="container-fluid">
      <div className="mb-4">
        <div className="d-flex align-items-center gap-3 mb-3">
          <button
            className="btn btn-ghost d-flex align-items-center gap-2"
            onClick={() => navigate('/flights')}
          >
            <ArrowLeft size={18} />
            Back to Flights
          </button>
          <div className="d-flex align-items-center gap-2">
            <Plane size={24} className="text-primary" />
            <h1 className="h3 mb-0">{flight.flightCode}</h1>
            <span className={`badge ${getStatusBadgeClass(flight.status)}`}>
              {flight.status}
            </span>
          </div>
        </div>

        {canEditStatus && (
          <div className="mb-3">
            <label className="form-label">Flight Status</label>
            <select
              className="form-select"
              value={flight.status}
              onChange={(e) => updateStatusMutation.mutate(e.target.value)}
              disabled={updateStatusMutation.isLoading}
              style={{ maxWidth: '200px' }}
            >
              <option value="SCHEDULED">SCHEDULED</option>
              <option value="AVAILABLE">AVAILABLE</option>
              <option value="BRIEFING">BRIEFING</option>
              <option value="IN PROGRESS">IN PROGRESS</option>
              <option value="CONCLUDED">CONCLUDED</option>
              <option value="CANCELLED">CANCELLED</option>
            </select>
          </div>
        )}
      </div>

      <div className="row">
        <div className="col-lg-8">
          <div className="card mb-4">
            <div className="card-header d-flex justify-content-between align-items-center">
              <h5 className="mb-0 d-flex align-items-center gap-2">
                <Users size={20} />
                Flight Allocation Panel
              </h5>
              {canEdit && !isLocked && (
                <small className="text-muted">
                  Flight Dispatcher privileges
                </small>
              )}
            </div>
            <div className="card-body">
              {flight.roles.map((role, roleIndex) => (
                <div key={roleIndex} className="mb-4">
                  <div className="d-flex justify-content-between align-items-center mb-2">
                    <h6 className="mb-0">
                      {role.name} ({role.assigned.length}/{role.capacity})
                    </h6>
                    {canEdit && !isLocked && role.assigned.length < role.capacity && (
                      <button
                        className="btn btn-primary btn-sm d-flex align-items-center gap-1"
                        onClick={() => openAllocationModal(roleIndex, role.name)}
                      >
                        <UserPlus size={14} />
                        ALLOCATE
                      </button>
                    )}
                  </div>
                  
                  <div className="allocated-users-grid">
                    {role.assigned.map((assignment, assignmentIndex) => (
                      <div key={assignmentIndex} className="allocated-user-card">
                        <div className="allocated-user-avatar">
                          {assignment.user.robloxAvatarUrl ? (
                            <img
                              src={assignment.user.robloxAvatarUrl}
                              alt="Avatar"
                              className="avatar-img"
                            />
                          ) : (
                            <div className="avatar-placeholder">
                              <User size={16} />
                            </div>
                          )}
                        </div>
                        <div className="allocated-user-info">
                          <Link 
                            to={`/u/${assignment.username}`}
                            className="allocated-user-name"
                          >
                            @{assignment.username}
                          </Link>
                          <div className="allocated-user-meta">
                            {moment(assignment.assignedAt).format('MMM DD, HH:mm')}
                          </div>
                        </div>
                        {canEdit && !isLocked && (
                          <button
                            className="allocated-user-remove"
                            onClick={() => unallocateMutation.mutate({ roleIndex, userId: assignment.user._id })}
                            disabled={unallocateMutation.isLoading}
                            title="Unallocate user"
                          >
                            <X size={12} />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>

                  {flight.status === 'AVAILABLE' && !userRole && role.assigned.length < role.capacity && (
                    <button
                      className="btn btn-outline btn-sm d-flex align-items-center gap-1"
                      onClick={() => selfAllocateMutation.mutate(roleIndex)}
                      disabled={selfAllocateMutation.isLoading}
                    >
                      <UserPlus size={14} />
                      Self Allocate
                    </button>
                  )}
                </div>
              ))}

              {userRole && ['AVAILABLE', 'BRIEFING'].includes(flight.status) && (
                <div className="alert alert-info d-flex justify-content-between align-items-center">
                  <span>You are allocated to: <strong>{userRole.role.name}</strong></span>
                  <button
                    className="btn btn-outline btn-sm d-flex align-items-center gap-1"
                                            onClick={() => selfUnallocateMutation.mutate()}
                        disabled={selfUnallocateMutation.isLoading}
                  >
                    <UserMinus size={14} />
                    Unallocate
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="card">
            <div className="card-header d-flex justify-content-between align-items-center">
              <h5 className="mb-0 d-flex align-items-center gap-2">
                <Calendar size={20} />
                Activity Log
              </h5>
            </div>
            <div className="card-body">
              {flight.logs.length > 0 ? (
                <div className="activity-log-progression">
                  {flight.logs.slice().reverse().map((log, index) => (
                    <div key={index} className="activity-log-entry">
                      <div className="activity-log-marker">
                        <div className="activity-log-dot">
                          <CheckCircle size={12} />
                        </div>
                        {index < flight.logs.length - 1 && <div className="activity-log-line"></div>}
                      </div>
                      <div className="activity-log-content">
                        <div className="activity-log-header">
                          <div className="activity-log-title">
                            {log.action.includes('Status changed') ? (
                              <span>
                                Status changed from{' '}
                                {(() => {
                                  const fromStatus = log.details.split(' from ')[1]?.split(' to ')[0];
                                  return (
                                    <span className={`badge ${getStatusBadgeClass(fromStatus)} badge-sm`}>
                                      {fromStatus}
                                    </span>
                                  );
                                })()}
                                {' '}to{' '}
                                {(() => {
                                  const toStatus = log.details.split(' to ')[1];
                                  return (
                                    <span className={`badge ${getStatusBadgeClass(toStatus)} badge-sm`}>
                                      {toStatus}
                                    </span>
                                  );
                                })()}
                              </span>
                            ) : (
                              log.action
                            )}
                          </div>
                          <div className="activity-log-date">
                            {moment(log.timestamp).format('MMM DD, HH:mm')}
                          </div>
                        </div>
                        {log.details && !log.action.includes('Status changed') && (
                          <div className="activity-log-details">
                            <div className="activity-log-description">
                              {log.details.includes('@') ? (
                                log.details.split(/(@\w+)/).map((part, index) => 
                                  part.startsWith('@') ? (
                                    <span 
                                      key={index}
                                      className="promoter-link" 
                                      onClick={() => navigate(`/u/${part.substring(1)}`)}
                                    >
                                      {part}
                                    </span>
                                  ) : part
                                )
                              ) : (
                                log.details
                              )}
                            </div>
                          </div>
                        )}
                        <div className="activity-log-performer">
                          by{' '}
                          <span 
                            className="promoter-link" 
                            onClick={() => navigate(`/u/${log.performedByUsername}`)}
                          >
                            @{log.performedByUsername}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center text-muted py-4">
                  <AlertCircle size={32} className="opacity-50 mb-2" />
                  <div>No activity logged yet</div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="col-lg-4">
          <div className="card">
            <div className="card-header d-flex justify-content-between align-items-center">
              <h5 className="mb-0">Flight Briefing</h5>
              {canEdit && !isLocked && !editingBriefing && (
                <button
                  className="btn btn-ghost btn-sm d-flex align-items-center gap-1"
                  onClick={handleEditBriefing}
                >
                  <Edit3 size={14} />
                  Edit
                </button>
              )}
            </div>
            <div className="card-body">
              {editingBriefing ? (
                <div className="space-y-3">
                  <div className="mb-3">
                    <label className="form-label">Flight Code</label>
                    <input
                      type="text"
                      className="form-control"
                      value={briefingForm.flightCode}
                      onChange={(e) => setBriefingForm({...briefingForm, flightCode: e.target.value})}
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Route</label>
                    <div className="row mx-0">
                      <div className="col-6 px-2">
                        <label className="form-label small text-muted">From</label>
                        <input
                          type="text"
                          className="form-control"
                          value={briefingForm.route?.departure || ''}
                          onChange={(e) => setBriefingForm({
                            ...briefingForm, 
                            route: {...briefingForm.route, departure: e.target.value}
                          })}
                          placeholder="Departure"
                        />
                      </div>
                      <div className="col-6 px-2">
                        <label className="form-label small text-muted">To</label>
                        <input
                          type="text"
                          className="form-control"
                          value={briefingForm.route?.arrival || ''}
                          onChange={(e) => setBriefingForm({
                            ...briefingForm, 
                            route: {...briefingForm.route, arrival: e.target.value}
                          })}
                          placeholder="Arrival"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Aircraft</label>
                    <input
                      type="text"
                      className="form-control"
                      value={briefingForm.aircraft}
                      onChange={(e) => setBriefingForm({...briefingForm, aircraft: e.target.value})}
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Gate</label>
                    <input
                      type="text"
                      className="form-control"
                      value={briefingForm.gate}
                      onChange={(e) => setBriefingForm({...briefingForm, gate: e.target.value})}
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Scheduled Date</label>
                    <input
                      type="datetime-local"
                      className="form-control"
                      value={briefingForm.scheduledDate}
                      onChange={(e) => setBriefingForm({...briefingForm, scheduledDate: e.target.value})}
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Staff Joining Time</label>
                    <input
                      type="datetime-local"
                      className="form-control"
                      value={briefingForm.times?.staffJoining}
                      onChange={(e) => setBriefingForm({
                        ...briefingForm, 
                        times: {...briefingForm.times, staffJoining: e.target.value}
                      })}
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Passenger Joining Time</label>
                    <input
                      type="datetime-local"
                      className="form-control"
                      value={briefingForm.times?.passengerJoining}
                      onChange={(e) => setBriefingForm({
                        ...briefingForm, 
                        times: {...briefingForm.times, passengerJoining: e.target.value}
                      })}
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Boarding Time</label>
                    <input
                      type="datetime-local"
                      className="form-control"
                      value={briefingForm.times?.boarding}
                      onChange={(e) => setBriefingForm({
                        ...briefingForm, 
                        times: {...briefingForm.times, boarding: e.target.value}
                      })}
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Service Category</label>
                    <input
                      type="text"
                      className="form-control"
                      value={briefingForm.serviceCategory}
                      onChange={(e) => setBriefingForm({...briefingForm, serviceCategory: e.target.value})}
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Notes</label>
                    <textarea
                      className="form-control"
                      rows="3"
                      value={briefingForm.notes}
                      onChange={(e) => setBriefingForm({...briefingForm, notes: e.target.value})}
                    />
                  </div>

                  <div className="d-flex gap-2">
                    <button
                      className="btn btn-primary d-flex align-items-center gap-1"
                      onClick={handleSaveBriefing}
                      disabled={updateFlightMutation.isLoading}
                    >
                      <Save size={14} />
                      Save
                    </button>
                    <button
                      className="btn btn-ghost d-flex align-items-center gap-1"
                      onClick={() => setEditingBriefing(false)}
                    >
                      <X size={14} />
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="d-flex align-items-center gap-2 mb-3">
                    <h4 className="mb-0 text-primary">{flight.flightCode}</h4>
                  </div>

                  <div className="d-flex align-items-center gap-2 mb-2">
                    <MapPin size={16} className="text-muted" />
                    <span className="fw-semibold">{flight.route.departure} → {flight.route.arrival}</span>
                  </div>

                  <div className="d-flex align-items-center gap-2 mb-2">
                    <Plane size={16} className="text-muted" />
                    <span>{flight.aircraft}</span>
                  </div>

                  {flight.gate && (
                    <div className="d-flex align-items-center gap-2 mb-2">
                      <MapPin size={16} className="text-muted" />
                      <span>Gate {flight.gate}</span>
                    </div>
                  )}

                  <div className="d-flex align-items-center gap-2 mb-2">
                    <Calendar size={16} className="text-muted" />
                    <span>{moment(flight.scheduledDate).format('MMMM DD, YYYY')}</span>
                  </div>

                  <div className="d-flex align-items-center gap-2 mb-2">
                    <Clock size={16} className="text-muted" />
                    <span>{moment(flight.scheduledDate).format('HH:mm')}</span>
                  </div>

                  <hr />

                  <div className="mb-3">
                    <h6>Times</h6>
                    <div className="small">
                      <div><strong>Staff Joining:</strong> {moment(flight.times.staffJoining).format('HH:mm')}</div>
                      <div><strong>Passenger Joining:</strong> {moment(flight.times.passengerJoining).format('HH:mm')}</div>
                      <div><strong>Boarding:</strong> {moment(flight.times.boarding).format('HH:mm')}</div>
                    </div>
                  </div>

                  {flight.serviceCategory && (
                    <div className="mb-3">
                      <h6>Service Category</h6>
                      <div>{flight.serviceCategory}</div>
                    </div>
                  )}

                  <div className="mb-3">
                    <h6>Flight Dispatcher</h6>
                    <div className="d-flex align-items-center gap-2">
                      <User size={16} />
                      <span 
                        className="promoter-link"
                        onClick={() => window.location.href = `/profile/lookup/${flight.dispatcher.robloxUsername}`}
                      >
                        @{flight.dispatcher.robloxUsername}
                      </span>
                    </div>
                  </div>

                  {flight.notes && (
                    <div className="mb-3">
                      <h6>Notes</h6>
                      <div className="text-muted">{flight.notes}</div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <UserAllocationModal
        isOpen={allocationModal.isOpen}
        onClose={closeAllocationModal}
        flightId={id}
        roleIndex={allocationModal.roleIndex}
        roleName={allocationModal.roleName}
        onSuccess={() => queryClient.invalidateQueries(['flight', id])}
      />
    </div>
  );
};

export default FlightDetails;