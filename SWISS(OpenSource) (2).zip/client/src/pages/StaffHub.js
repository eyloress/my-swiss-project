import React from 'react';
import { FileText, ExternalLink, Users, BookOpen, Shirt, Code } from 'lucide-react';

const StaffHub = () => {
  const documents = [
    {
      title: 'Personnel Handbook',
      description: 'Comprehensive guide to Swiss International Airlines policies and procedures',
      url: 'https://docs.google.com/document/d/1_3fgeGQinH2iTDmOL2Ac7oVcp31LrCspmuie4cGJp2k/edit?usp=sharing',
      icon: BookOpen,
      color: 'primary'
    },
    {
      title: 'Personnel Expectations',
      description: 'Standards and expectations for all Swiss International Airlines staff',
      url: 'https://docs.google.com/document/d/1-T2PfpNfq_h_5H1shGdrpWCMM779Bh-NaJ-VDCqJ-VM/edit?usp=sharing',
      icon: Users,
      color: 'info'
    },
    {
      title: 'Staff Database',
      description: 'Complete database of all Swiss International Airlines personnel',
      url: 'https://docs.google.com/spreadsheets/d/1Myx4IFh-zkIGs6Q3xzrilNSA201xxKv_YH3XqHYfN-Y/edit?usp=sharing',
      icon: FileText,
      color: 'success'
    },
    {
      title: 'Uniform Guide',
      description: 'Official uniform guidelines and dress code requirements',
      url: 'https://docs.google.com/document/d/1ASM5CDQUm1yQRI7Vp1TPxu9hYVoK0ru9Y_WIRVwZVak/edit?usp=sharing',
      icon: Shirt,
      color: 'warning'
    },
    {
      title: 'Insert Codes',
      description: 'Reference guide for system codes and operational procedures',
      url: 'https://docs.google.com/document/d/1yDozJ11PoL2iaYZ-HOl-6ZbkXJ7oDG4l0f9bFafihRA/edit?usp=sharing',
      icon: Code,
      color: 'primary'
    }
  ];

  const handleDocumentClick = (url) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="container-fluid">
      <div className="mb-4">
        <div className="d-flex justify-content-between align-items-center flex-wrap gap-2">
          <h1 className="h2 mb-0">
            <span className="d-none d-md-inline">Staff Hub</span>
            <span className="d-md-none">Staff Hub</span>
          </h1>
        </div>
      </div>

      <div className="row">
        <div className="col-12">
          <div className="card">
            <div className="card-header d-flex align-items-center gap-2">
              <FileText size={18} />
              Personnel Documents
            </div>
            <div className="card-body">
              <p className="text-muted mb-4">
                All relevant <strong>Personnel documents</strong> and files can be accessed here. 
                Please familiarise yourself with them to ensure you gain a key understanding of all 
                of our policies here at SWISS. You can find your <strong>relevant departmental handbooks</strong> 
                and documentation within your department bulletin.
              </p>
              
              <div className="row">
                {documents.map((doc, index) => (
                  <div key={index} className="col-lg-6 col-md-12 mb-4">
                    <div 
                      className="card staff-document-card h-100"
                      onClick={() => handleDocumentClick(doc.url)}
                    >
                      <div className="card-body">
                        <div className="d-flex align-items-start gap-3">
                          <div className={`staff-document-icon bg-${doc.color}`}>
                            <doc.icon size={24} />
                          </div>
                          <div className="flex-grow-1">
                            <h5 className="staff-document-title">
                              {doc.title}
                              <ExternalLink size={16} className="ms-2 text-muted" />
                            </h5>
                            <p className="staff-document-description text-muted mb-0">
                              {doc.description}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StaffHub; 