import React from 'react';
import { useQuery } from 'react-query';
import { useNavigate } from 'react-router-dom';
import { 
  Trophy, 
  Medal, 
  Award, 
  User, 
  DollarSign,
  TrendingUp,
  Crown,
  Star
} from 'lucide-react';
import axios from 'axios';
import moment from 'moment';
import LoadingSpinner from '../components/LoadingSpinner';

const Leaderboard = () => {
  const navigate = useNavigate();

  const { data: leaderboardData, isLoading, error } = useQuery(
    'leaderboard',
    () => axios.get('/api/users/leaderboard').then(res => res.data),
    {
      refetchOnWindowFocus: true,
      staleTime: 30000,
      cacheTime: 60000,
      refetchOnMount: 'always'
    }
  );

  const handleUsernameClick = (username) => {
    navigate(`/u/${username}`);
  };

  const getRankIcon = (position) => {
    if (position === 1) return <Crown size={20} className="text-warning" />;
    if (position === 2) return <Medal size={20} className="text-muted" />;
    if (position === 3) return <Award size={20} style={{ color: '#CD7F32' }} />;
    return <Star size={16} className="text-muted" />;
  };

  const getRankBadgeClass = (position) => {
    if (position === 1) return 'badge-warning';
    if (position === 2) return 'badge-secondary';
    if (position === 3) return 'badge-info';
    return 'badge-primary';
  };

  const sortedUsers = leaderboardData?.users || [];

  if (isLoading) return <LoadingSpinner />;
  if (error) return <div className="alert alert-danger">Failed to load leaderboard</div>;

  return (
    <div className="container-fluid">
      <div className="mb-4">
        <div className="d-flex justify-content-between align-items-center flex-wrap gap-2">
          <h1 className="h2 mb-0">
            <span className="d-flex align-items-center gap-2">
              <Trophy size={28} className="text-warning" />
              <span className="d-none d-md-inline">Term Pay Leaderboard</span>
              <span className="d-md-none">Leaderboard</span>
            </span>
          </h1>
        </div>
      </div>

      <div className="row justify-content-center">
        <div className="col-12 col-lg-10">
          <div className="card">
            <div className="card-header d-flex align-items-center gap-2">
              <TrendingUp size={18} />
              Current Term Rankings
              <span className="badge badge-primary ms-auto">
                {sortedUsers.length} Staff Members
              </span>
            </div>
            <div className="card-body p-0">
              {sortedUsers.length > 0 ? (
                <div className="table-responsive">
                  <table className="table table-hover mb-0">
                    <thead>
                      <tr>
                        <th style={{ width: '80px' }} className="text-center">Rank</th>
                        <th>Staff Member</th>
                        <th className="text-center">Role</th>
                        <th className="text-center">
                          <DollarSign size={16} className="me-1" />Term Pay
                        </th>
                        <th className="text-center d-none d-lg-table-cell">Last Active</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sortedUsers.map((user, index) => {
                        const position = index + 1;
                        const termPay = user.stats?.termPay || 0;
                        
                        return (
                          <tr key={user._id} className={position <= 3 ? 'table-warning' : ''}>
                            <td className="text-center">
                              <div className="d-flex align-items-center justify-content-center gap-2">
                                {getRankIcon(position)}
                                <span className={`badge ${getRankBadgeClass(position)}`}>
                                  #{position}
                                </span>
                              </div>
                            </td>
                            <td>
                              <div className="d-flex align-items-center gap-3">
                                {user.robloxAvatarUrl ? (
                                  <img
                                    src={user.robloxAvatarUrl}
                                    alt="Avatar"
                                    style={{ width: '40px', height: '40px' }}
                                  />
                                ) : (
                                  <div 
                                    className="d-flex align-items-center justify-content-center bg-light"
                                    style={{ width: '40px', height: '40px' }}
                                  >
                                    <User size={20} className="text-muted" />
                                  </div>
                                )}
                                <div>
                                  <div 
                                    className="fw-semibold promoter-link d-inline"
                                    onClick={() => handleUsernameClick(user.robloxUsername)}
                                    style={{ cursor: 'pointer' }}
                                  >
                                    @{user.robloxUsername}
                                  </div>
                                  {user.robloxDisplayName && user.robloxDisplayName !== user.robloxUsername && (
                                    <div className="text-muted small">
                                      ({user.robloxDisplayName})
                                    </div>
                                  )}
                                  <div className="text-muted small">
                                    {user.groupRank?.rankName || 'Unknown Rank'}
                                  </div>
                                </div>
                              </div>
                            </td>
                            <td className="text-center">
                              <span className="badge badge-secondary">
                                {user.role || 'Personnel'}
                              </span>
                            </td>
                            <td className="text-center">
                              <div className="fw-bold text-primary">
                                <span className="d-flex align-items-center justify-content-center gap-1">
                                  <DollarSign size={14} />
                                  {termPay.toLocaleString()}
                                </span>
                              </div>
                            </td>
                            <td className="text-center d-none d-lg-table-cell">
                              <span className="text-muted small">
                                {moment(user.lastLogin).fromNow()}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-5 text-muted">
                  <Trophy size={48} className="opacity-50 mb-3" />
                  <div>No leaderboard data available</div>
                </div>
              )}
            </div>
          </div>

          <div className="row mt-4 justify-content-center">
            <div className="col-lg-6 col-xl-4 mb-3">
              <div className="card stat-card bg-primary text-white">
                <div className="card-body">
                  <div className="d-flex align-items-center justify-content-between">
                    <div>
                      <h3 className="mb-0">
                        {sortedUsers.length > 0 ? sortedUsers.reduce((sum, user) => sum + (user.stats?.termPay || 0), 0).toLocaleString() : '0'}
                      </h3>
                      <h6 className="card-title mb-0">Total Term Pay</h6>
                    </div>
                    <DollarSign size={28} className="opacity-75" />
                  </div>
                </div>
              </div>
            </div>
            <div className="col-lg-6 col-xl-4 mb-3">
              <div className="card stat-card bg-warning text-dark">
                <div className="card-body">
                  <div className="d-flex align-items-center justify-content-between">
                    <div>
                      <h3 className="mb-0">
                        {sortedUsers.length}
                      </h3>
                      <h6 className="card-title mb-0">Staff Members</h6>
                    </div>
                    <User size={28} className="opacity-75" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Leaderboard; 