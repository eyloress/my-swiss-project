import React, { useState, useEffect, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { useNavigate } from 'react-router-dom';
import { 
  Search, 
  User, 
  Users, 
  Shield, 
  Award, 
  AlertTriangle,
  FileText,
  Calendar,
  Settings,
  Plus,
  Edit,
  Trash2,
  Eye,
  EyeOff,
  Save,
  X,
  Filter,
  RotateCcw,
  CheckCircle,
  Clock,
  Plane,
  TrendingUp,
  Gift
} from 'lucide-react';
import axios from 'axios';
import moment from 'moment';
import LoadingSpinner from '../components/LoadingSpinner';
import ConfirmationModal from '../components/ConfirmationModal';
import { toast } from 'react-toastify';

const AdminDivision = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState('');
  const [selectedUser, setSelectedUser] = useState(null);
  const [activeTab, setActiveTab] = useState('quota');
  const [showUsersList, setShowUsersList] = useState(true);
  const [filter, setFilter] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newItem, setNewItem] = useState({});
  const [editingItem, setEditingItem] = useState(null);
  
  const [historyPage, setHistoryPage] = useState(1);
  const [historyActionFilter, setHistoryActionFilter] = useState('all');
  const [historyUserFilter, setHistoryUserFilter] = useState('');
  
  const [userHistoryPage, setUserHistoryPage] = useState(1);
  const [userHistoryActionFilter, setUserHistoryActionFilter] = useState('all');
  
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [confirmStep, setConfirmStep] = useState(1);

  const queryClient = useQueryClient();
  const navigate = useNavigate();


  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 300);

    return () => clearTimeout(timer);
  }, [searchTerm]);


  const { data: usersData, isLoading: usersLoading, error: usersError } = useQuery(
    ['admin-users', debouncedSearchTerm, filter],
    async () => {
      try {
        let url = `/api/admin/users?search=${encodeURIComponent(debouncedSearchTerm)}`;
        if (filter === 'quota-deficit') {
          url += '&filter=quota-deficit';
        }
        const response = await axios.get(url);
        return response.data;
      } catch (error) {
        throw error;
      }
    },
    {
      enabled: showUsersList,
      refetchOnWindowFocus: false,
      staleTime: 0,
      cacheTime: 0,
      keepPreviousData: true,
      retry: 1
    }
  );


  const { data: userDetails, isLoading: userLoading } = useQuery(
    ['admin-user', selectedUser?.id],
    () => axios.get(`/api/admin/users/${selectedUser.id}`).then(res => res.data),
    {
      enabled: !!selectedUser,
      refetchOnWindowFocus: true,
      staleTime: 0,
      cacheTime: 0
    }
  );


  const { data: adminHistory, isLoading: historyLoading } = useQuery(
    ['admin-history', historyPage, historyActionFilter, historyUserFilter],
    () => {
      const params = new URLSearchParams({
        page: historyPage,
        limit: 10,
        ...(historyActionFilter !== 'all' && { actionType: historyActionFilter }),
        ...(historyUserFilter && { targetUser: historyUserFilter })
      });
      return axios.get(`/api/admin/history?${params}`).then(res => res.data);
    },
    {
      enabled: showUsersList,
      refetchOnWindowFocus: false,
      staleTime: 30000,
      keepPreviousData: true
    }
  );


  const { data: userAdminHistory, isLoading: userHistoryLoading } = useQuery(
    ['user-admin-history', selectedUser?.robloxUsername, userHistoryPage, userHistoryActionFilter],
    () => {
      const params = new URLSearchParams({
        page: userHistoryPage,
        limit: 10,
        ...(userHistoryActionFilter !== 'all' && { actionType: userHistoryActionFilter }),
        targetUser: selectedUser.robloxUsername
      });
      return axios.get(`/api/admin/history?${params}`).then(res => res.data);
    },
    {
      enabled: !!selectedUser && !showUsersList,
      refetchOnWindowFocus: false,
      staleTime: 30000,
      keepPreviousData: true
    }
  );


  const addSanctionMutation = useMutation(
    (data) => axios.post(`/api/admin/users/${selectedUser.id}/sanctions`, data),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(['admin-user', selectedUser.id]);
        queryClient.invalidateQueries(['admin-history']);
        queryClient.invalidateQueries(['user-admin-history', selectedUser?.robloxUsername]);
        setShowAddModal(false);
        setNewItem({});
        toast.success(`Sanction added successfully to @${selectedUser.robloxUsername}`);
      },
      onError: (error) => {
        toast.error(`Failed to add sanction: ${error.response?.data?.message || error.message}`);
      }
    }
  );

  const deleteSanctionMutation = useMutation(
    (sanctionId) => axios.delete(`/api/admin/users/${selectedUser.id}/sanctions/${sanctionId}`),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(['admin-user', selectedUser.id]);
        queryClient.invalidateQueries(['admin-history']);
        queryClient.invalidateQueries(['user-admin-history', selectedUser?.robloxUsername]);
        toast.success(`Sanction deleted successfully from @${selectedUser.robloxUsername}`);
      },
      onError: (error) => {
        toast.error(`Failed to delete sanction: ${error.response?.data?.message || error.message}`);
      }
    }
  );

  const addQualificationMutation = useMutation(
    (data) => axios.post(`/api/admin/users/${selectedUser.id}/qualifications`, data),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(['admin-user', selectedUser.id]);
        queryClient.invalidateQueries(['admin-history']);
        queryClient.invalidateQueries(['user-admin-history', selectedUser?.robloxUsername]);
        setShowAddModal(false);
        setNewItem({});
        toast.success(`Qualification added successfully to @${selectedUser.robloxUsername}`);
      },
      onError: (error) => {
        toast.error(`Failed to add qualification: ${error.response?.data?.message || error.message}`);
      }
    }
  );

  const deleteQualificationMutation = useMutation(
    (qualId) => axios.delete(`/api/admin/users/${selectedUser.id}/qualifications/${qualId}`),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(['admin-user', selectedUser.id]);
        queryClient.invalidateQueries(['admin-history']);
        queryClient.invalidateQueries(['user-admin-history', selectedUser?.robloxUsername]);
        toast.success(`Qualification removed successfully from @${selectedUser.robloxUsername}`);
      },
      onError: (error) => {
        toast.error(`Failed to remove qualification: ${error.response?.data?.message || error.message}`);
      }
    }
  );

  const updateQuotaMutation = useMutation(
    (quota) => axios.put(`/api/admin/users/${selectedUser.id}/quota`, { requiredFlights: quota }),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(['admin-user', selectedUser.id]);
        queryClient.invalidateQueries(['admin-history']);
        queryClient.invalidateQueries(['user-admin-history', selectedUser?.robloxUsername]);
        toast.success(`Quota updated successfully for @${selectedUser.robloxUsername}`);
      },
      onError: (error) => {
        toast.error(`Failed to update quota: ${error.response?.data?.message || error.message}`);
      }
    }
  );

  const addNoteMutation = useMutation(
    (data) => axios.post(`/api/admin/users/${selectedUser.id}/notes`, data),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(['admin-user', selectedUser.id]);
        queryClient.invalidateQueries(['admin-history']);
        queryClient.invalidateQueries(['user-admin-history', selectedUser?.robloxUsername]);
        setShowAddModal(false);
        setNewItem({});
        toast.success(`Note added successfully to @${selectedUser.robloxUsername}`);
      },
      onError: (error) => {
        toast.error(`Failed to add note: ${error.response?.data?.message || error.message}`);
      }
    }
  );

  const addRewardMutation = useMutation(
    (data) => axios.post(`/api/admin/users/${selectedUser.id}/reward`, data),
    {
      onSuccess: (response, variables) => {
        queryClient.invalidateQueries(['admin-user', selectedUser.id]);
        queryClient.invalidateQueries(['admin-history']);
        queryClient.invalidateQueries(['user-admin-history', selectedUser?.robloxUsername]);
        setShowAddModal(false);
        setNewItem({});
        toast.success(`Reward of $${variables.amount} added successfully to @${selectedUser.robloxUsername}`);
      },
      onError: (error) => {
        toast.error(`Failed to add reward: ${error.response?.data?.message || error.message}`);
      }
    }
  );

  const advanceTermMutation = useMutation(
    () => axios.post('/api/admin/term/advance'),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(['admin-users']);
        queryClient.invalidateQueries(['admin-history']);
        toast.success('Term advanced successfully! All users\' term flights have been moved to career totals.');
      },
      onError: (error) => {
        toast.error(`Failed to advance term: ${error.response?.data?.message || error.message}`);
      }
    }
  );

  const handleAdvanceTerm = () => {
    setConfirmStep(1);
    setShowConfirmModal(true);
  };

  const handleConfirmStep1 = () => {
    setConfirmStep(2);
  };

  const handleConfirmStep2 = () => {
    setShowConfirmModal(false);
    setConfirmStep(1);
    advanceTermMutation.mutate();
  };

  const handleCloseConfirm = () => {
    setShowConfirmModal(false);
    setConfirmStep(1);
  };

  const qualificationOptions = [
    'Ground Services Licence',
    'Cabin Crew Licence',
    'First Officer Licence',
    'Captain License',
    'Tarmac Supervisor Licence',
    'Maître de Cabine Licence',
    'Administrative Division',
    'Operations Division',
    'Network Division'
  ];

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleUserSelect = (user) => {
    setSelectedUser(user);
    setShowUsersList(false);
    setActiveTab('quota');
  };

  const handleAddItem = () => {
    if (activeTab === 'sanctions') {
      addSanctionMutation.mutate(newItem);
    } else if (activeTab === 'qualifications') {
      addQualificationMutation.mutate(newItem);
    } else if (activeTab === 'notes') {
      addNoteMutation.mutate(newItem);
    } else if (activeTab === 'rewards') {
      addRewardMutation.mutate(newItem);
    }
  };

  const getSanctionBadgeClass = (type) => {
    const classes = {
      'reminder': 'badge-info',
      'warning': 'badge-warning',
      'suspension': 'badge-danger'
    };
    return classes[type] || 'badge-secondary';
  };

  return (
    <div className="admin-division-container">
    <div className="container-fluid">

        <div className="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h1 className="h2 mb-0 text-primary d-flex align-items-center gap-2">
              <Shield size={28} />
              Administrative Division
            </h1>
            <p className="text-muted mb-0">Staff management and administrative tools</p>
          </div>
          {!showUsersList && (
            <button
              className="btn btn-outline"
              onClick={() => {
                setShowUsersList(true);
                setSelectedUser(null);
              }}
            >
              <Users size={18} />
              Back to Users
            </button>
          )}
        </div>

        {usersError && (
          <div className="alert alert-danger mb-4">
            <strong>Error:</strong> {usersError.response?.data?.message || usersError.message || 'Failed to load users'}
          </div>
        )}

        {showUsersList ? (

          <div>

            <div className="card mb-4">
              <div className="card-body">
                <div className="row align-items-center">
                  <div className="col-md-6">
                    <div className="search-container">
                      <div className="search-input-wrapper">
                        <Search className="search-icon" size={18} />
                        <input
                          type="text"
                          className="form-control search-input"
                          placeholder="Search by username or Roblox ID..."
                          value={searchTerm}
                          onChange={handleSearch}
                          disabled={usersLoading}
                        />
                        {usersLoading && (
                          <div className="position-absolute" style={{ right: '10px', top: '50%', transform: 'translateY(-50%)' }}>
                            <div className="spinner-border spinner-border-sm text-primary" role="status">
                              <span className="visually-hidden">Loading...</span>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="d-flex gap-2">
                      <select
                        className="form-select"
                        value={filter}
                        onChange={(e) => setFilter(e.target.value)}
                      >
                        <option value="all">All Users</option>
                        <option value="below-quota">Below Quota (sorted by ratio)</option>
                        <option value="over-quota">Over Quota (sorted by ratio)</option>
                        <option value="quota-deficit">Quota Deficit (legacy)</option>
                      </select>
                      <button
                        className="btn btn-primary"
                        onClick={handleAdvanceTerm}
                        disabled={advanceTermMutation.isLoading}
                      >
                        <RotateCcw size={18} />
                        {advanceTermMutation.isLoading ? 'Processing...' : 'Advance Term'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="users-grid">
              {usersData?.users?.map(user => (
                <div
                  key={user._id}
                  className="user-card"
                  onClick={() => handleUserSelect({ id: user._id, ...user })}
                >
                  <div className="user-info">
                    <div className="user-avatar">
                      {user.robloxAvatarUrl ? (
                        <img src={user.robloxAvatarUrl} alt="Avatar" className="avatar-img" />
                      ) : (
                        <User size={32} className="text-muted" />
                      )}
                    </div>
                    <div className="user-details">
                      <div className="user-name">@{user.robloxUsername}</div>
                      <div className="user-rank">{user.groupRank?.rankName || 'Unknown'}</div>
                      <div className="text-muted small">
                        Term: {user.termFlightsCount || user.stats?.termFlightsAttended || 0}/{user.stats?.requiredFlights || 0} flights
                        {user.quotaRatio !== undefined && (
                          <span className={`ms-2 badge badge-sm ${
                            user.quotaRatio >= 1 ? 'badge-success' : 'badge-warning'
                          }`}>
                            {Math.round(user.quotaRatio * 100)}%
                          </span>
                        )}
                      </div>
                      {user.isOnLeave && (
                        <span className="badge badge-warning badge-sm">On Leave</span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {usersData?.users?.length === 0 && (
              <div className="text-center py-5">
                <Users size={48} className="text-muted mb-3" />
                <h4>No users found</h4>
                <p className="text-muted">Try adjusting your search or filter criteria.</p>
              </div>
            )}

            <div className="card mt-4">
              <div className="card-header">
                <div className="d-flex justify-content-between align-items-center">
                  <h5 className="mb-0 d-flex align-items-center gap-2">
                    <Settings size={18} />
                    Administrative History
                  </h5>
                  <div className="d-flex gap-2">
                    <select
                      className="form-select form-select-sm"
                      value={historyActionFilter}
                      onChange={(e) => {
                        setHistoryActionFilter(e.target.value);
                        setHistoryPage(1);
                      }}
                      style={{ width: 'auto' }}
                    >
                      <option value="all">All Actions</option>
                      <option value="sanction_add">Add Sanction</option>
                      <option value="sanction_delete">Delete Sanction</option>
                      <option value="qualification_add">Add Qualification</option>
                      <option value="qualification_delete">Delete Qualification</option>
                      <option value="note_add">Add Note</option>
                      <option value="reward_add">Add Reward</option>
                      <option value="quota_update">Update Quota</option>
                      <option value="term_advance">Advance Term</option>
                    </select>
                    <input
                      type="text"
                      className="form-control form-control-sm"
                      placeholder="Filter by username..."
                      value={historyUserFilter}
                      onChange={(e) => {
                        setHistoryUserFilter(e.target.value);
                        setHistoryPage(1);
                      }}
                      style={{ width: '200px' }}
                    />
                  </div>
                </div>
              </div>
              <div className="card-body">
                {historyLoading ? (
                  <LoadingSpinner />
                ) : adminHistory?.actions?.length > 0 ? (
                  <>
                    <div className="admin-history-timeline">
                      {adminHistory.actions.map((action, index) => (
                        <div key={action._id} className="admin-history-item">
                          <div className="admin-history-marker"></div>
                          <div className="admin-history-content">
                            <div className="admin-history-header">
                              <div className="d-flex justify-content-between align-items-start">
                                <div className="d-flex align-items-center gap-2">
                                  <span className={`badge admin-action-badge ${
                                    action.actionType.includes('add') ? 'badge-success' :
                                    action.actionType.includes('delete') ? 'badge-danger' :
                                    action.actionType.includes('update') ? 'badge-warning' :
                                    action.actionType === 'term_advance' ? 'badge-primary' : 'badge-info'
                                  }`}>
                                    {action.actionType.replace('_', ' ').toUpperCase()}
                                  </span>
                                  <span className="fw-semibold">
                                    <span 
                                      className="promoter-link"
                                      onClick={() => navigate(`/profile/lookup/${action.performedByUsername}`)}
                                    >
                                      @{action.performedByUsername}
                                    </span>
                                  </span>
                                  {action.targetUsername && (
                                    <>
                                      <span className="text-muted mx-1">→</span>
                                      <span 
                                        className="promoter-link"
                                        onClick={() => navigate(`/u/${action.targetUsername}`)}
                                      >
                                        @{action.targetUsername}
                                      </span>
                                    </>
                                  )}
                                </div>
                                <small className="text-muted">
                                  {moment(action.timestamp).format('MMM DD, HH:mm')}
                                </small>
                              </div>
                            </div>
                            <div className="admin-history-details">
                              <div className="fw-semibold mb-1">{action.details.action}</div>
                              {action.details.sanctionType && (
                                <div><strong>Type:</strong> {action.details.sanctionType}</div>
                              )}
                              {action.details.breach && (
                                <div><strong>Breach:</strong> {action.details.breach}</div>
                              )}
                              {action.details.reason && (
                                <div><strong>Reason:</strong> {action.details.reason}</div>
                              )}
                              {action.details.qualificationName && (
                                <div><strong>Qualification:</strong> {action.details.qualificationName}</div>
                              )}
                              {action.details.amount && (
                                <div><strong>Amount:</strong> ${action.details.amount}</div>
                              )}
                              {action.details.rewardType && (
                                <div><strong>Type:</strong> {action.details.rewardType}</div>
                              )}
                              {action.details.newRequiredFlights !== undefined && (
                                <div><strong>New Quota:</strong> {action.details.newRequiredFlights} flights</div>
                              )}
                              {action.details.noteType && (
                                <div><strong>Note Type:</strong> {action.details.noteType}</div>
                              )}
                              {action.details.content && (
                                <div><strong>Content:</strong> {action.details.content}</div>
                              )}
                              {action.details.usersProcessed && (
                                <div><strong>Users Processed:</strong> {action.details.usersProcessed}</div>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {adminHistory.pagination && adminHistory.pagination.pages > 1 && (
                      <div className="d-flex justify-content-between align-items-center mt-4">
                        <div className="text-muted small">
                          Showing {((adminHistory.pagination.page - 1) * adminHistory.pagination.limit) + 1} to{' '}
                          {Math.min(adminHistory.pagination.page * adminHistory.pagination.limit, adminHistory.pagination.total)} of{' '}
                          {adminHistory.pagination.total} actions
                        </div>
                        <div className="d-flex gap-1">
                          <button
                            className="btn btn-outline btn-sm"
                            onClick={() => setHistoryPage(historyPage - 1)}
                            disabled={historyPage <= 1}
                          >
                            Previous
                          </button>
                          {Array.from({ length: Math.min(5, adminHistory.pagination.pages) }, (_, i) => {
                            const page = i + 1;
                            return (
                              <button
                                key={page}
                                className={`btn btn-sm ${page === historyPage ? 'btn-primary' : 'btn-outline'}`}
                                onClick={() => setHistoryPage(page)}
                              >
                                {page}
                              </button>
                            );
                          })}
                          <button
                            className="btn btn-outline btn-sm"
                            onClick={() => setHistoryPage(historyPage + 1)}
                            disabled={historyPage >= adminHistory.pagination.pages}
                          >
                            Next
                          </button>
                        </div>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-center py-4 text-muted">
                    <Settings size={32} className="mb-2" />
                    <div>No administrative actions recorded</div>
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : (

          selectedUser && (
            <div>
              {userLoading ? (
                <LoadingSpinner />
              ) : userDetails ? (
                <div>

                  <div className="card mb-4">
                    <div className="card-body">
                      <div className="row align-items-center">
                        <div className="col-md-3 text-center">
                          {userDetails.user.robloxAvatarUrl ? (
                            <img
                              src={userDetails.user.robloxAvatarUrl}
                              alt="Avatar"
                              style={{ 
                                width: '100px', 
                                height: '100px', 
                                objectFit: 'cover',
                                border: '3px solid var(--swiss-red)'
                              }}
                            />
                          ) : (
                            <div 
                              className="bg-light d-flex align-items-center justify-content-center mx-auto"
                              style={{ 
                                width: '100px', 
                                height: '100px',
                                border: '3px solid var(--swiss-red)'
                              }}
                            >
                              <User size={40} className="text-muted" />
                            </div>
                          )}
                        </div>
                        <div className="col-md-6">
                          <h3 className="mb-1 text-primary">@{userDetails.user.robloxUsername}</h3>
                          <div className="mb-2">
                            <span className="badge badge-primary me-2">{userDetails.user.groupRank?.rankName}</span>
                            <span className="badge badge-secondary">ID: {userDetails.user.robloxId}</span>
                          </div>
                          <div className="text-muted">
                            Role: {userDetails.user.role} | Last login: {moment(userDetails.user.lastLogin).format('MMM DD, HH:mm')}
                          </div>
                        </div>
                        <div className="col-md-3">
                          <div className="d-flex flex-column gap-2">
                            <div className="d-flex justify-content-between">
                              <span className="text-muted">Term flights:</span>
                              <span className="fw-semibold">
                                {userDetails.user.stats?.termFlightsAttended || 0}/{userDetails.user.stats?.requiredFlights || 0}
                              </span>
                            </div>
                            <div className="d-flex justify-content-between">
                              <span className="text-muted">Status:</span>
                              <div className="d-flex gap-1">
                                {userDetails.user.isOnLeave && (
                                  <span className="badge badge-warning">On Leave</span>
                                )}
                                {userDetails.user.sanctions?.some(s => 
                                  s.type === 'suspension' && 
                                  new Date(s.expiryDate) > new Date() &&
                                  (!s.activeUntil || new Date(s.activeUntil) > new Date())
                                ) ? (
                                  <span className="badge badge-danger">Suspended</span>
                                ) : (
                                  <span className="badge badge-success">Active</span>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="card">
                    <div className="card-header p-0">
                      <div className="admin-tabs">
                        {['quota', 'sanctions', 'qualifications', 'notes', 'rewards', 'history'].map(tab => (
                          <button
                            key={tab}
                            className={`admin-tab ${activeTab === tab ? 'active' : ''}`}
                            onClick={() => setActiveTab(tab)}
                          >
                            {tab === 'quota' && <TrendingUp size={16} />}
                            {tab === 'sanctions' && <AlertTriangle size={16} />}
                            {tab === 'qualifications' && <Award size={16} />}
                            {tab === 'notes' && <FileText size={16} />}
                            {tab === 'rewards' && <Gift size={16} />}
                            {tab === 'history' && <Clock size={16} />}
                            {tab.charAt(0).toUpperCase() + tab.slice(1)}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="card-body">

                      {activeTab === 'quota' && (
                        <div>
                          <div className="row">
                            <div className="col-md-6">
                              <div className="mb-3">
                                <label className="form-label fw-semibold">Required Flights per Term</label>
                                <div className="d-flex gap-2">
                                  <input
                                    type="number"
                                    className="form-control"
                                    defaultValue={userDetails.user.stats?.requiredFlights || 0}
                                    min="0"
                                    onBlur={(e) => {
                                      const value = parseInt(e.target.value);
                                      if (value !== userDetails.user.stats?.requiredFlights) {
                                        updateQuotaMutation.mutate(value);
                                      }
                                    }}
                                  />
                                  <span className="btn btn-outline disabled">flights</span>
                                </div>
                              </div>
                            </div>
                            <div className="col-md-6">
                              <div className="admin-stats-grid">
                                <div className="admin-stat-card bg-primary text-white">
                                  <div className="d-flex justify-content-between align-items-center">
                                    <div>
                                      <div className="small opacity-75">Term Attended</div>
                                      <div className="h4 mb-0">{userDetails.user.stats?.termFlightsAttended || 0}</div>
                                    </div>
                                    <Plane size={24} className="opacity-75" />
                                  </div>
                                </div>
                                <div className="admin-stat-card bg-success text-white">
                                  <div className="d-flex justify-content-between align-items-center">
                                    <div>
                                      <div className="small opacity-75">Term Hosted</div>
                                      <div className="h4 mb-0">{userDetails.user.stats?.termFlightsHosted || 0}</div>
                                    </div>
                                    <TrendingUp size={24} className="opacity-75" />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}

                      {activeTab === 'sanctions' && (
                        <div>
                          <div className="d-flex justify-content-between align-items-center mb-3">
                            <h5 className="mb-0">Sanctions Management</h5>
                            <button
                              className="btn btn-primary"
                              onClick={() => {
                                setShowAddModal(true);
                                setNewItem({
                                  type: 'reminder',
                                  breach: '',
                                  reason: '',
                                  comment: '',
                                  expiryDate: moment().add(30, 'days').format('YYYY-MM-DD')
                                });
                              }}
                            >
                              <Plus size={16} />
                              Add Sanction
                            </button>
                          </div>

                          <div className="table-responsive">
                            <table className="table">
                              <thead>
                                <tr>
                                  <th>Type</th>
                                  <th>Breach</th>
                                  <th>Reason</th>
                                  <th>Issuer</th>
                                  <th>Issued</th>
                                  <th>Expires</th>
                                  <th>Actions</th>
                                </tr>
                              </thead>
                              <tbody>
                                {userDetails.user.sanctions?.map(sanction => (
                                  <tr key={sanction._id}>
                                    <td>
                                      <span className={`badge ${getSanctionBadgeClass(sanction.type)}`}>
                                        {sanction.type} #{sanction.count}
                                      </span>
                                    </td>
                                    <td>{sanction.breach}</td>
                                    <td>{sanction.reason}</td>
                                    <td>{sanction.issuerUsername}</td>
                                    <td>{moment(sanction.issuedDate).format('MMM DD, YYYY')}</td>
                                    <td>{moment(sanction.expiryDate).format('MMM DD, YYYY')}</td>
                                    <td>
                                      <button
                                        className="btn btn-sm btn-outline text-danger"
                                        onClick={() => deleteSanctionMutation.mutate(sanction._id)}
                                      >
                                        <Trash2 size={14} />
                                      </button>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                            {!userDetails.user.sanctions?.length && (
                              <div className="text-center py-4 text-muted">
                                <AlertTriangle size={32} className="mb-2" />
                                <div>No sanctions recorded</div>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {activeTab === 'qualifications' && (
                        <div>
                          <div className="d-flex justify-content-between align-items-center mb-3">
                            <h5 className="mb-0">Qualifications Management</h5>
                            <button
                              className="btn btn-primary"
                              onClick={() => {
                                setShowAddModal(true);
                                setNewItem({ name: qualificationOptions[0] });
                              }}
                            >
                              <Plus size={16} />
                              Add Qualification
                            </button>
                          </div>

                          <div className="qualification-tags-container mb-4">
                            {userDetails.user.qualifications?.map(qual => (
                              <div key={qual._id} className="qualification-tag active d-inline-flex align-items-center gap-2">
                                {qual.name}
                                <button
                                  className="btn-close btn-close-white btn-sm"
                                  onClick={() => deleteQualificationMutation.mutate(qual._id)}
                                >
                                  <X size={12} />
                                </button>
                              </div>
                            ))}
                          </div>

                          {!userDetails.user.qualifications?.length && (
                            <div className="text-center py-4 text-muted">
                              <Award size={32} className="mb-2" />
                              <div>No qualifications granted</div>
                            </div>
                          )}
                        </div>
                      )}

                      {activeTab === 'notes' && (
                        <div>
                          <div className="d-flex justify-content-between align-items-center mb-3">
                            <h5 className="mb-0">Notes Management</h5>
                            <button
                              className="btn btn-primary"
                              onClick={() => {
                                setShowAddModal(true);
                                setNewItem({
                                  content: '',
                                  visibleToUser: false,
                                  type: 'general'
                                });
                              }}
                            >
                              <Plus size={16} />
                              Add Note
                            </button>
                          </div>

                          <div className="space-y-3">
                            {userDetails.user.notes?.map(note => (
                              <div key={note._id} className="card">
                                <div className="card-body">
                                  <div className="d-flex justify-content-between align-items-start mb-2">
                                    <div className="d-flex gap-2">
                                      <span className={`badge ${
                                        note.type === 'loa' ? 'badge-warning' :
                                        note.type === 'performance' ? 'badge-info' : 'badge-secondary'
                                      }`}>
                                        {note.type}
                                      </span>
                                      {note.visibleToUser ? (
                                        <span className="badge badge-success">
                                          <Eye size={12} /> Visible
                                        </span>
                                      ) : (
                                        <span className="badge badge-danger">
                                          <EyeOff size={12} /> Hidden
                                        </span>
                                      )}
                                    </div>
                                    <small className="text-muted">
                                      {moment(note.addedDate).format('MMM DD, YYYY')}
                                    </small>
                                  </div>
                                  <p className="mb-0">{note.content}</p>
                                </div>
                              </div>
                            ))}
                          </div>

                          {!userDetails.user.notes?.length && (
                            <div className="text-center py-4 text-muted">
                              <FileText size={32} className="mb-2" />
                              <div>No notes recorded</div>
                            </div>
                          )}
                        </div>
                      )}

                      {activeTab === 'rewards' && (
                        <div>
                          <div className="d-flex justify-content-between align-items-center mb-3">
                            <h5 className="mb-0">Reward Management</h5>
                            <button
                              className="btn btn-primary"
                              onClick={() => {
                                setShowAddModal(true);
                                setNewItem({
                                  amount: '',
                                  reason: '',
                                  type: 'bonus'
                                });
                              }}
                            >
                              <Plus size={16} />
                              Add Reward
                            </button>
                          </div>

                          <div className="space-y-3">
                            {userDetails.user.rewards?.map(reward => (
                              <div key={reward._id} className="card">
                                <div className="card-body">
                                  <div className="d-flex justify-content-between align-items-start mb-2">
                                    <div className="d-flex gap-2">
                                      <span className={`badge ${
                                        reward.type === 'bonus' ? 'badge-success' :
                                        reward.type === 'commission' ? 'badge-info' : 'badge-primary'
                                      }`}>
                                        {reward.type}
                                      </span>
                                      <span className="badge badge-warning">
                                        +${reward.amount}
                                      </span>
                                    </div>
                                    <small className="text-muted">
                                      {moment(reward.awardedDate).format('MMM DD, YYYY')}
                                    </small>
                                  </div>
                                  <p className="mb-0">{reward.reason}</p>
                                  <small className="text-muted">Awarded by: {reward.awardedBy}</small>
                                  </div>
                                </div>
                              ))}
                            </div>

                          {!userDetails.user.rewards?.length && (
                            <div className="text-center py-4 text-muted">
                              <Gift size={32} className="mb-2" />
                              <div>No rewards awarded</div>
                          </div>
                          )}
                        </div>
                      )}

                      {activeTab === 'history' && (
                          <div>
                          <div className="d-flex justify-content-between align-items-center mb-3">
                            <h5 className="mb-0">Administrative History</h5>
                            <div className="d-flex gap-2">
                              <select
                                className="form-select form-select-sm"
                                value={userHistoryActionFilter}
                                onChange={(e) => {
                                  setUserHistoryActionFilter(e.target.value);
                                  setUserHistoryPage(1);
                                }}
                                style={{ width: 'auto' }}
                              >
                                <option value="all">All Actions</option>
                                <option value="sanction_add">Add Sanction</option>
                                <option value="sanction_delete">Delete Sanction</option>
                                <option value="qualification_add">Add Qualification</option>
                                <option value="qualification_delete">Delete Qualification</option>
                                <option value="note_add">Add Note</option>
                                <option value="reward_add">Add Reward</option>
                                <option value="quota_update">Update Quota</option>
                              </select>
                            </div>
                          </div>
                          
                          {userHistoryLoading ? (
                            <LoadingSpinner />
                          ) : userAdminHistory?.actions?.length > 0 ? (
                            <>
                              <div className="admin-history-timeline">
                                {userAdminHistory.actions.map((action, index) => (
                                  <div key={action._id} className="admin-history-item">
                                    <div className="admin-history-marker"></div>
                                    <div className="admin-history-content">
                                      <div className="admin-history-header">
                                        <div className="d-flex justify-content-between align-items-start">
                                          <div className="d-flex align-items-center gap-2">
                                            <span className={`badge admin-action-badge ${
                                              action.actionType.includes('add') ? 'badge-success' :
                                              action.actionType.includes('delete') ? 'badge-danger' :
                                              action.actionType.includes('update') ? 'badge-warning' :
                                              action.actionType === 'term_advance' ? 'badge-primary' : 'badge-info'
                                        }`}>
                                              {action.actionType.replace('_', ' ').toUpperCase()}
                                        </span>
                                            <span className="fw-semibold">
                                              <span 
                                                className="promoter-link"
                                                onClick={() => navigate(`/profile/lookup/${action.performedByUsername}`)}
                                              >
                                                @{action.performedByUsername}
                                              </span>
                                            </span>
                                            {action.targetUsername && action.targetUsername !== selectedUser.robloxUsername && (
                                              <>
                                                <span className="text-muted mx-1">→</span>
                                                <span 
                                                  className="promoter-link"
                                                  onClick={() => navigate(`/u/${action.targetUsername}`)}
                                                >
                                                  @{action.targetUsername}
                                                </span>
                                              </>
                                            )}
                                          </div>
                                          <small className="text-muted">
                                            {moment(action.timestamp).format('MMM DD, HH:mm')}
                                          </small>
                                        </div>
                                      </div>
                                      <div className="admin-history-details">
                                        <div className="fw-semibold mb-1">{action.details.action}</div>
                                        {action.details.sanctionType && (
                                          <div><strong>Type:</strong> {action.details.sanctionType}</div>
                                        )}
                                        {action.details.breach && (
                                          <div><strong>Breach:</strong> {action.details.breach}</div>
                                        )}
                                        {action.details.reason && (
                                          <div><strong>Reason:</strong> {action.details.reason}</div>
                                        )}
                                        {action.details.qualificationName && (
                                          <div><strong>Qualification:</strong> {action.details.qualificationName}</div>
                                        )}
                                        {action.details.amount && (
                                          <div><strong>Amount:</strong> ${action.details.amount}</div>
                                        )}
                                        {action.details.rewardType && (
                                          <div><strong>Type:</strong> {action.details.rewardType}</div>
                                        )}
                                        {action.details.newRequiredFlights !== undefined && (
                                          <div><strong>New Quota:</strong> {action.details.newRequiredFlights} flights</div>
                                        )}
                                        {action.details.noteType && (
                                          <div><strong>Note Type:</strong> {action.details.noteType}</div>
                                        )}
                                        {action.details.content && (
                                          <div><strong>Content:</strong> {action.details.content}</div>
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                ))}
                            </div>

                              {userAdminHistory.pagination && userAdminHistory.pagination.pages > 1 && (
                                <div className="d-flex justify-content-between align-items-center mt-4">
                                  <div className="text-muted small">
                                    Showing {((userAdminHistory.pagination.page - 1) * userAdminHistory.pagination.limit) + 1} to{' '}
                                    {Math.min(userAdminHistory.pagination.page * userAdminHistory.pagination.limit, userAdminHistory.pagination.total)} of{' '}
                                    {userAdminHistory.pagination.total} actions
                                  </div>
                                  <div className="d-flex gap-1">
                                    <button
                                      className="btn btn-outline btn-sm"
                                      onClick={() => setUserHistoryPage(userHistoryPage - 1)}
                                      disabled={userHistoryPage <= 1}
                                    >
                                      Previous
                                    </button>
                                    {Array.from({ length: Math.min(5, userAdminHistory.pagination.pages) }, (_, i) => {
                                      const page = i + 1;
                                      return (
                                        <button
                                          key={page}
                                          className={`btn btn-sm ${page === userHistoryPage ? 'btn-primary' : 'btn-outline'}`}
                                          onClick={() => setUserHistoryPage(page)}
                                        >
                                          {page}
                                        </button>
                                      );
                                    })}
                                    <button
                                      className="btn btn-outline btn-sm"
                                      onClick={() => setUserHistoryPage(userHistoryPage + 1)}
                                      disabled={userHistoryPage >= userAdminHistory.pagination.pages}
                                    >
                                      Next
                                    </button>
                          </div>
                        </div>
                      )}
                            </>
                          ) : (
                            <div className="text-center py-4 text-muted">
                              <Settings size={32} className="mb-2" />
                              <div>No administrative actions recorded for this user</div>
                    </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="alert alert-danger">Failed to load user details</div>
              )}
            </div>
          )
        )}

        {showAddModal && (
          <div className="modal-overlay">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="mb-0">
                  Add {activeTab === 'sanctions' ? 'Sanction' : 
                       activeTab === 'qualifications' ? 'Qualification' : 
                       activeTab === 'rewards' ? 'Reward' : 'Note'}
                </h5>
                <button
                  className="btn btn-ghost btn-sm"
                  onClick={() => setShowAddModal(false)}
                >
                  <X size={16} />
                </button>
              </div>
              <div className="modal-body">
                {activeTab === 'sanctions' && (
                  <div>
                    <div className="mb-3">
                      <label className="form-label">Type</label>
                      <select
                        className="form-select"
                        value={newItem.type || 'reminder'}
                        onChange={(e) => setNewItem({...newItem, type: e.target.value})}
                      >
                        <option value="reminder">Reminder</option>
                        <option value="warning">Warning</option>
                        <option value="suspension">Suspension</option>
                      </select>
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Breach</label>
                      <input
                        type="text"
                        className="form-control"
                        value={newItem.breach || ''}
                        onChange={(e) => setNewItem({...newItem, breach: e.target.value})}
                        placeholder="What rule was breached?"
                      />
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Reason</label>
                      <textarea
                        className="form-control"
                        value={newItem.reason || ''}
                        onChange={(e) => setNewItem({...newItem, reason: e.target.value})}
                        placeholder="Detailed reason for the sanction"
                        rows="3"
                      />
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Comment (Optional)</label>
                      <textarea
                        className="form-control"
                        value={newItem.comment || ''}
                        onChange={(e) => setNewItem({...newItem, comment: e.target.value})}
                        placeholder="Additional comments"
                        rows="2"
                      />
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Expiry Date</label>
                      <input
                        type="date"
                        className="form-control"
                        value={newItem.expiryDate || ''}
                        onChange={(e) => setNewItem({...newItem, expiryDate: e.target.value})}
                      />
                    </div>
                    {newItem.type === 'suspension' && (
                      <div className="mb-3">
                        <label className="form-label">Active Until</label>
                        <input
                          type="datetime-local"
                          className="form-control"
                          value={newItem.activeUntil || ''}
                          onChange={(e) => setNewItem({...newItem, activeUntil: e.target.value})}
                        />
                      </div>
                    )}
                  </div>
                )}

                {activeTab === 'qualifications' && (
                  <div className="mb-3">
                    <label className="form-label">Qualification</label>
                    <select
                      className="form-select"
                      value={newItem.name || ''}
                      onChange={(e) => setNewItem({...newItem, name: e.target.value})}
                    >
                      {qualificationOptions
                        .filter(qual => !userDetails.user.qualifications?.some(userQual => userQual.name === qual))
                        .map(qual => (
                        <option key={qual} value={qual}>{qual}</option>
                      ))}
                    </select>
                    {qualificationOptions.filter(qual => !userDetails.user.qualifications?.some(userQual => userQual.name === qual)).length === 0 && (
                      <div className="text-muted small mt-2">All available qualifications have been granted to this user.</div>
                    )}
                  </div>
                )}

                {activeTab === 'notes' && (
                  <div>
                    <div className="mb-3">
                      <label className="form-label">Note Type</label>
                      <select
                        className="form-select"
                        value={newItem.type || 'general'}
                        onChange={(e) => setNewItem({...newItem, type: e.target.value})}
                      >
                        <option value="general">General</option>
                        <option value="loa">Leave of Absence</option>
                        <option value="performance">Performance</option>
                      </select>
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Content</label>
                      <textarea
                        className="form-control"
                        value={newItem.content || ''}
                        onChange={(e) => setNewItem({...newItem, content: e.target.value})}
                        placeholder="Note content"
                        rows="4"
                      />
                    </div>
                    <div className="form-check">
                      <input
                        type="checkbox"
                        className="form-check-input"
                        checked={newItem.visibleToUser || false}
                        onChange={(e) => setNewItem({...newItem, visibleToUser: e.target.checked})}
                      />
                      <label className="form-check-label">
                        Visible to user
                      </label>
                    </div>
                  </div>
                )}

                {activeTab === 'rewards' && (
                  <div>
                    <div className="mb-3">
                      <label className="form-label">Reward Type</label>
                      <select
                        className="form-select"
                        value={newItem.type || 'bonus'}
                        onChange={(e) => setNewItem({...newItem, type: e.target.value})}
                      >
                        <option value="bonus">Bonus</option>
                        <option value="commission">Commission</option>
                        <option value="incentive">Incentive</option>
                      </select>
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Amount ($)</label>
                      <input
                        type="number"
                        className="form-control"
                        value={newItem.amount || ''}
                        onChange={(e) => setNewItem({...newItem, amount: e.target.value})}
                        placeholder="Reward amount"
                        min="1"
                      />
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Reason</label>
                      <textarea
                        className="form-control"
                        value={newItem.reason || ''}
                        onChange={(e) => setNewItem({...newItem, reason: e.target.value})}
                        placeholder="Reason for the reward"
                        rows="3"
                      />
                    </div>
                  </div>
                )}
              </div>
              <div className="modal-footer">
                <button
                  className="btn btn-secondary"
                  onClick={() => setShowAddModal(false)}
                >
                  Cancel
                </button>
                <button
                  className="btn btn-primary"
                  onClick={handleAddItem}
                  disabled={
                    (activeTab === 'sanctions' && (!newItem.breach || !newItem.reason)) ||
                    (activeTab === 'qualifications' && !newItem.name) ||
                    (activeTab === 'notes' && !newItem.content) ||
                    (activeTab === 'rewards' && (!newItem.amount || !newItem.reason))
                  }
                >
                  <Save size={16} />
                  Add {activeTab === 'sanctions' ? 'Sanction' : 
                       activeTab === 'qualifications' ? 'Qualification' : 
                       activeTab === 'rewards' ? 'Reward' : 'Note'}
                </button>
              </div>
            </div>
          </div>
        )}

        <ConfirmationModal
          isOpen={showConfirmModal && confirmStep === 1}
          onClose={handleCloseConfirm}
          onConfirm={handleConfirmStep1}
          title="⚠️ ADVANCE TERM - CRITICAL ACTION"
          type="warning"
          confirmText="Continue"
          cancelText="Cancel"
          message={`This action will:

• Move ALL users' term flight counts to career totals
• Reset ALL users' term flights to 0
• Reset ALL users' term pay to 0
• Archive ALL concluded/logged flights

🚨 THIS CANNOT BE UNDONE! 🚨

This should only be done at the end of a term period.
Are you absolutely sure you want to continue?`}
        />

        <ConfirmationModal
          isOpen={showConfirmModal && confirmStep === 2}
          onClose={handleCloseConfirm}
          onConfirm={handleConfirmStep2}
          title="FINAL CONFIRMATION"
          type="danger"
          confirmText="ADVANCE TERM"
          cancelText="Cancel"
          message={`You are about to advance the term for ALL users.
This will permanently reset term statistics.

This action is IRREVERSIBLE and will affect all users in the system.

Click "ADVANCE TERM" to proceed or "Cancel" to abort.`}
        />
      </div>
    </div>
  );
};

export default AdminDivision; 