import React, { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery } from 'react-query';
import { 
  User, 
  ArrowLeft, 
  Calendar, 
  Award,
  Plane,
  Clock,
  Star,
  TrendingUp,
  DollarSign,
  MapPin,
  Shield,
  AlertTriangle,
  FileText
} from 'lucide-react';
import axios from 'axios';
import moment from 'moment';
import LoadingSpinner from '../components/LoadingSpinner';

const UserProfile = () => {
  const { id, identifier } = useParams();
  const navigate = useNavigate();


  const { data: lookupData, isLoading: isLookingUp } = useQuery(
    ['userLookup', identifier],
    () => axios.get(`/api/users/lookup/${identifier}`).then(res => res.data),
    {
      enabled: !!identifier && !id,
      refetchOnWindowFocus: true,
      staleTime: 0,
      cacheTime: 0,
      refetchOnMount: 'always'
    }
  );


  useEffect(() => {
    if (lookupData?.userId && identifier) {
      navigate(`/profile/${lookupData.userId}`, { replace: true });
    }
  }, [lookupData, identifier, navigate]);


  const userId = id || lookupData?.userId;

  const { data: user, isLoading, error } = useQuery(
    ['user', userId],
    () => axios.get(`/api/users/${userId}`).then(res => res.data),
    {
      enabled: !!userId,
      refetchOnWindowFocus: true,
      staleTime: 0,
      cacheTime: 0,
      refetchOnMount: 'always'
    }
  );

  if (isLookingUp || (identifier && !lookupData)) return <LoadingSpinner />;
  if (isLoading) return <LoadingSpinner />;
  if (error) return <div className="alert alert-danger">User not found</div>;
  if (!user) return <div className="alert alert-danger">User not found</div>;

  const activeSanctions = user.sanctions?.filter(s => new Date(s.expiryDate) > new Date()) || [];

  const getSanctionBadgeClass = (type) => {
    const classes = {
      'reminder': 'badge-info',
      'warning': 'badge-warning',
      'suspension': 'badge-danger'
    };
    return classes[type] || 'badge-secondary';
  };

  return (
    <div className="container-fluid">
      <div className="mb-4">
        <button
          className="btn btn-ghost d-flex align-items-center gap-2 mb-4"
          onClick={() => navigate(-1)}
        >
          <ArrowLeft size={18} />
          Back
        </button>

        <div className="row">

          <div className="col-lg-4 col-md-6 mb-4">

            <div className="card">
              <div className="card-body text-center">
                {user.robloxAvatarUrl ? (
                  <img
                    src={user.robloxAvatarUrl}
                    alt="Avatar"
                    className="mb-3"
                    style={{ width: '120px', height: '120px' }}
                  />
                ) : (
                  <div className="d-flex align-items-center justify-content-center mb-3" style={{ width: '120px', height: '120px', background: '#f8f9fa' }}>
                    <User size={60} className="text-muted" />
                  </div>
                )}
                <h4 className="mb-1">{user.robloxUsername}</h4>
                {user.robloxDisplayName && user.robloxDisplayName !== user.robloxUsername && (
                  <p className="text-muted mb-2">({user.robloxDisplayName})</p>
                )}
                <div className="d-flex flex-column align-items-center gap-2 mb-3">
                  <div className="badge badge-primary">
                    {user.groupRank?.rankName || 'Unknown Rank'}
                  </div>
                  <div className="d-flex gap-1">
                    {user.isOnLeave && (
                      <span className="badge badge-warning badge-sm">On Leave</span>
                    )}
                    {activeSanctions.some(s => 
                      s.type === 'suspension' && 
                      (!s.activeUntil || new Date(s.activeUntil) > new Date())
                    ) ? (
                      <span className="badge badge-danger badge-sm">Suspended</span>
                    ) : (
                      <span className="badge badge-success badge-sm">Active</span>
                    )}
                  </div>
                </div>
                <div className="text-muted small">
                  Role: {user.role || 'Personnel'}
                </div>
                <div className="text-muted small">
                  Last login: {moment(user.lastLogin).format('MMM DD, YYYY HH:mm')}
                </div>
              </div>
            </div>

            {user.qualifications && user.qualifications.length > 0 && (
              <div className="card">
                <div className="card-header d-flex align-items-center gap-2">
                  <Award size={18} />
                  Qualifications & Certifications
                </div>
                <div className="card-body">
                  <div className="qualification-tags-container">
                    {user.qualifications.map((qual, index) => (
                      <span key={index} className="qualification-tag active">
                        {typeof qual === 'string' ? qual : qual.name || qual}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeSanctions.length > 0 && (
              <div className="card">
                <div className="card-header d-flex align-items-center gap-2">
                  <AlertTriangle size={18} />
                  Active Sanctions ({activeSanctions.length})
                </div>
                <div className="card-body">
                  {activeSanctions.map((sanction, index) => (
                    <div key={index} className="mb-3 last:mb-0">
                      <div className="d-flex justify-content-between align-items-start mb-2">
                        <span className={`badge ${getSanctionBadgeClass(sanction.type)}`}>
                          {sanction.type.charAt(0).toUpperCase() + sanction.type.slice(1)} #{sanction.count}
                        </span>
                        <small className="text-muted">
                          Expires: {moment(sanction.expiryDate).format('MMM DD, YYYY')}
                        </small>
                      </div>
                      <div className="small">
                        <strong>Breach:</strong> {sanction.breach}
                      </div>
                      <div className="small">
                        <strong>Reason:</strong> {sanction.reason}
                      </div>
                      {sanction.comment && (
                        <div className="small">
                          <strong>Comment:</strong> {sanction.comment}
                        </div>
                      )}
                      {sanction.activeUntil && (
                        <div className="small text-danger">
                          <strong>Active until:</strong> {moment(sanction.activeUntil).format('MMM DD, YYYY HH:mm')}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="card">
              <div className="card-header d-flex align-items-center gap-2">
                <Clock size={18} />
                Rank History
              </div>
              <div className="card-body">
                {user.rankHistory && user.rankHistory.length > 0 ? (
                  <div className="rank-progression">
                    {user.rankHistory.slice(-5).reverse().map((entry, index) => (
                      <div key={index} className="rank-entry">
                        <div className="rank-entry-marker">
                          <div className="rank-dot"></div>
                          {index < user.rankHistory.slice(-5).length - 1 && <div className="rank-line"></div>}
                        </div>
                        <div className="rank-entry-content">
                          <div className="rank-entry-header">
                            <h6 className="rank-title">{entry.rankName}</h6>
                            <span className="rank-date">{moment(entry.date).format('MMM DD, YYYY')}</span>
                          </div>
                          <div className="rank-entry-details">
                            <span className={`rank-type rank-type-${entry.type.toLowerCase().replace(/\s+/g, '-')}`}>
                              {entry.type === 'promotion' ? 'Promotion' : 
                               entry.type === 'demotion' ? 'Demotion' : 
                               entry.type === 'qualification' ? 'Qualification' :
                               entry.type === 'transfer' ? 'Transfer' :
                               entry.type.charAt(0).toUpperCase() + entry.type.slice(1)}
                            </span>
                            {entry.promotedBy && (
                              <span className="rank-promoter">
                                by <span 
                                  className="promoter-link" 
                                  onClick={() => window.location.href = `/u/${entry.promotedBy.robloxUsername || 'System'}`}
                                >
                                  @{entry.promotedBy.robloxUsername || 'System'}
                                </span>
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-3 text-muted">
                    <Clock size={32} className="mb-2" />
                    <div>No rank history available</div>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="col-lg-8">

            <div className="row">
              <div className="col-lg-6 col-md-6 mb-3">
                <div className="card stat-card bg-primary text-white">
                  <div className="card-body">
                    <div className="d-flex justify-content-between align-items-center">
                      <div>
                        <h6 className="card-title mb-0">Term Flights Attended</h6>
                        <h3 className="mb-0">{user.stats?.termFlightsAttended || 0}</h3>
                        <small>of {user.stats?.requiredFlights || 0} required</small>
                      </div>
                      <Plane size={32} className="opacity-75" />
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="col-lg-6 col-md-6 mb-3">
                <div className="card stat-card bg-success text-white">
                  <div className="card-body">
                    <div className="d-flex justify-content-between align-items-center">
                      <div>
                        <h6 className="card-title mb-0">Term Flights Hosted</h6>
                        <h3 className="mb-0">{user.stats?.termFlightsHosted || 0}</h3>
                        <small>Dispatcher flights</small>
                      </div>
                      <TrendingUp size={32} className="opacity-75" />
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="col-lg-6 col-md-6 mb-3">
                <div className="card stat-card bg-warning text-dark">
                  <div className="card-body">
                    <div className="d-flex justify-content-between align-items-center">
                      <div>
                        <h6 className="card-title mb-0">Term Pay</h6>
                        <h3 className="mb-0">CHF {(user.stats?.termPay || 0).toLocaleString()}</h3>
                        <small>This term earnings</small>
                      </div>
                      <DollarSign size={32} className="opacity-75" />
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="col-lg-6 col-md-6 mb-3">
                <div className="card stat-card bg-info text-white">
                  <div className="card-body">
                    <div className="d-flex justify-content-between align-items-center">
                      <div>
                        <h6 className="card-title mb-0">Career Statistics</h6>
                        <h3 className="mb-0">{((user.stats?.totalFlightsAttended || 0) + (user.stats?.termFlightsAttended || 0)).toLocaleString()}</h3>
                        <small>Total Attended / Hosted</small>
                      </div>
                      <Star size={32} className="opacity-75" />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="row">

              <div className="col-lg-6 col-md-12 mb-4">
                <div className="card h-100">
                  <div className="card-header d-flex align-items-center gap-2">
                    <Plane size={18} />
                    Recent Flight History
                  </div>
                  <div className="card-body">
                    {user.flightHistory && user.flightHistory.length > 0 ? (
                      <div className="table-responsive">
                        <table className="table table-sm">
                          <thead>
                            <tr>
                              <th>Flight</th>
                              <th>Route</th>
                              <th>Role</th>
                              <th>Date</th>
                            </tr>
                          </thead>
                          <tbody>
                            {user.flightHistory.slice(0, 5).map((flight, index) => (
                              <tr key={index}>
                                <td className="fw-semibold">{flight.flightCode}</td>
                                <td>{flight.route.departure} → {flight.route.arrival}</td>
                                <td>{flight.userRole}</td>
                                <td>{moment(flight.scheduledDate).format('MMM DD')}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    ) : (
                      <div className="text-center py-3 text-muted">
                        <Plane size={32} className="mb-2" />
                        <div>No flight history available</div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="col-lg-6 col-md-12 mb-4">
                <div className="card h-100">
                  <div className="card-header d-flex align-items-center gap-2">
                    <Calendar size={18} />
                    Upcoming Flights
                  </div>
                  <div className="card-body">
                    {user.upcomingFlights && user.upcomingFlights.length > 0 ? (
                      <div className="table-responsive">
                        <table className="table table-sm">
                          <thead>
                            <tr>
                              <th>Flight</th>
                              <th>Route</th>
                              <th>Role</th>
                              <th>Date</th>
                              <th>Assigned By</th>
                            </tr>
                          </thead>
                          <tbody>
                            {user.upcomingFlights.map((flight, index) => (
                              <tr key={index}>
                                <td className="fw-semibold">{flight.flightCode}</td>
                                <td>{flight.route.departure} → {flight.route.arrival}</td>
                                <td>{flight.userRole}</td>
                                <td>{moment(flight.scheduledDate).format('MMM DD, HH:mm')}</td>
                                <td className="text-muted small">
                                  {flight.assignedBy ? (
                                    <span 
                                      className="promoter-link" 
                                      onClick={() => window.location.href = `/u/${flight.assignedBy.robloxUsername}`}
                                    >
                                      @{flight.assignedBy.robloxUsername}
                                    </span>
                                  ) : 'Self-assigned'}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    ) : (
                      <div className="text-center py-4 text-muted">
                        No upcoming flights allocated
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {user.notes && user.notes.filter(note => note.visibleToUser).length > 0 && (
              <div className="row">
                <div className="col-md-12 mb-4">
                  <div className="card">
                    <div className="card-header d-flex align-items-center gap-2">
                      <FileText size={18} />
                      Public Notes
                    </div>
                    <div className="card-body">
                      <div className="notes-list">
                        {user.notes.filter(note => note.visibleToUser).map((note, index) => (
                          <div key={index} className="note-item">
                            <div className="note-content">{note.content}</div>
                            <div className="note-meta">
                              <span className={`badge ${
                                note.type === 'loa' ? 'badge-warning' :
                                note.type === 'performance' ? 'badge-info' : 'badge-secondary'
                              } me-2`}>
                                {note.type}
                              </span>
                              <span className="text-muted small">
                                {moment(note.addedDate).format('MMM DD, YYYY')}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserProfile; 