import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { 
  Plane, 
  Plus, 
  Calendar, 
  Clock, 
  MapPin, 
  Users, 
  Edit3, 
  Check, 
  X, 
  Trash2,
  User,
  AlertCircle,
  CheckCircle,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import axios from 'axios';
import moment from 'moment';
import { toast } from 'react-toastify';
import LoadingSpinner from '../components/LoadingSpinner';

const FlightScheduling = () => {
  const queryClient = useQueryClient();
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [expandedFlight, setExpandedFlight] = useState(null);
  const [flightForm, setFlightForm] = useState({
    flightCode: '',
    route: { departure: '', arrival: '' },
    aircraft: '',
    gate: '',
    scheduledDate: '',
    times: {
      staffJoining: '',
      passengerJoining: '',
      boarding: ''
    },
    serviceCategory: '',
    notes: '',
    roles: [
      { name: 'Captain', capacity: 1 },
      { name: 'Cabin Crew', capacity: 4 }
    ]
  });

  const { data: flightsData, isLoading, error } = useQuery(
    'scheduling-flights',
    () => axios.get('/api/flights/scheduling').then(res => res.data),
    {
      refetchOnWindowFocus: false,
      refetchInterval: 30000
    }
  );

  const { data: authData } = useQuery('auth', 
    () => axios.get('/api/auth/me').then(res => res.data),
    {
      retry: false,
      refetchOnWindowFocus: false
    }
  );

  const createFlightMutation = useMutation(
    (flightData) => axios.post('/api/flights', flightData),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('scheduling-flights');
        setShowCreateForm(false);
        resetForm();
        toast.success('Flight created successfully');
      },
      onError: (error) => {
        toast.error(error.response?.data?.message || 'Failed to create flight');
      }
    }
  );

  const approveFlightMutation = useMutation(
    (flightId) => axios.put(`/api/flights/${flightId}/approve`),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('scheduling-flights');
        toast.success('Flight approved');
      },
      onError: (error) => {
        toast.error(error.response?.data?.message || 'Failed to approve flight');
      }
    }
  );

  const rejectFlightMutation = useMutation(
    (flightId) => axios.put(`/api/flights/${flightId}/reject`),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('scheduling-flights');
        toast.success('Flight rejected');
      },
      onError: (error) => {
        toast.error(error.response?.data?.message || 'Failed to reject flight');
      }
    }
  );

  const deleteFlightMutation = useMutation(
    (flightId) => axios.delete(`/api/flights/${flightId}`),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('scheduling-flights');
        toast.success('Flight deleted');
      },
      onError: (error) => {
        toast.error(error.response?.data?.message || 'Failed to delete flight');
      }
    }
  );

  const reviewFlightMutation = useMutation(
    ({ flightId, points }) => axios.put(`/api/flights/${flightId}/review`, { points }),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('scheduling-flights');
        toast.success('Flight reviewed and points awarded');
      },
      onError: (error) => {
        toast.error(error.response?.data?.message || 'Failed to review flight');
      }
    }
  );

  const resetForm = () => {
    setFlightForm({
      flightCode: '',
      route: { departure: '', arrival: '' },
      aircraft: '',
      gate: '',
      scheduledDate: '',
      times: {
        staffJoining: '',
        passengerJoining: '',
        boarding: ''
      },
      serviceCategory: '',
      notes: '',
      roles: [
        { name: 'Captain', capacity: 1 },
        { name: 'Cabin Crew', capacity: 4 }
      ]
    });
  };

  const handleCreateFlight = () => {
    if (!flightForm.flightCode || !flightForm.route.departure || !flightForm.route.arrival || 
        !flightForm.aircraft || !flightForm.scheduledDate || !flightForm.times.staffJoining ||
        !flightForm.times.passengerJoining || !flightForm.times.boarding) {
      toast.error('Please fill in all required fields');
      return;
    }

    const flightData = {
      ...flightForm,
      scheduledDate: new Date(flightForm.scheduledDate),
      times: {
        staffJoining: new Date(flightForm.times.staffJoining),
        passengerJoining: new Date(flightForm.times.passengerJoining),
        boarding: new Date(flightForm.times.boarding)
      }
    };

    createFlightMutation.mutate(flightData);
  };

  const addRole = () => {
    setFlightForm({
      ...flightForm,
      roles: [...flightForm.roles, { name: '', capacity: 1 }]
    });
  };

  const updateRole = (index, field, value) => {
    const updatedRoles = [...flightForm.roles];
    updatedRoles[index][field] = value;
    setFlightForm({ ...flightForm, roles: updatedRoles });
  };

  const removeRole = (index) => {
    const updatedRoles = flightForm.roles.filter((_, i) => i !== index);
    setFlightForm({ ...flightForm, roles: updatedRoles });
  };

  const canApprove = authData?.user && authData.user.groupRank && authData.user.groupRank.rankId >= 247;
  const canReview = authData?.user && authData.user.groupRank && authData.user.groupRank.rankId >= 247;

  if (isLoading) return <LoadingSpinner />;
  if (error) return <div className="alert alert-danger">Failed to load flights</div>;

  const { pending = [], approved = [], concluded = [] } = flightsData || {};

  const FlightCard = ({ flight, column }) => (
    <div className="card mb-3 border">
      <div className="card-body p-3">
        <div className="d-flex justify-content-between align-items-start mb-2">
          <h6 className="mb-0 text-primary">{flight.flightCode}</h6>
          <div className="d-flex align-items-center gap-1">
            <span className={`badge badge-sm ${
              flight.approvalStatus === 'pending' ? 'badge-warning' :
              flight.approvalStatus === 'approved' ? 'badge-success' :
              'badge-danger'
            }`}>
              {flight.approvalStatus}
            </span>
            {flight.status && (
              <span className="badge badge-info badge-sm">
                {flight.status}
              </span>
            )}
          </div>
        </div>
        
        <div className="small mb-2">
          <div className="d-flex align-items-center gap-1 mb-1">
            <MapPin size={12} />
            <span>{flight.route.departure} → {flight.route.arrival}</span>
          </div>
          <div className="d-flex align-items-center gap-1 mb-1">
            <Plane size={12} />
            <span>{flight.aircraft}</span>
          </div>
          <div className="d-flex align-items-center gap-1 mb-1">
            <Calendar size={12} />
            <span>{moment(flight.scheduledDate).format('MMM DD, YYYY HH:mm')}</span>
          </div>
          <div className="d-flex align-items-center gap-1 mb-1">
            <User size={12} />
            <span>@{flight.dispatcherUsername}</span>
          </div>
          {flight.gate && (
            <div className="d-flex align-items-center gap-1">
              <MapPin size={12} />
              <span>Gate {flight.gate}</span>
            </div>
          )}
        </div>

        <div className="d-flex align-items-center gap-1 mb-2">
          <Users size={12} />
          <span className="small">
            {flight.assignedSlots || 0}/{flight.totalSlots || 0} allocated
          </span>
        </div>

        <div className="d-flex flex-wrap gap-1">
          {column === 'pending' && canApprove && (
            <>
              <button
                className="btn btn-success btn-sm d-flex align-items-center gap-1"
                onClick={() => approveFlightMutation.mutate(flight._id)}
                disabled={approveFlightMutation.isLoading}
                style={{ fontSize: '0.7rem' }}
              >
                <Check size={12} />
                Approve
              </button>
              <button
                className="btn btn-danger btn-sm d-flex align-items-center gap-1"
                onClick={() => rejectFlightMutation.mutate(flight._id)}
                disabled={rejectFlightMutation.isLoading}
                style={{ fontSize: '0.7rem' }}
              >
                <X size={12} />
                Reject
              </button>
            </>
          )}

          {column === 'concluded' && canReview && flight.status === 'CONCLUDED' && !flight.reviewedAt && (
            <button
              className="btn btn-primary btn-sm d-flex align-items-center gap-1"
              onClick={() => {
                const points = prompt('Enter points to award (default: attended=1, hosted=2):');
                if (points !== null) {
                  reviewFlightMutation.mutate({ 
                    flightId: flight._id, 
                    points: points ? JSON.parse(points) : undefined 
                  });
                }
              }}
              disabled={reviewFlightMutation.isLoading}
              style={{ fontSize: '0.7rem' }}
            >
              <CheckCircle size={12} />
              Review & Award Points
            </button>
          )}

          {(flight.dispatcher._id === authData?.user?.userId || canApprove) && (
            <button
              className="btn btn-ghost btn-sm d-flex align-items-center gap-1"
              onClick={() => setExpandedFlight(expandedFlight === flight._id ? null : flight._id)}
              style={{ fontSize: '0.7rem' }}
            >
              {expandedFlight === flight._id ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
              Details
            </button>
          )}

          {flight.dispatcher._id === authData?.user?.userId && flight.approvalStatus === 'pending' && (
            <button
              className="btn btn-danger btn-sm d-flex align-items-center gap-1"
              onClick={() => {
                if (window.confirm('Are you sure you want to delete this flight?')) {
                  deleteFlightMutation.mutate(flight._id);
                }
              }}
              disabled={deleteFlightMutation.isLoading}
              style={{ fontSize: '0.7rem' }}
            >
              <Trash2 size={12} />
              Delete
            </button>
          )}
        </div>

        {expandedFlight === flight._id && (
          <div className="mt-3 pt-3 border-top">
            <div className="small">
              <div className="mb-2">
                <strong>Times:</strong>
                <div>Staff: {moment(flight.times.staffJoining).format('HH:mm')}</div>
                <div>Passengers: {moment(flight.times.passengerJoining).format('HH:mm')}</div>
                <div>Boarding: {moment(flight.times.boarding).format('HH:mm')}</div>
              </div>
              
              {flight.serviceCategory && (
                <div className="mb-2">
                  <strong>Service Category:</strong> {flight.serviceCategory}
                </div>
              )}

              <div className="mb-2">
                <strong>Roles:</strong>
                {flight.roles.map((role, index) => (
                  <div key={index}>
                    {role.name}: {role.assigned?.length || 0}/{role.capacity}
                  </div>
                ))}
              </div>

              {flight.notes && (
                <div className="mb-2">
                  <strong>Notes:</strong>
                  <div className="text-muted">{flight.notes}</div>
                </div>
              )}

              {flight.reviewedAt && (
                <div className="text-success small">
                  <CheckCircle size={12} className="me-1" />
                  Reviewed by @{flight.reviewedBy?.robloxUsername || 'Unknown'} on {moment(flight.reviewedAt).format('MMM DD, HH:mm')}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="container-fluid">
      <div className="mb-4">
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h1 className="h2 mb-0 d-flex align-items-center gap-2">
            <Calendar size={24} />
            Flight Scheduling
          </h1>
          <button
            className="btn btn-primary d-flex align-items-center gap-2"
            onClick={() => setShowCreateForm(true)}
          >
            <Plus size={18} />
            Create Flight
          </button>
        </div>

        {showCreateForm && (
          <div className="card mb-4">
            <div className="card-header d-flex justify-content-between align-items-center">
              <h5 className="mb-0">Create New Flight</h5>
              <button
                className="btn btn-ghost btn-sm"
                onClick={() => setShowCreateForm(false)}
              >
                <X size={16} />
              </button>
            </div>
            <div className="card-body">
              <div className="row mx-0">
                <div className="col-md-6 px-3">
                  <div className="mb-3">
                    <label className="form-label">Flight Code*</label>
                    <input
                      type="text"
                      className="form-control"
                      value={flightForm.flightCode}
                      onChange={(e) => setFlightForm({...flightForm, flightCode: e.target.value})}
                      placeholder="LX 340"
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Route*</label>
                    <div className="row mx-0">
                      <div className="col-6 px-2">
                        <label className="form-label small text-muted">From*</label>
                        <input
                          type="text"
                          className="form-control"
                          value={flightForm.route.departure}
                          onChange={(e) => setFlightForm({
                            ...flightForm, 
                            route: {...flightForm.route, departure: e.target.value}
                          })}
                          placeholder="Zurich"
                        />
                      </div>
                      <div className="col-6 px-2">
                        <label className="form-label small text-muted">To*</label>
                        <input
                          type="text"
                          className="form-control"
                          value={flightForm.route.arrival}
                          onChange={(e) => setFlightForm({
                            ...flightForm, 
                            route: {...flightForm.route, arrival: e.target.value}
                          })}
                          placeholder="Istanbul"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Aircraft*</label>
                    <input
                      type="text"
                      className="form-control"
                      value={flightForm.aircraft}
                      onChange={(e) => setFlightForm({...flightForm, aircraft: e.target.value})}
                      placeholder="Airbus A320"
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Gate</label>
                    <input
                      type="text"
                      className="form-control"
                      value={flightForm.gate}
                      onChange={(e) => setFlightForm({...flightForm, gate: e.target.value})}
                      placeholder="31A"
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Service Category</label>
                    <input
                      type="text"
                      className="form-control"
                      value={flightForm.serviceCategory}
                      onChange={(e) => setFlightForm({...flightForm, serviceCategory: e.target.value})}
                      placeholder="Business/Economy"
                    />
                  </div>
                </div>

                <div className="col-md-6 px-3">
                  <div className="mb-3">
                    <label className="form-label">Scheduled Date*</label>
                    <input
                      type="datetime-local"
                      className="form-control"
                      value={flightForm.scheduledDate}
                      onChange={(e) => setFlightForm({...flightForm, scheduledDate: e.target.value})}
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Staff Joining Time*</label>
                    <input
                      type="datetime-local"
                      className="form-control"
                      value={flightForm.times.staffJoining}
                      onChange={(e) => setFlightForm({
                        ...flightForm, 
                        times: {...flightForm.times, staffJoining: e.target.value}
                      })}
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Passenger Joining Time*</label>
                    <input
                      type="datetime-local"
                      className="form-control"
                      value={flightForm.times.passengerJoining}
                      onChange={(e) => setFlightForm({
                        ...flightForm, 
                        times: {...flightForm.times, passengerJoining: e.target.value}
                      })}
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Boarding Time*</label>
                    <input
                      type="datetime-local"
                      className="form-control"
                      value={flightForm.times.boarding}
                      onChange={(e) => setFlightForm({
                        ...flightForm, 
                        times: {...flightForm.times, boarding: e.target.value}
                      })}
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Notes</label>
                    <textarea
                      className="form-control"
                      rows="3"
                      value={flightForm.notes}
                      onChange={(e) => setFlightForm({...flightForm, notes: e.target.value})}
                      placeholder="Additional flight information..."
                    />
                  </div>
                </div>
              </div>

              <div className="mb-3">
                <div className="d-flex justify-content-between align-items-center mb-2">
                  <label className="form-label mb-0">Roles & Capacity</label>
                  <button
                    type="button"
                    className="btn btn-outline btn-sm d-flex align-items-center gap-1"
                    onClick={addRole}
                  >
                    <Plus size={14} />
                    Add Role
                  </button>
                </div>

                {flightForm.roles.map((role, index) => (
                  <div key={index} className="row mx-0 align-items-center mb-2">
                    <div className="col-6 px-2">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Role name"
                        value={role.name}
                        onChange={(e) => updateRole(index, 'name', e.target.value)}
                      />
                    </div>
                    <div className="col-4 px-2">
                      <input
                        type="number"
                        className="form-control"
                        placeholder="Capacity"
                        min="1"
                        value={role.capacity}
                        onChange={(e) => updateRole(index, 'capacity', parseInt(e.target.value) || 1)}
                      />
                    </div>
                    <div className="col-2 px-2">
                      <button
                        type="button"
                        className="btn btn-danger btn-sm"
                        onClick={() => removeRole(index)}
                        disabled={flightForm.roles.length <= 1}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="d-flex gap-2">
                <button
                  className="btn btn-primary d-flex align-items-center gap-2"
                  onClick={handleCreateFlight}
                  disabled={createFlightMutation.isLoading}
                >
                  <Plane size={16} />
                  Create Flight
                </button>
                <button
                  className="btn btn-ghost"
                  onClick={() => setShowCreateForm(false)}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="row">
        <div className="col-lg-4">
          <div className="card h-100">
            <div className="card-header d-flex align-items-center gap-2">
              <AlertCircle size={18} className="text-warning" />
              <h6 className="mb-0">Pending Approval</h6>
              <span className="badge badge-warning">{pending.length}</span>
            </div>
            <div className="card-body" style={{ minHeight: '500px', maxHeight: '80vh', overflowY: 'auto' }}>
              {pending.length > 0 ? (
                pending.map(flight => (
                  <FlightCard key={flight._id} flight={flight} column="pending" />
                ))
              ) : (
                <div className="text-center text-muted py-4">
                  <AlertCircle size={32} className="opacity-50 mb-2" />
                  <div>No flights pending approval</div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="col-lg-4">
          <div className="card h-100">
            <div className="card-header d-flex align-items-center gap-2">
              <CheckCircle size={18} className="text-success" />
              <h6 className="mb-0">Approved & Active</h6>
              <span className="badge badge-success">{approved.length}</span>
            </div>
            <div className="card-body" style={{ minHeight: '500px', maxHeight: '80vh', overflowY: 'auto' }}>
              {approved.length > 0 ? (
                approved.map(flight => (
                  <FlightCard key={flight._id} flight={flight} column="approved" />
                ))
              ) : (
                <div className="text-center text-muted py-4">
                  <CheckCircle size={32} className="opacity-50 mb-2" />
                  <div>No approved flights</div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="col-lg-4">
          <div className="card h-100">
            <div className="card-header d-flex align-items-center gap-2">
              <Plane size={18} className="text-info" />
              <h6 className="mb-0">Concluded</h6>
              <span className="badge badge-info">{concluded.length}</span>
            </div>
            <div className="card-body" style={{ minHeight: '500px', maxHeight: '80vh', overflowY: 'auto' }}>
              {concluded.length > 0 ? (
                concluded.map(flight => (
                  <FlightCard key={flight._id} flight={flight} column="concluded" />
                ))
              ) : (
                <div className="text-center text-muted py-4">
                  <Plane size={32} className="opacity-50 mb-2" />
                  <div>No concluded flights</div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FlightScheduling; 