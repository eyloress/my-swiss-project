import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { LogIn, AlertCircle } from 'lucide-react';
import { toast } from 'react-toastify';
import SuspensionModal from '../components/SuspensionModal';

const Login = () => {
  const [searchParams] = useSearchParams();
  const [suspensionData, setSuspensionData] = useState(null);
  const error = searchParams.get('error');
  const suspended = searchParams.get('suspended');

  useEffect(() => {
    if (suspended === 'true') {
      const storedSuspensionData = localStorage.getItem('suspensionData');
      if (storedSuspensionData) {
        try {
          const parsedData = JSON.parse(storedSuspensionData);
          setSuspensionData(parsedData);
          localStorage.removeItem('suspensionData');
        } catch (e) {
          console.error('Failed to parse suspension data:', e);
        }
      }
    }

    if (error) {
      let message = 'Authentication failed';
      
      switch (error) {
        case 'access_denied':
          message = 'Authentication was cancelled';
          break;
        case 'not_in_group':
          message = 'You are not a member of the SWISS Airlines group';
          break;
        case 'insufficient_rank':
          message = 'Your rank is insufficient to access this portal';
          break;
        case 'oauth_failed':
          message = 'Authentication failed. Please try again';
          break;
        default:
          message = 'An error occurred during authentication';
      }
      
      toast.error(message);
    }
  }, [error, suspended]);

  const handleLogin = () => {
    const apiUrl = process.env.REACT_APP_API_URL || 'http://localhost:5000';
    window.location.href = `${apiUrl}/api/auth/roblox`;
  };

  return (
    <>

      {suspensionData && (
        <SuspensionModal 
          suspension={suspensionData} 
          onClose={() => setSuspensionData(null)}
        />
      )}
      
      <div 
        className="d-flex align-items-center justify-content-center"
        style={{
          background: 'linear-gradient(135deg, var(--swiss-light-gray) 0%, #e9ecef 100%)',
          minHeight: '100vh',
          padding: '2rem 1rem'
        }}
      >
      <div className="w-100" style={{ maxWidth: '600px' }}>
        <div className="card shadow-lg border-0">
          <div className="card-body" style={{ padding: '3rem 3rem 2rem 3rem' }}>
            <div className="text-center mb-4">
              <div className="logo-container justify-content-center mb-4" style={{ gap: '0.25rem' }}>
                <img
                  src="/swiss-logo.svg"
                  alt="SWISS Airlines Logo"
                  className="logo-svg"
                  style={{ height: '48px' }}
                />
                <div 
                  className="d-inline-block"
                  style={{ 
                    color: 'var(--swiss-red)',
                    fontSize: '2rem',
                    fontWeight: '700',
                    letterSpacing: '2px'
                  }}
                >
                  SWISS
                </div>
              </div>
              <h2 className="h3 mb-3 mt-3">Staff Portal</h2>
              <p className="text-muted mb-3">
                Secure access for airline personnel
              </p>
            </div>

            {error && (
              <div 
                className="alert d-flex align-items-center mb-4"
                style={{
                  backgroundColor: 'var(--swiss-red-light)',
                  border: '2px solid var(--swiss-red)',
                  color: 'var(--swiss-red)',
                  padding: '1rem'
                }}
              >
                <AlertCircle size={18} className="me-2" />
                <small>
                  Authentication failed. Please check your permissions and try again.
                </small>
              </div>
            )}

            <button
              onClick={handleLogin}
              className="btn btn-primary btn-lg d-flex align-items-center justify-content-center gap-3 w-100"
              style={{ 
                minHeight: '56px',
                fontSize: '1.1rem',
                fontWeight: '600'
              }}
            >
              <LogIn size={24} />
              Log in with Roblox
            </button>
          </div>
          
          <div className="card-footer bg-light text-center py-4">
            <small className="text-muted">
              You'll be redirected to the Roblox login page
            </small>
          </div>
        </div>
      </div>
    </div>
    </>
  );
};

export default Login; 