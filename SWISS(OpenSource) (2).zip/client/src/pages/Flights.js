import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { Link } from 'react-router-dom';
import { Plane, Users, Calendar, ChevronLeft, ChevronRight } from 'lucide-react';
import axios from 'axios';
import moment from 'moment';
import { toast } from 'react-toastify';
import LoadingSpinner from '../components/LoadingSpinner';

const Flights = () => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const queryClient = useQueryClient();

  const { data: flightsData, isLoading, error } = useQuery(
    ['flights', currentDate],
    () => axios.get(`/api/flights/week?date=${currentDate.toISOString()}`).then(res => res.data),
    {
      refetchOnWindowFocus: false
    }
  );

  const allocateMutation = useMutation(
    ({ flightId, roleIndex }) => 
      axios.post(`/api/flights/${flightId}/allocate`, { roleIndex }),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(['flights']);
        toast.success('Successfully allocated to flight');
      },
      onError: (error) => {
        toast.error(error.response?.data?.message || 'Failed to allocate to flight');
      }
    }
  );

    const unallocateMutation = useMutation(
    (flightId) =>
      axios.delete(`/api/flights/${flightId}/unallocate`),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(['flights']);
        toast.success('Successfully unallocated from flight');
      },
      onError: (error) => {
        toast.error(error.response?.data?.message || 'Failed to unallocate from flight');
      }
    }
  );

  const getStatusBadgeClass = (status) => {
    const classes = {
      'SCHEDULED': 'badge-secondary',
      'AVAILABLE': 'badge-success',
      'BRIEFING': 'badge-warning',
      'IN PROGRESS': 'badge-info',
      'CONCLUDED': 'badge-primary',
      'CANCELLED': 'badge-danger',
      'LOGGED': 'badge-success'
    };
    return classes[status] || 'badge-secondary';
  };

  const navigateWeek = (direction) => {
    const newDate = new Date(currentDate);
    newDate.setDate(newDate.getDate() + (direction * 7));
    setCurrentDate(newDate);
  };

  if (isLoading) return <LoadingSpinner />;
  if (error) return <div className="alert alert-danger">Failed to load flights</div>;

  const { flights, weekStart } = flightsData;
  const weekEnd = moment(weekStart).add(6, 'days');

  return (
    <div className="container-fluid">
      <div className="mb-4">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <h1 className="h2 mb-0 d-flex align-items-center gap-2">
            <Plane size={24} className="d-none d-md-inline" />
            <span className="d-none d-md-inline">Flight Schedule</span>
            <span className="d-md-none">Flights</span>
          </h1>
        </div>
        
        <div className="d-flex align-items-center justify-content-center gap-2 gap-md-4 mb-4">
          <button
            className="btn btn-outline d-flex align-items-center gap-1"
            onClick={() => navigateWeek(-1)}
            style={{ minWidth: '80px' }}
          >
            <ChevronLeft size={16} />
            <span className="d-none d-sm-inline">Previous</span>
            <span className="d-sm-none">Prev</span>
          </button>
          
          <div className="text-center px-2">
            <div className="fw-semibold" style={{ fontSize: '0.9rem' }}>
              {moment(weekStart).format('MMM DD')} - {weekEnd.format('MMM DD, YYYY')}
            </div>
            <small className="text-muted d-none d-md-block">Week View</small>
          </div>
          
          <button
            className="btn btn-outline d-flex align-items-center gap-1"
            onClick={() => navigateWeek(1)}
            style={{ minWidth: '80px' }}
          >
            <span className="d-none d-sm-inline">Next</span>
            <span className="d-sm-none">Next</span>
            <ChevronRight size={16} />
          </button>
        </div>
      </div>

      <div className="row flights-container">
        {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map((day, index) => (
          <div key={day} className="col-lg mb-4">
            <div className="card h-100">
              <div className="card-header text-center">
                <h6 className="mb-0">{day}</h6>
                <small className="text-muted">
                  {moment(weekStart).add(index, 'days').format('MMM DD')}
                </small>
              </div>
              <div className="card-body p-2" style={{ minHeight: '400px' }}>
                {flights[day] && flights[day].length > 0 ? (
                  <div className="d-flex flex-column gap-2">
                    {flights[day].map((flight) => (
                      <div key={flight._id} className="card border">
                        <div className="card-body p-3">
                          <div className="d-flex justify-content-between align-items-start mb-2">
                            <h6 className="mb-0 text-primary">{flight.flightCode}</h6>
                            <span className={`badge ${getStatusBadgeClass(flight.status)} badge-sm`}>
                              {flight.status}
                            </span>
                          </div>
                          
                          <div className="small mb-2">
                            <div className="fw-semibold">
                              {flight.route.departure} → {flight.route.arrival}
                            </div>
                            <div className="text-muted">
                              {moment(flight.scheduledDate).format('HH:mm')} • {flight.aircraft}
                            </div>
                            <div className="text-muted">
                              Dispatcher: {flight.dispatcherUsername}
                            </div>
                          </div>
                          
                          <div className="d-flex align-items-center justify-content-between mb-2">
                            <div className="d-flex align-items-center gap-1">
                              <Users size={14} />
                              <span className="small">
                                {flight.assignedSlots}/{flight.totalSlots}
                              </span>
                            </div>
                            
                            {flight.isUserAssigned && (
                              <span className="badge badge-info badge-sm">
                                Allocated
                              </span>
                            )}
                          </div>
                          
                          <div className="d-flex gap-1">
                            {flight.status === 'AVAILABLE' && !flight.isUserAssigned && (
                              <Link
                                to={`/flights/${flight._id}`}
                                className="btn btn-primary btn-sm flex-grow-1"
                                style={{ fontSize: '0.7rem' }}
                              >
                                View & Allocate
                              </Link>
                            )}
                            
                            {flight.isUserAssigned && ['AVAILABLE', 'BRIEFING'].includes(flight.status) && (
                              <button
                                className="btn btn-outline btn-sm flex-grow-1"
                                style={{ fontSize: '0.7rem' }}
                                                        onClick={() => unallocateMutation.mutate(flight._id)}
                        disabled={unallocateMutation.isLoading}
                      >
                        Unallocate
                              </button>
                            )}
                            
                            <Link
                              to={`/flights/${flight._id}`}
                              className="btn btn-ghost btn-sm"
                              style={{ fontSize: '0.7rem' }}
                            >
                              Details
                            </Link>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center text-muted py-4">
                    <Plane size={32} className="opacity-50 mb-2" />
                    <div>No flights scheduled</div>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Flights; 