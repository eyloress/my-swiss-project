import React from 'react';
import { useQuery } from 'react-query';
import { 
  User, 
  Calendar, 
  Award, 
  AlertTriangle, 
  DollarSign, 
  Clock,
  Plane,
  TrendingUp
} from 'lucide-react';
import axios from 'axios';
import moment from 'moment';
import LoadingSpinner from '../components/LoadingSpinner';
import FlightHistoryCard from '../components/FlightHistoryCard';

const Profile = () => {
  const { data: profileData, isLoading, error } = useQuery(
    'profile',
    () => axios.get('/api/users/profile').then(res => res.data),
    {
      refetchOnWindowFocus: true,
      staleTime: 0,
      cacheTime: 0,
      refetchOnMount: 'always'
    }
  );

  if (isLoading) return <LoadingSpinner />;
  if (error) return <div className="alert alert-danger">Failed to load profile</div>;

  const { user, upcomingFlights, flightHistory, nextQuotaReset } = profileData;

  const getStatusBadgeClass = (status) => {
    const classes = {
      'SCHEDULED': 'badge-secondary',
      'AVAILABLE': 'badge-success',
      'BRIEFING': 'badge-warning',
      'IN PROGRESS': 'badge-info',
      'CONCLUDED': 'badge-primary',
      'CANCELLED': 'badge-danger',
      'LOGGED': 'badge-success'
    };
    return classes[status] || 'badge-secondary';
  };

  const getSanctionBadgeClass = (type) => {
    const classes = {
      'reminder': 'badge-info',
      'warning': 'badge-warning',
      'suspension': 'badge-danger'
    };
    return classes[type] || 'badge-secondary';
  };

  return (
    <div className="container-fluid">
      <div className="mb-4">
        <div className="d-flex justify-content-between align-items-center flex-wrap gap-2">
          <h1 className="h2 mb-0">
            <span className="d-none d-md-inline">Profile Dashboard</span>
            <span className="d-md-none">Profile</span>
          </h1>
        </div>
      </div>

      <div className="row">
        <div className="col-lg-4 col-md-6 mb-4">
          <div className="card">
            <div className="card-body text-center">
              {user.robloxAvatarUrl && (
                <img
                  src={user.robloxAvatarUrl}
                  alt="Avatar"
                  className="mb-3"
                  style={{ width: '120px', height: '120px' }}
                />
              )}
              <h4 className="mb-1">{user.robloxUsername}</h4>
              {user.robloxDisplayName && user.robloxDisplayName !== user.robloxUsername && (
                <p className="text-muted mb-2">({user.robloxDisplayName})</p>
              )}
              <div className="badge badge-primary mb-3">
                {user.groupRank.rankName}
              </div>
              <div className="text-muted small">
                Role: {user.role}
              </div>
              <div className="text-muted small">
                Last login: {moment(user.lastLogin).format('MMM DD, YYYY HH:mm')}
              </div>
            </div>
          </div>

          {user.qualifications && user.qualifications.length > 0 && (
            <div className="card">
              <div className="card-header d-flex align-items-center gap-2">
                <Award size={18} />
                Qualifications & Certifications
              </div>
              <div className="card-body">
                <div className="qualification-tags-container">
                  {user.qualifications.map((qual, index) => (
                    <span key={index} className="qualification-tag active">
                      {qual.name}
                    </span>
                  ))}
                </div>
                {user.qualifications.length === 0 && (
                  <div className="text-center py-3 text-muted">
                    No qualifications earned yet
                  </div>
                )}
              </div>
            </div>
          )}

          {user.sanctions && user.sanctions.length > 0 && (
            <div className="card">
              <div className="card-header d-flex align-items-center gap-2">
                <AlertTriangle size={18} />
                Active Sanctions ({user.sanctions.length})
              </div>
              <div className="card-body">
                {user.sanctions.map((sanction, index) => (
                  <div key={index} className="mb-3 last:mb-0">
                    <div className="d-flex justify-content-between align-items-start mb-2">
                      <span className={`badge ${getSanctionBadgeClass(sanction.type)}`}>
                        {sanction.type.charAt(0).toUpperCase() + sanction.type.slice(1)} #{sanction.count}
                      </span>
                      <small className="text-muted">
                        Expires: {moment(sanction.expiryDate).format('MMM DD, YYYY')}
                      </small>
                    </div>
                    <div className="small">
                      <strong>Breach:</strong> {sanction.breach}
                    </div>
                    <div className="small">
                      <strong>Reason:</strong> {sanction.reason}
                    </div>
                    {sanction.comment && (
                      <div className="small">
                        <strong>Comment:</strong> {sanction.comment}
                      </div>
                    )}
                    {sanction.activeUntil && (
                      <div className="small text-danger">
                        <strong>Active until:</strong> {moment(sanction.activeUntil).format('MMM DD, YYYY HH:mm')}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="card">
            <div className="card-header d-flex align-items-center gap-2">
              <Clock size={18} />
              Rank History
            </div>
            <div className="card-body">
              {user.rankHistory && user.rankHistory.length > 0 ? (
                <div className="rank-progression">
                  {user.rankHistory.slice(-5).reverse().map((entry, index) => (
                    <div key={index} className="rank-entry">
                      <div className="rank-entry-marker">
                        <div className="rank-dot"></div>
                        {index < user.rankHistory.slice(-5).length - 1 && <div className="rank-line"></div>}
                      </div>
                      <div className="rank-entry-content">
                        <div className="rank-entry-header">
                          <h6 className="rank-title">{entry.rankName}</h6>
                          <span className="rank-date">{moment(entry.date).format('MMM DD, YYYY')}</span>
                        </div>
                        <div className="rank-entry-details">
                          <span className={`rank-type rank-type-${entry.type.toLowerCase().replace(/\s+/g, '-')}`}>
                            {entry.type === 'promotion' ? 'Promotion' : 
                             entry.type === 'demotion' ? 'Demotion' : 
                             entry.type === 'qualification' ? 'Qualification' :
                             entry.type === 'transfer' ? 'Transfer' :
                             entry.type.charAt(0).toUpperCase() + entry.type.slice(1)}
                          </span>
                          {entry.promotedBy && (
                            <span className="rank-promoter">
                              by <span 
                                className="promoter-link" 
                                onClick={() => window.location.href = `/u/${entry.promotedBy.robloxUsername || 'System'}`}
                              >
                                @{entry.promotedBy.robloxUsername || 'System'}
                              </span>
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-3 text-muted">
                  <Clock size={32} className="mb-2" />
                  <div>No rank history available</div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="col-lg-8">
          <div className="row">
            <div className="col-lg-6 col-md-6 mb-3">
              <div className="card stat-card bg-primary text-white">
                <div className="card-body">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <h6 className="card-title mb-0">Term Flights Attended</h6>
                      <h3 className="mb-0">{user.stats.termFlightsAttended}</h3>
                      <small>of {user.stats.requiredFlights} required</small>
                    </div>
                    <Plane size={32} className="opacity-75" />
                  </div>
                </div>
              </div>
            </div>
            
            <div className="col-lg-6 col-md-6 mb-3">
              <div className="card stat-card bg-success text-white">
                <div className="card-body">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <h6 className="card-title mb-0">Term Flights Hosted</h6>
                      <h3 className="mb-0">{user.stats.termFlightsHosted}</h3>
                      <small>Dispatcher flights</small>
                    </div>
                    <TrendingUp size={32} className="opacity-75" />
                  </div>
                </div>
              </div>
            </div>
            
            <div className="col-lg-6 col-md-6 mb-3">
              <div className="card stat-card bg-warning text-dark">
                <div className="card-body">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <h6 className="card-title mb-0">Term Pay</h6>
                      <h3 className="mb-0">CHF {user.stats.termPay.toLocaleString()}</h3>
                      <small>This term earnings</small>
                    </div>
                    <DollarSign size={32} className="opacity-75" />
                  </div>
                </div>
              </div>
            </div>
            
            <div className="col-lg-6 col-md-6 mb-3">
              <div className="card stat-card bg-info text-white">
                <div className="card-body">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <h6 className="card-title mb-0">Quota Reset</h6>
                      <h3 className="mb-0 small">{moment(nextQuotaReset).fromNow()}</h3>
                      <small>{moment(nextQuotaReset).format('MMM DD, YYYY')}</small>
                    </div>
                    <Clock size={32} className="opacity-75" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-lg-6 col-md-12 mb-4">
              <div className="card h-100">
                <div className="card-header d-flex align-items-center gap-2">
                  <Plane size={18} />
                  Recent Flight History
                </div>
                <div className="card-body">
                  {flightHistory && flightHistory.length > 0 ? (
                    <div>
                      {flightHistory.slice(0, 3).map((flight, index) => (
                        <FlightHistoryCard key={index} flight={flight} />
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-3 text-muted">
                      <Plane size={32} className="mb-2" />
                      <div>No flight history available</div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="col-lg-6 col-md-12 mb-4">
              <div className="card h-100">
                <div className="card-header d-flex align-items-center gap-2">
                  <Calendar size={18} />
                  Upcoming Flights
                </div>
                <div className="card-body">
                  {upcomingFlights && upcomingFlights.length > 0 ? (
                    <div className="table-responsive">
                      <table className="table table-sm">
                        <thead>
                          <tr>
                            <th>Flight</th>
                            <th>Route</th>
                            <th>Date & Time</th>
                            <th>Role</th>
                            <th>Assigned By</th>
                          </tr>
                        </thead>
                        <tbody>
                          {upcomingFlights.map((flight, index) => (
                            <tr key={index}>
                              <td className="fw-semibold">{flight.flightCode}</td>
                              <td>{flight.route.departure} - {flight.route.arrival}</td>
                              <td>{moment(flight.scheduledDate).format('MMM DD, HH:mm')}</td>
                              <td>
                                <span className="badge badge-secondary">
                                  {flight.userRole || 'Passenger'}
                                </span>
                              </td>
                              <td className="text-muted small">
                                {flight.assignedBy ? (
                                  <span 
                                    className="promoter-link" 
                                    onClick={() => window.location.href = `/u/${flight.assignedBy.robloxUsername}`}
                                  >
                                    @{flight.assignedBy.robloxUsername}
                                  </span>
                                ) : 'Self-assigned'}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-4 text-muted">
                      No upcoming flights allocated
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-md-12 mb-4">
              <div className="card">
                <div className="card-header">
                  Career Statistics
                </div>
                <div className="card-body">
                  <div className="row text-center gap-3">
                    <div className="col-6">
                      <h4 className="text-primary mb-0">{user.stats.totalFlightsAttended}</h4>
                      <small className="text-muted">Total Attended</small>
                    </div>
                    <div className="col-6">
                      <h4 className="text-success mb-0">{user.stats.totalFlightsHosted}</h4>
                      <small className="text-muted">Total Hosted</small>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile; 