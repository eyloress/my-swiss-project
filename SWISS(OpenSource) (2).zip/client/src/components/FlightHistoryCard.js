import React from 'react';
import { Plane, MapPin, Calendar, User, Clock } from 'lucide-react';
import moment from 'moment';

const FlightHistoryCard = ({ flight }) => {
  const getStatusBadgeClass = (status) => {
    const classes = {
      'SCHEDULED': 'badge-secondary',
      'AVAILABLE': 'badge-success',
      'BRIEFING': 'badge-warning',
      'IN PROGRESS': 'badge-info',
      'CONCLUDED': 'badge-primary',
      'CANCELLED': 'badge-danger',
      'LOGGED': 'badge-success'
    };
    return classes[status] || 'badge-secondary';
  };

  const getRoleBadgeClass = (role) => {
    const classes = {
      'Captain': 'badge-primary',
      'First Officer': 'badge-info',
      'Senior Cabin Crew': 'badge-warning',
      'Cabin Crew': 'badge-secondary',
      'Passenger': 'badge-light'
    };
    return classes[role] || 'badge-secondary';
  };

  return (
    <div className="flight-history-card">
      <div className="flight-header">
        <div className="flight-code">
          <Plane size={16} className="me-2" />
          {flight.flightCode}
        </div>
        <div className="flight-badges">
          <span className={`badge ${getRoleBadgeClass(flight.userRole)} badge-sm`}>
            {flight.userRole}
          </span>
          <span className={`badge ${getStatusBadgeClass(flight.status)} badge-sm`}>
            {flight.status}
          </span>
        </div>
      </div>
      
      <div className="flight-route">
        <MapPin size={14} className="me-1" />
        <span className="route-text">
          {flight.route.departure} → {flight.route.arrival}
        </span>
      </div>
      
      <div className="flight-details">
        <div className="flight-detail">
          <Calendar size={14} className="me-1" />
          <span>{moment(flight.scheduledDate).format('MMM DD, YYYY')}</span>
        </div>
        <div className="flight-detail">
          <Clock size={14} className="me-1" />
          <span>{moment(flight.scheduledDate).format('HH:mm')}</span>
        </div>
        <div className="flight-detail">
          <User size={14} className="me-1" />
          <span 
            className="promoter-link" 
            onClick={() => window.location.href = `/u/${flight.dispatcher?.robloxUsername || flight.dispatcherUsername}`}
          >
            @{flight.dispatcher?.robloxUsername || flight.dispatcherUsername}
          </span>
        </div>
      </div>
      
      <div className="flight-aircraft">
        <span className="text-muted">{flight.aircraft}</span>
      </div>
    </div>
  );
};

export default FlightHistoryCard; 