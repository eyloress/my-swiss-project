import React from 'react';
import { AlertTriangle, Clock, FileText, X, Calendar } from 'lucide-react';
import moment from 'moment';

const SuspensionModal = ({ suspension, onClose }) => {
  if (!suspension) return null;

  return (
    <div className="modal-overlay">
      <div className="suspension-modal">
        <div className="suspension-header">
          <div className="suspension-icon">
            <AlertTriangle size={48} />
          </div>
          <h2>Account Suspended</h2>
          <button className="btn-close-suspension" onClick={onClose}>
            <X size={20} />
          </button>
        </div>
        
        <div className="suspension-body">
          <div className="suspension-info">
            <div className="suspension-detail">
              <FileText size={18} className="detail-icon" />
              <div>
                <div className="detail-label">Reason</div>
                <div className="detail-value">{suspension.reason}</div>
              </div>
            </div>
            
            {suspension.breach && (
              <div className="suspension-detail">
                <AlertTriangle size={18} className="detail-icon" />
                <div>
                  <div className="detail-label">Breach</div>
                  <div className="detail-value">{suspension.breach}</div>
                </div>
              </div>
            )}
            
            <div className="suspension-detail">
              <Clock size={18} className="detail-icon" />
              <div>
                <div className="detail-label">Time Remaining</div>
                <div className="detail-value">{suspension.timeLeft}</div>
              </div>
            </div>
            
            <div className="suspension-detail">
              <Calendar size={18} className="detail-icon" />
              <div>
                <div className="detail-label">Expires On</div>
                <div className="detail-value">
                  {moment(suspension.expiryDate).format('MMMM DD, YYYY [at] HH:mm')}
                </div>
              </div>
            </div>
          </div>
          
          <div className="suspension-message">
            <p>Your account has been suspended and you cannot access the system until the suspension expires.</p>
            <p>If you believe this is an error, please contact the Management Board.</p>
          </div>
        </div>
        
        <div className="suspension-footer">
          <button className="btn btn-primary" onClick={() => window.location.href = '/login'}>
            Return to Login
          </button>
        </div>
      </div>
    </div>
  );
};

export default SuspensionModal; 