import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  User, 
  Plane, 
  Calendar, 
  Users, 
  Home, 
  Menu, 
  X, 
  LogOut,
  Settings,
  Trophy
} from 'lucide-react';
import axios from 'axios';
import { toast } from 'react-toastify';

const Layout = ({ user, children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await axios.post('/api/auth/logout');
      window.location.href = '/login';
    } catch (error) {
      window.location.href = '/login';
    }
  };

  const hasMinimumRank = (minRankId) => {
    return user.groupRank && user.groupRank.rankId >= minRankId;
  };

  const navigationItems = [
    {
      name: 'Profile',
      path: '/profile',
      icon: User,
      minRankId: 239
    },
    {
      name: 'Flights',
      path: '/flights',
      icon: Plane,
      minRankId: 239
    },
    {
      name: 'Leaderboard',
      path: '/leaderboard',
      icon: Trophy,
      minRankId: 239
    },
    {
      name: 'Flight Scheduling',
      path: '/scheduling',
      icon: Calendar,
      minRankId: 244
    },
    {
      name: 'Administrative Division',
      path: '/admin',
      icon: Users,
      minRankId: 247
    },
    {
      name: 'Staff Hub',
      path: '/hub',
      icon: Home,
      minRankId: 239
    }
  ];

  const filteredNavigation = navigationItems.filter(item => 
    hasMinimumRank(item.minRankId)
  );

  return (
    <div className="min-h-screen bg-light">
      <header className="bg-white shadow-sm border-bottom" style={{ borderColor: 'var(--swiss-border)' }}>
        <div className="container-fluid">
          <div className="d-flex justify-content-between align-items-center" style={{ padding: '1rem 1rem' }}>
            <div className="d-flex align-items-center gap-2">
              <button
                className="btn btn-ghost mobile-menu-btn mobile-only"
                onClick={() => setSidebarOpen(!sidebarOpen)}
              >
                <Menu size={20} />
              </button>
              
              <div className="d-flex align-items-center gap-2">
                <Link to="/profile" className="text-decoration-none" style={{ textDecoration: 'none' }}>
                  <div className="logo-container" style={{ gap: '0.25rem' }}>
                    <img
                      src="/swiss-logo.svg"
                      alt="SWISS Airlines Logo"
                      className="logo-svg"
                    />
                    <div 
                      className="d-inline-block"
                      style={{ 
                        color: 'var(--swiss-red)',
                        fontWeight: '700',
                        fontSize: '1.1rem',
                        letterSpacing: '1px',
                        textDecoration: 'none'
                      }}
                    >
                      SWISS
                    </div>
                  </div>
                </Link>
                <span className="text-muted d-none d-md-inline">Staff Portal</span>
              </div>
            </div>

            <div className="d-flex align-items-center gap-2">
              <div className="d-flex align-items-center gap-2">
                {user.robloxAvatarUrl && (
                  <img
                    src={user.robloxAvatarUrl}
                    alt="Avatar"
                    style={{ width: '32px', height: '32px' }}
                  />
                )}
                <div className="text-end d-none d-lg-block">
                  <div className="fw-semibold">{user.robloxUsername}</div>
                  <div className="text-muted" style={{ fontSize: '0.8rem' }}>
                    {user.groupRank.rankName}
                  </div>
                </div>
                <div className="d-lg-none">
                  <div className="fw-semibold" style={{ fontSize: '0.9rem' }}>{user.robloxUsername}</div>
                  <div className="text-muted" style={{ fontSize: '0.75rem' }}>
                    {user.groupRank.rankName}
                  </div>
                </div>
              </div>
              
              <button
                className="btn btn-ghost logout-btn"
                onClick={handleLogout}
                title="Logout"
              >
                <LogOut size={18} />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="d-flex">
        <aside 
          className={`sidebar ${sidebarOpen ? 'sidebar-open' : ''}`}
          style={{
            width: '250px',
            minHeight: 'calc(100vh - 73px)',
            backgroundColor: 'var(--swiss-white)',
            borderRight: '1px solid var(--swiss-border)',
            position: 'fixed',
            left: sidebarOpen ? '0' : '-250px',
            top: '73px',
            transition: 'left 0.3s ease',
            zIndex: 1000,
            overflowY: 'auto'
          }}
        >
          <nav className="p-3">
            <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
              {filteredNavigation.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path || 
                  (item.path !== '/profile' && location.pathname.startsWith(item.path));
                
                return (
                  <li key={item.path} className="mb-1">
                    <Link
                      to={item.path}
                      className={`nav-link ${isActive ? 'nav-link-active' : ''}`}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.75rem',
                        padding: '0.75rem 1rem',
                        borderRadius: 'var(--border-radius)',
                        textDecoration: 'none',
                        color: isActive ? 'var(--swiss-red)' : 'var(--swiss-black)',
                        backgroundColor: isActive ? 'var(--swiss-red-light)' : 'transparent',
                        fontWeight: isActive ? '600' : '400',
                        transition: 'var(--transition)'
                      }}
                      onClick={() => setSidebarOpen(false)}
                    >
                      <Icon size={18} />
                      {item.name}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </nav>
        </aside>

        <main 
          className="flex-grow-1 main-content"
        >
          <div className="container-fluid py-4">
            {children}
          </div>
        </main>
      </div>

      {sidebarOpen && (
        <div
          className="sidebar-overlay"
          style={{
            position: 'fixed',
            top: '73px',
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            zIndex: 999
          }}
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
};

export default Layout; 