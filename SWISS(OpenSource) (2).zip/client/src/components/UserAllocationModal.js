import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { Search, User, X, UserPlus, Loader } from 'lucide-react';
import axios from 'axios';
import { toast } from 'react-toastify';

const UserAllocationModal = ({ isOpen, onClose, flightId, roleIndex, roleName, onSuccess }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const queryClient = useQueryClient();

  const { data: users, isLoading, error } = useQuery(
    ['users', searchTerm],
    () => axios.get(`/api/users/search?q=${searchTerm}`).then(res => res.data),
    {
      enabled: isOpen && searchTerm.length >= 2,
      refetchOnWindowFocus: false
    }
  );

  const allocateMutation = useMutation(
    (userId) => axios.post(`/api/flights/${flightId}/allocate-user`, { roleIndex, userId }),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(['flight', flightId]);
        toast.success('User allocated successfully');
        onSuccess?.();
        onClose();
      },
      onError: (error) => {
        toast.error(error.response?.data?.message || 'Failed to allocate user');
      }
    }
  );

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h5 className="mb-0">Allocate User to {roleName}</h5>
          <button className="btn btn-ghost btn-sm" onClick={onClose}>
            <X size={18} />
          </button>
        </div>

        <div className="modal-body">
          <div className="search-container mb-3">
            <div className="search-input-wrapper">
              <Search size={18} className="search-icon" />
              <input
                type="text"
                className="form-control search-input"
                placeholder="Search by username or Roblox ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                autoFocus
              />
            </div>
          </div>

          <div className="users-list">
            {searchTerm.length < 2 && (
              <div className="text-center text-muted py-4">
                <Search size={32} className="opacity-50 mb-2" />
                <div>Type at least 2 characters to search for users</div>
              </div>
            )}

            {searchTerm.length >= 2 && isLoading && (
              <div className="text-center py-4">
                <Loader size={24} className="spinner" />
                <div className="mt-2 text-muted">Searching users...</div>
              </div>
            )}

            {searchTerm.length >= 2 && !isLoading && (!users || users.length === 0) && (
              <div className="text-center text-muted py-4">
                <User size={32} className="opacity-50 mb-2" />
                <div>No users found</div>
              </div>
            )}

            {users && users.length > 0 && (
              <div className="users-grid">
                {users.map((user) => (
                  <div key={user._id} className="user-card">
                    <div className="user-info">
                      <div className="user-avatar">
                        {user.robloxAvatarUrl ? (
                          <img
                            src={user.robloxAvatarUrl}
                            alt="Avatar"
                            className="avatar-img"
                          />
                        ) : (
                          <User size={24} />
                        )}
                      </div>
                      <div className="user-details">
                        <div className="user-name">@{user.robloxUsername}</div>
                        <div className="user-rank">{user.groupRank?.rankName || 'Unknown Rank'}</div>
                      </div>
                    </div>
                    <button
                      className="btn btn-primary btn-sm d-flex align-items-center gap-1"
                      onClick={() => allocateMutation.mutate(user._id)}
                      disabled={allocateMutation.isLoading}
                    >
                      <UserPlus size={14} />
                      Allocate
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserAllocationModal; 