import React from 'react';

const LoadingSpinner = ({ size = 'lg' }) => {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-8 h-8',
    lg: 'w-12 h-12',
    xl: 'w-16 h-16'
  };

  return (
    <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '200px' }}>
      <div 
        className={`spinner ${sizeClasses[size]}`}
        style={{
          width: size === 'sm' ? '1rem' : size === 'md' ? '2rem' : size === 'lg' ? '3rem' : '4rem',
          height: size === 'sm' ? '1rem' : size === 'md' ? '2rem' : size === 'lg' ? '3rem' : '4rem',
          border: '3px solid var(--swiss-border)',
          borderTop: '3px solid var(--swiss-red)',
          borderRadius: '50%',
          animation: 'spin 1s linear infinite'
        }}
      />
    </div>
  );
};

export default LoadingSpinner; 