import React from 'react';
import { AlertTriangle, X } from 'lucide-react';

const ConfirmationModal = ({ isOpen, onClose, onConfirm, title, message, confirmText = "Confirm", cancelText = "Cancel", type = "warning" }) => {
  if (!isOpen) return null;

  const getTypeStyles = () => {
    switch (type) {
      case 'danger':
        return {
          iconColor: 'text-danger',
          buttonClass: 'btn-danger',
          borderColor: 'border-danger'
        };
      case 'warning':
        return {
          iconColor: 'text-warning',
          buttonClass: 'btn-warning',
          borderColor: 'border-warning'
        };
      default:
        return {
          iconColor: 'text-primary',
          buttonClass: 'btn-primary',
          borderColor: 'border-primary'
        };
    }
  };

  const styles = getTypeStyles();

  return (
    <div className="modal-overlay" style={{ zIndex: 1050 }}>
      <div className="modal-content" style={{ maxWidth: '500px', margin: '2rem auto' }}>
        <div className={`modal-header ${styles.borderColor}`} style={{ borderBottom: '2px solid' }}>
          <div className="d-flex align-items-center gap-2">
            <AlertTriangle size={24} className={styles.iconColor} />
            <h5 className="mb-0 fw-bold">{title}</h5>
          </div>
          <button
            className="btn btn-ghost btn-sm"
            onClick={onClose}
          >
            <X size={16} />
          </button>
        </div>
        <div className="modal-body" style={{ padding: '1.5rem' }}>
          <div className="text-center">
            <AlertTriangle size={48} className={`${styles.iconColor} mb-3`} />
            <div style={{ whiteSpace: 'pre-line', lineHeight: '1.6' }}>
              {message}
            </div>
          </div>
        </div>
        <div className="modal-footer" style={{ padding: '1rem 1.5rem', gap: '0.75rem' }}>
          <button
            className="btn btn-ghost"
            onClick={onClose}
            style={{ minWidth: '100px' }}
          >
            {cancelText}
          </button>
          <button
            className={`btn ${styles.buttonClass}`}
            onClick={onConfirm}
            style={{ minWidth: '100px' }}
          >
            {confirmText}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmationModal; 