import React, { useState, useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useQuery, useQueryClient } from 'react-query';
import axios from 'axios';

import Layout from './components/Layout';
import Login from './pages/Login';
import Profile from './pages/Profile';
import UserProfile from './pages/UserProfile';
import Flights from './pages/Flights';
import FlightDetails from './pages/FlightDetails';
import FlightScheduling from './pages/FlightScheduling';
import AdminDivision from './pages/AdminDivision';
import StaffHub from './pages/StaffHub';
import Leaderboard from './pages/Leaderboard';
import LoadingSpinner from './components/LoadingSpinner';
import SuspensionModal from './components/SuspensionModal';


axios.defaults.withCredentials = true;


let globalSuspensionHandler = null;


axios.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 403 && error.response?.data?.suspension) {

      if (globalSuspensionHandler) {
        globalSuspensionHandler(error.response.data.suspension);
      } else {

        const suspensionData = error.response.data.suspension;
        localStorage.setItem('suspensionData', JSON.stringify(suspensionData));
        window.location.href = '/login?suspended=true';
      }
    }
    return Promise.reject(error);
  }
);

const ProtectedRoute = ({ children, minRankId = null }) => {
  const { data: authData, isLoading, error } = useQuery('auth', 
    () => axios.get('/api/auth/me').then(res => res.data),
    {
      retry: false,
      refetchOnWindowFocus: false
    }
  );

  if (isLoading) {
    return <LoadingSpinner />;
  }

  if (error || !authData?.user) {
    return <Navigate to="/login" replace />;
  }

  if (minRankId) {
    const userRankId = authData.user.groupRank?.rankId || 0;
    
    if (userRankId < minRankId) {
      return <Navigate to="/profile" replace />;
    }
  }

  return <Layout user={authData.user}>{children}</Layout>;
};

const PublicRoute = ({ children }) => {
  const { data: authData, isLoading } = useQuery('auth', 
    () => axios.get('/api/auth/me').then(res => res.data),
    {
      retry: false,
      refetchOnWindowFocus: false
    }
  );

  if (isLoading) {
    return <LoadingSpinner />;
  }

  if (authData?.user) {
    return <Navigate to="/profile" replace />;
  }

  return children;
};

const AppContent = () => {
  const [globalSuspensionData, setGlobalSuspensionData] = useState(null);
  const queryClient = useQueryClient();


  useEffect(() => {
    globalSuspensionHandler = (suspensionData) => {

      queryClient.clear();
      

      axios.post('/api/auth/logout').catch(() => {

      });
      

      setGlobalSuspensionData(suspensionData);
    };


    return () => {
      globalSuspensionHandler = null;
    };
  }, [queryClient]);


  const handleGlobalSuspensionClose = () => {
    setGlobalSuspensionData(null);

    window.location.href = '/login';
  };

  return (
    <div className="App">

      {globalSuspensionData && (
        <SuspensionModal 
          suspension={globalSuspensionData} 
          onClose={handleGlobalSuspensionClose}
        />
      )}
      
      <Routes>
        <Route path="/login" element={
          <PublicRoute>
            <Login />
          </PublicRoute>
        } />
        
        <Route path="/profile" element={
          <ProtectedRoute>
            <Profile />
          </ProtectedRoute>
        } />
        
        <Route path="/profile/:id" element={
          <ProtectedRoute>
            <UserProfile />
          </ProtectedRoute>
        } />
        
        <Route path="/flights" element={
          <ProtectedRoute>
            <Flights />
          </ProtectedRoute>
        } />
        
        <Route path="/flights/:id" element={
          <ProtectedRoute>
            <FlightDetails />
          </ProtectedRoute>
        } />
        
        <Route path="/leaderboard" element={
          <ProtectedRoute>
            <Leaderboard />
          </ProtectedRoute>
        } />
        
        <Route path="/u/:identifier" element={
          <ProtectedRoute>
            <UserProfile />
          </ProtectedRoute>
        } />
        
        <Route path="/scheduling" element={
          <ProtectedRoute minRankId={244}>
            <FlightScheduling />
          </ProtectedRoute>
        } />
        
        <Route path="/admin" element={
          <ProtectedRoute minRankId={247}>
            <AdminDivision />
          </ProtectedRoute>
        } />
        
        <Route path="/hub" element={
          <ProtectedRoute>
            <StaffHub />
          </ProtectedRoute>
        } />
        
        <Route path="/" element={<Navigate to="/profile" replace />} />
        <Route path="*" element={<Navigate to="/profile" replace />} />
      </Routes>
    </div>
  );
};

function App() {
  return <AppContent />;
}

export default App;