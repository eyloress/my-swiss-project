const jwt = require('jsonwebtoken');
const User = require('../models/User');

const auth = async (req, res, next) => {
  try {
    const token = req.cookies.token;
    
    if (!token) {
      return res.status(401).json({ message: 'Access denied. No token provided.' });
    }
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    const user = await User.findById(decoded.userId);
    if (!user) {
      return res.status(401).json({ message: 'User not found' });
    }

    const activeSuspension = user.sanctions?.find(s => 
      s.type === 'suspension' && 
      new Date(s.expiryDate) > new Date() &&
      (!s.activeUntil || new Date(s.activeUntil) > new Date())
    );

    if (activeSuspension) {
      const timeLeft = new Date(activeSuspension.expiryDate) - new Date();
      const daysLeft = Math.ceil(timeLeft / (1000 * 60 * 60 * 24));
      const hoursLeft = Math.ceil(timeLeft / (1000 * 60 * 60));
      
      let timeLeftText;
      if (daysLeft > 1) {
        timeLeftText = `${daysLeft} days`;
      } else if (hoursLeft > 1) {
        timeLeftText = `${hoursLeft} hours`;
      } else {
        timeLeftText = 'less than an hour';
      }

      return res.status(403).json({ 
        message: 'Account suspended',
        suspension: {
          reason: activeSuspension.reason,
          expiryDate: activeSuspension.expiryDate,
          timeLeft: timeLeftText,
          breach: activeSuspension.breach
        }
      });
    }
    
    req.user = { ...decoded, fullUser: user };
    next();
  } catch (error) {
    console.error('Token verification error:', error);
    res.status(401).json({ message: 'Invalid token.' });
  }
};

module.exports = auth; 