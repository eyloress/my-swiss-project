const express = require('express');
const Flight = require('../models/Flight');
const User = require('../models/User');
const auth = require('../middleware/auth');
const moment = require('moment');
const router = express.Router();

router.get('/week', auth, async (req, res) => {
  try {
    const { date } = req.query;
    const startDate = date ? new Date(date) : new Date();
    
    const monday = new Date(startDate);
    monday.setDate(startDate.getDate() - startDate.getDay() + 1);
    monday.setHours(0, 0, 0, 0);
    
    const flights = await Flight.getFlightsByWeek(monday);
    
    const weekFlights = {
      Monday: [],
      Tuesday: [],
      Wednesday: [],
      Thursday: [],
      Friday: [],
      Saturday: [],
      Sunday: []
    };
    
    flights.forEach(flight => {
      const dayName = flight.getDayOfWeek();
      weekFlights[dayName].push({
        ...flight.toObject(),
        totalSlots: flight.getTotalSlots(),
        assignedSlots: flight.getAssignedSlots(),
        isUserAssigned: flight.isUserAssigned(req.user.userId)
      });
    });
    
    res.json({ flights: weekFlights, weekStart: monday });
    
  } catch (error) {
    console.error('Week flights fetch error:', error);
    res.status(500).json({ message: 'Failed to fetch week flights' });
  }
});

router.get('/scheduling', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId);
    if (!user || !user.groupRank || user.groupRank.rankId < 244) {
      return res.status(403).json({ message: 'Insufficient permissions. Minimum rank ID 244 (Flight Dispatcher) required.' });
    }

    const pending = await Flight.find({ approvalStatus: 'pending' })
      .populate('dispatcher', 'robloxUsername')
      .sort('-createdAt');

    const approved = await Flight.find({ approvalStatus: 'approved', status: { $nin: ['CONCLUDED', 'CANCELLED'] } })
      .populate('dispatcher', 'robloxUsername')
      .sort('scheduledDate');

    const concluded = await Flight.find({ 
      approvalStatus: 'approved', 
      status: { $in: ['CONCLUDED', 'CANCELLED', 'LOGGED'] } 
    })
      .populate('dispatcher', 'robloxUsername')
      .populate('reviewedBy', 'robloxUsername')
      .sort('-concludedAt');

    const formatFlights = (flights) => flights.map(flight => ({
      ...flight.toObject(),
      totalSlots: flight.getTotalSlots(),
      assignedSlots: flight.getAssignedSlots()
    }));

    res.json({
      pending: formatFlights(pending),
      approved: formatFlights(approved),
      concluded: formatFlights(concluded)
    });

  } catch (error) {
    console.error('Scheduling flights fetch error:', error);
    res.status(500).json({ message: 'Failed to fetch scheduling flights' });
  }
});

router.get('/:id', auth, async (req, res) => {
  try {
    const flight = await Flight.findById(req.params.id)
      .populate('dispatcher', 'robloxUsername')
      .populate('roles.assigned.user', 'robloxUsername robloxAvatarUrl')
      .populate('logs.performedBy', 'robloxUsername');
    
    if (!flight) {
      return res.status(404).json({ message: 'Flight not found' });
    }
    

    const user = await User.findById(req.user.userId);
    if (flight.approvalStatus !== 'approved' && 
        (!user.groupRank || user.groupRank.rankId < 247) && 
        flight.dispatcher.toString() !== req.user.userId) {
      return res.status(403).json({ message: 'Access denied' });
    }
    
    res.json({
      ...flight.toObject(),
      totalSlots: flight.getTotalSlots(),
      assignedSlots: flight.getAssignedSlots(),
      isUserAssigned: flight.isUserAssigned(req.user.userId)
    });
    
  } catch (error) {
    console.error('Flight fetch error:', error);
    res.status(500).json({ message: 'Failed to fetch flight' });
  }
});

router.post('/:id/allocate', auth, async (req, res) => {
  try {
    const { roleIndex } = req.body;
    const flight = await Flight.findById(req.params.id);
    
    if (!flight) {
      return res.status(404).json({ message: 'Flight not found' });
    }
    
    if (flight.status !== 'AVAILABLE') {
      return res.status(400).json({ message: 'Flight allocation is not available' });
    }
    
    const user = await User.findById(req.user.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    if (!flight.canUserAllocate(req.user.userId, roleIndex)) {
      return res.status(400).json({ message: 'Cannot allocate to this role' });
    }
    
    flight.allocateUser(
      req.user.userId,
      user.robloxUsername,
      roleIndex,
      req.user.userId,
      user.robloxUsername
    );
    
    await flight.save();
    
    res.json({ message: 'Successfully allocated to flight' });
    
  } catch (error) {
    console.error('Flight allocation error:', error);
    res.status(500).json({ message: 'Failed to allocate to flight' });
  }
});

router.delete('/:id/unallocate', auth, async (req, res) => {
  try {
    const flight = await Flight.findById(req.params.id);
    
    if (!flight) {
      return res.status(404).json({ message: 'Flight not found' });
    }
    
    if (!['AVAILABLE', 'BRIEFING'].includes(flight.status)) {
      return res.status(400).json({ message: 'Cannot unallocate from this flight' });
    }
    
    const user = await User.findById(req.user.userId);
    let unallocated = false;
    
    for (let i = 0; i < flight.roles.length; i++) {
      if (flight.removeUserFromRole(req.user.userId, i, req.user.userId, user.robloxUsername)) {
        unallocated = true;
        break;
      }
    }
    
    if (!unallocated) {
      return res.status(400).json({ message: 'User not allocated to this flight' });
    }
    
    await flight.save();
    res.json({ message: 'Successfully unallocated from flight' });
    
  } catch (error) {
    console.error('Flight unallocation error:', error);
    res.status(500).json({ message: 'Failed to unallocate from flight' });
  }
});

router.post('/', auth, async (req, res) => {
  try {

    const user = await User.findById(req.user.userId);
    if (!user || !user.groupRank || user.groupRank.rankId < 244) {
      return res.status(403).json({ message: 'Insufficient permissions. Minimum rank ID 244 (Flight Dispatcher) required.' });
    }
    const flightData = {
      ...req.body,
      dispatcher: req.user.userId,
      dispatcherUsername: user.robloxUsername
    };
    
    const flight = new Flight(flightData);
    flight.addLog('Flight created', req.user.userId, user.robloxUsername);
    
    await flight.save();
    res.status(201).json(flight);
    
  } catch (error) {
    console.error('Flight creation error:', error);
    res.status(500).json({ message: 'Failed to create flight' });
  }
});

router.put('/:id', auth, async (req, res) => {
  try {
    const flight = await Flight.findById(req.params.id);
    
    if (!flight) {
      return res.status(404).json({ message: 'Flight not found' });
    }


    const editUser = await User.findById(req.user.userId);
    const canEdit = flight.dispatcher.toString() === req.user.userId || 
                   (editUser.groupRank && editUser.groupRank.rankId >= 247);

    if (!canEdit) {
      return res.status(403).json({ message: 'Insufficient permissions' });
    }

    if (flight.status === 'CONCLUDED' && (!editUser.groupRank || editUser.groupRank.rankId < 247)) {
      return res.status(403).json({ message: 'Cannot edit concluded flight' });
    }

    const updateData = req.body;

    Object.assign(flight, updateData);
    flight.addLog('Flight updated', req.user.userId, editUser.robloxUsername);

    await flight.save();
    res.json(flight);

  } catch (error) {
    console.error('Flight update error:', error);
    res.status(500).json({ message: 'Failed to update flight' });
  }
});

router.put('/:id/status', auth, async (req, res) => {
  try {
    const { status } = req.body;
    const flight = await Flight.findById(req.params.id);
    
    if (!flight) {
      return res.status(404).json({ message: 'Flight not found' });
    }


    const statusUser = await User.findById(req.user.userId);
    const canEdit = flight.dispatcher.toString() === req.user.userId || 
                   (statusUser.groupRank && statusUser.groupRank.rankId >= 247);

    if (!canEdit) {
      return res.status(403).json({ message: 'Insufficient permissions' });
    }

    flight.updateStatus(status, req.user.userId, statusUser.robloxUsername);

    await flight.save();
    res.json({ message: 'Status updated successfully' });

  } catch (error) {
    console.error('Status update error:', error);
    res.status(500).json({ message: 'Failed to update status' });
  }
});

router.put('/:id/approve', auth, async (req, res) => {
  try {

    const approveUser = await User.findById(req.user.userId);
    if (!approveUser || !approveUser.groupRank || approveUser.groupRank.rankId < 247) {
      return res.status(403).json({ message: 'Insufficient permissions. Minimum rank ID 247 (Corporate Board) required.' });
    }

    const flight = await Flight.findById(req.params.id);
    
    if (!flight) {
      return res.status(404).json({ message: 'Flight not found' });
    }

    if (flight.approvalStatus !== 'pending') {
      return res.status(400).json({ message: 'Flight is not pending approval' });
    }

    flight.approvalStatus = 'approved';
    flight.approvedAt = new Date();
    flight.approvedBy = req.user.userId;
    flight.status = 'AVAILABLE';
    
    flight.addLog('Flight approved', req.user.userId, approveUser.robloxUsername);

    await flight.save();
    res.json({ message: 'Flight approved successfully' });

  } catch (error) {
    console.error('Flight approval error:', error);
    res.status(500).json({ message: 'Failed to approve flight' });
  }
});

router.put('/:id/reject', auth, async (req, res) => {
  try {

    const rejectUser = await User.findById(req.user.userId);
    if (!rejectUser || !rejectUser.groupRank || rejectUser.groupRank.rankId < 247) {
      return res.status(403).json({ message: 'Insufficient permissions. Minimum rank ID 247 (Corporate Board) required.' });
    }

    const flight = await Flight.findById(req.params.id);
    
    if (!flight) {
      return res.status(404).json({ message: 'Flight not found' });
    }

    if (flight.approvalStatus !== 'pending') {
      return res.status(400).json({ message: 'Flight is not pending approval' });
    }

    flight.approvalStatus = 'rejected';
    flight.addLog('Flight rejected', req.user.userId, rejectUser.robloxUsername);

    await flight.save();
    res.json({ message: 'Flight rejected successfully' });

  } catch (error) {
    console.error('Flight rejection error:', error);
    res.status(500).json({ message: 'Failed to reject flight' });
  }
});

router.put('/:id/review', auth, async (req, res) => {
  try {

    const reviewUser = await User.findById(req.user.userId);
    if (!reviewUser || !reviewUser.groupRank || reviewUser.groupRank.rankId < 247) {
      return res.status(403).json({ message: 'Insufficient permissions. Minimum rank ID 247 (Corporate Board) required.' });
    }

    const flight = await Flight.findById(req.params.id);
    
    if (!flight) {
      return res.status(404).json({ message: 'Flight not found' });
    }

    if (flight.status !== 'CONCLUDED') {
      return res.status(400).json({ message: 'Flight must be concluded to review' });
    }

    if (flight.reviewedAt) {
      return res.status(400).json({ message: 'Flight already reviewed' });
    }

    const { points } = req.body;
    if (points) {
      flight.points = points;
    }

    flight.reviewedAt = new Date();
    flight.reviewedBy = req.user.userId;
    flight.status = 'LOGGED';
    
    flight.addLog('Flight reviewed and points awarded', req.user.userId, reviewUser.robloxUsername);

    await flight.save();

    res.json({ message: 'Flight reviewed successfully' });

  } catch (error) {
    console.error('Flight review error:', error);
    res.status(500).json({ message: 'Failed to review flight' });
  }
});

router.post('/:id/allocate-user', auth, async (req, res) => {
  try {
    const { roleIndex, userId } = req.body;
    const flight = await Flight.findById(req.params.id);
    
    if (!flight) {
      return res.status(404).json({ message: 'Flight not found' });
    }


    const allocateUser = await User.findById(req.user.userId);
    const canEdit = flight.dispatcher.toString() === req.user.userId || 
                   (allocateUser.groupRank && allocateUser.groupRank.rankId >= 247);

    if (!canEdit) {
      return res.status(403).json({ message: 'Insufficient permissions' });
    }

    if (flight.status === 'CONCLUDED') {
      return res.status(400).json({ message: 'Cannot allocate to concluded flight' });
    }

    let targetUser;

    if (/^[0-9a-fA-F]{24}$/.test(userId)) {
      targetUser = await User.findById(userId);
    } else if (userId.includes('@') || /^\d+$/.test(userId)) {
      targetUser = await User.findOne({
        $or: [
          { robloxUsername: userId.replace('@', '') },
          { robloxId: userId }
        ]
      });
    } else {
      targetUser = await User.findOne({ robloxUsername: userId });
    }

    if (!targetUser) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (!flight.canUserAllocate(targetUser._id, roleIndex)) {
      return res.status(400).json({ message: 'Cannot allocate user to this role' });
    }

    flight.allocateUser(
      targetUser._id,
      targetUser.robloxUsername,
      roleIndex,
      req.user.userId,
      allocateUser.robloxUsername
    );

    await flight.save();
    res.json({ message: 'User allocated successfully' });

  } catch (error) {
    console.error('User allocation error:', error);
    res.status(500).json({ message: 'Failed to allocate user' });
  }
});

router.delete('/:id/unallocate-user', auth, async (req, res) => {
  try {
    const { roleIndex, userId } = req.body;
    const flight = await Flight.findById(req.params.id);
    
    if (!flight) {
      return res.status(404).json({ message: 'Flight not found' });
    }

    const canEdit = flight.dispatcher.toString() === req.user.userId || 
                   ['Corporate Board', 'Management Board'].includes(req.user.role);

    if (!canEdit) {
      return res.status(403).json({ message: 'Insufficient permissions' });
    }

    if (flight.status === 'CONCLUDED') {
      return res.status(400).json({ message: 'Cannot unallocate from concluded flight' });
    }

    const currentUser = await User.findById(req.user.userId);
    
    if (!flight.removeUserFromRole(userId, roleIndex, req.user.userId, currentUser.robloxUsername)) {
      return res.status(400).json({ message: 'User not found in this role' });
    }

    await flight.save();
    res.json({ message: 'User unallocated successfully' });

  } catch (error) {
    console.error('User unallocation error:', error);
    res.status(500).json({ message: 'Failed to unallocate user' });
  }
});

router.delete('/:id', auth, async (req, res) => {
  try {
    const flight = await Flight.findById(req.params.id);
    
    if (!flight) {
      return res.status(404).json({ message: 'Flight not found' });
    }

    const canDelete = flight.dispatcher.toString() === req.user.userId && flight.approvalStatus === 'pending';

    if (!canDelete) {
      return res.status(403).json({ message: 'Can only delete your own pending flights' });
    }

    await Flight.findByIdAndDelete(req.params.id);
    res.json({ message: 'Flight deleted successfully' });

  } catch (error) {
    console.error('Flight deletion error:', error);
    res.status(500).json({ message: 'Failed to delete flight' });
  }
});

module.exports = router; 