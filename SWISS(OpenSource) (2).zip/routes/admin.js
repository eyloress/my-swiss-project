const express = require('express');
const User = require('../models/User');
const Flight = require('../models/Flight');
const AdminAction = require('../models/AdminAction');
const auth = require('../middleware/auth');
const router = express.Router();

router.use(auth);

router.use(async (req, res, next) => {
  try {
    const user = await User.findById(req.user.userId);
    
    if (!user) {
      return res.status(401).json({ message: 'User not found' });
    }
    

    if (!user.groupRank || user.groupRank.rankId < 247) {
      return res.status(403).json({ 
        message: 'Administrative access required. Minimum rank ID 247 (Corporate Board) needed.',
        currentRank: user.groupRank?.rankId || 0,
        requiredRank: 247
      });
    }
    
    req.user.fullUser = user;
    
    next();
  } catch (error) {
    console.error('Admin middleware error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

router.get('/users', async (req, res) => {
  try {
    const { page = 1, limit = 20, filter, search } = req.query;
    const skip = (page - 1) * limit;
    
    let query = {};
    
    if (search) {
      const searchRegex = new RegExp(search, 'i');
      query.$or = [
        { robloxUsername: searchRegex },
        { robloxDisplayName: searchRegex },
        { robloxId: search }
      ];
    }
    
    if (['quota-deficit', 'below-quota', 'over-quota'].includes(filter)) {
      const currentTermStart = new Date();
      currentTermStart.setDate(1);
      currentTermStart.setHours(2, 0, 0, 0);
      
      let matchCondition = {};
      let sortCondition = {};
      
      if (filter === 'quota-deficit') {

        matchCondition = {
          $expr: {
            $and: [
              { $lt: ['$termFlightsCount', '$stats.requiredFlights'] },
              { $eq: ['$isOnLeave', false] }
            ]
          }
        };
      } else if (filter === 'below-quota') {

        matchCondition = {
          $expr: {
            $and: [
              { $lt: ['$termFlightsCount', '$stats.requiredFlights'] },
              { $gt: ['$stats.requiredFlights', 0] }
            ]
          }
        };
        sortCondition = { quotaRatio: 1 };
      } else if (filter === 'over-quota') {

        matchCondition = {
          $expr: {
            $and: [
              { $gte: ['$termFlightsCount', '$stats.requiredFlights'] },
              { $gt: ['$stats.requiredFlights', 0] }
            ]
          }
        };
        sortCondition = { quotaRatio: -1 };
      }
      
      const users = await User.aggregate([
        { $match: query },
        {
          $lookup: {
            from: 'flights',
            let: { userId: '$_id' },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $in: ['$$userId', '$roles.assigned.user'] },
                      { $gte: ['$scheduledDate', currentTermStart] },
                      { $in: ['$status', ['CONCLUDED', 'LOGGED']] }
                    ]
                  }
                }
              }
            ],
            as: 'termFlights'
          }
        },
        {
          $addFields: {
            termFlightsCount: { $size: '$termFlights' },
            quotaRatio: {
              $cond: {
                if: { $gt: ['$stats.requiredFlights', 0] },
                then: { $divide: ['$termFlightsCount', '$stats.requiredFlights'] },
                else: 0
              }
            }
          }
        },
        { $match: matchCondition },
        { $sort: Object.keys(sortCondition).length > 0 ? sortCondition : { _id: 1 } },
        { $skip: skip },
        { $limit: parseInt(limit) }
      ]);
      
      return res.json({ users, pagination: { page: parseInt(page), limit: parseInt(limit) } });
    }
    
    const users = await User.find(query)
      .select('-sanctions -notes')
      .sort('-lastLogin')
      .skip(skip)
      .limit(parseInt(limit));
    
    const total = await User.countDocuments(query);
    
    res.json({
      users,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
    
  } catch (error) {
    console.error('Admin users fetch error:', error);
    res.status(500).json({ message: 'Failed to fetch users' });
  }
});

router.get('/users/:id', async (req, res) => {
  try {
    const requestingUser = req.user.fullUser;
    const targetUser = await User.findById(req.params.id)
      .populate('sanctions.issuer', 'robloxUsername')
      .populate('notes.addedBy', 'robloxUsername')
      .populate('rankHistory.promotedBy', 'robloxUsername');
    
    if (!targetUser) {
      return res.status(404).json({ message: 'User not found' });
    }
    


    if (targetUser.groupRank.rankId > requestingUser.groupRank.rankId && 
        requestingUser.groupRank.rankId < 249) {
      return res.status(403).json({ message: 'Cannot view profile of higher ranked user' });
    }
    
    const flightHistory = await Flight.find({
      'roles.assigned.user': targetUser._id,
      status: { $in: ['CONCLUDED', 'LOGGED'] }
    }).sort('-scheduledDate').limit(20);
    

    const currentTermStart = new Date();
    currentTermStart.setDate(1);
    currentTermStart.setHours(2, 0, 0, 0);
    
    const termFlights = await Flight.find({
      'roles.assigned.user': targetUser._id,
      scheduledDate: { $gte: currentTermStart },
      status: { $in: ['CONCLUDED', 'LOGGED'] }
    });
    
    const termAttended = termFlights.length;
    const termHosted = termFlights.filter(flight => 
      flight.dispatcher.toString() === targetUser._id.toString()
    ).length;
    
    const totalFlights = await Flight.countDocuments({
      'roles.assigned.user': targetUser._id,
      status: { $in: ['CONCLUDED', 'LOGGED'] }
    });
    
    const totalHosted = await Flight.countDocuments({
      dispatcher: targetUser._id,
      status: { $in: ['CONCLUDED', 'LOGGED'] }
    });
    

    const userWithUpdatedStats = {
      ...targetUser.toObject(),
      stats: {
        ...targetUser.stats,
        termFlightsAttended: termAttended,
        termFlightsHosted: termHosted,
        totalFlightsAttended: totalFlights,
        totalFlightsHosted: totalHosted
      }
    };
    
    res.json({
      user: userWithUpdatedStats,
      flightHistory
    });
    
  } catch (error) {
    console.error('Admin user fetch error:', error);
    res.status(500).json({ message: 'Failed to fetch user' });
  }
});

router.post('/users/:id/sanctions', async (req, res) => {
  try {
    const { type, breach, reason, comment, expiryDate, activeUntil } = req.body;
    const targetUser = await User.findById(req.params.id);
    const issuer = await User.findById(req.user.userId);
    
    if (!targetUser) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    const existingSanctions = targetUser.sanctions.filter(s => s.type === type && s.expiryDate > new Date());
    const count = existingSanctions.length + 1;
    
    const sanction = {
      type,
      count,
      breach,
      reason,
      comment,
      issuer: req.user.userId,
      issuerUsername: issuer.robloxUsername,
      expiryDate: new Date(expiryDate),
      activeUntil: activeUntil ? new Date(activeUntil) : undefined
    };
    
    targetUser.sanctions.push(sanction);
    await targetUser.save();
    

    await AdminAction.create({
      actionType: 'sanction_add',
      performedBy: req.user.userId,
      performedByUsername: issuer.robloxUsername,
      targetUser: targetUser._id,
      targetUsername: targetUser.robloxUsername,
      details: {
        action: 'Added sanction',
        sanctionType: type,
        breach: breach,
        reason: reason,
        expiryDate: expiryDate,
        activeUntil: activeUntil
      }
    });
    
    res.json({ message: 'Sanction added successfully', sanction });
    
  } catch (error) {
    console.error('Sanction creation error:', error);
    res.status(500).json({ message: 'Failed to add sanction' });
  }
});

router.delete('/users/:userId/sanctions/:sanctionId', async (req, res) => {
  try {

    if (req.user.fullUser.groupRank.rankId < 249) {
      return res.status(403).json({ message: 'Only Management Board (rank ID 249+) can delete sanctions' });
    }
    
    const user = await User.findById(req.params.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    const deletedSanction = user.sanctions.id(req.params.sanctionId);
    user.sanctions.pull({ _id: req.params.sanctionId });
    await user.save();
    

    await AdminAction.create({
      actionType: 'sanction_delete',
      performedBy: req.user.userId,
      performedByUsername: req.user.fullUser.robloxUsername,
      targetUser: user._id,
      targetUsername: user.robloxUsername,
      details: {
        action: 'Deleted sanction',
        sanctionType: deletedSanction?.type,
        breach: deletedSanction?.breach,
        reason: deletedSanction?.reason
      }
    });
    
    res.json({ message: 'Sanction deleted successfully' });
    
  } catch (error) {
    console.error('Sanction deletion error:', error);
    res.status(500).json({ message: 'Failed to delete sanction' });
  }
});

router.post('/users/:id/qualifications', async (req, res) => {
  try {
    const { name } = req.body;
    const targetUser = await User.findById(req.params.id);
    const grantor = await User.findById(req.user.userId);
    
    if (!targetUser) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    if (targetUser.hasQualification(name)) {
      return res.status(400).json({ message: 'User already has this qualification' });
    }
    
    const qualification = {
      name,
      grantedBy: req.user.userId,
      grantedDate: new Date()
    };
    
    targetUser.qualifications.push(qualification);
    
    targetUser.rankHistory.push({
      rankId: targetUser.groupRank.rankId,
      rankName: name,
      date: new Date(),
      promotedBy: req.user.userId,
      type: 'qualification'
    });
    
    await targetUser.save();
    

    await AdminAction.create({
      actionType: 'qualification_add',
      performedBy: req.user.userId,
      performedByUsername: grantor.robloxUsername,
      targetUser: targetUser._id,
      targetUsername: targetUser.robloxUsername,
      details: {
        action: 'Added qualification',
        qualificationName: name
      }
    });
    
    res.json({ message: 'Qualification added successfully', qualification });
    
  } catch (error) {
    console.error('Qualification addition error:', error);
    res.status(500).json({ message: 'Failed to add qualification' });
  }
});

router.delete('/users/:userId/qualifications/:qualificationId', async (req, res) => {
  try {
    const user = await User.findById(req.params.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    const deletedQualification = user.qualifications.id(req.params.qualificationId);
    user.qualifications.pull({ _id: req.params.qualificationId });
    await user.save();
    

    await AdminAction.create({
      actionType: 'qualification_delete',
      performedBy: req.user.userId,
      performedByUsername: req.user.fullUser.robloxUsername,
      targetUser: user._id,
      targetUsername: user.robloxUsername,
      details: {
        action: 'Removed qualification',
        qualificationName: deletedQualification?.name
      }
    });
    
    res.json({ message: 'Qualification removed successfully' });
    
  } catch (error) {
    console.error('Qualification removal error:', error);
    res.status(500).json({ message: 'Failed to remove qualification' });
  }
});

router.put('/users/:id/quota', async (req, res) => {
  try {
    const { requiredFlights } = req.body;
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { 'stats.requiredFlights': requiredFlights },
      { new: true }
    );
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    

    await AdminAction.create({
      actionType: 'quota_update',
      performedBy: req.user.userId,
      performedByUsername: req.user.fullUser.robloxUsername,
      targetUser: user._id,
      targetUsername: user.robloxUsername,
      details: {
        action: 'Updated quota',
        newRequiredFlights: requiredFlights,
        previousRequiredFlights: user.stats?.requiredFlights || 0
      }
    });
    
    res.json({ message: 'Quota updated successfully', requiredFlights });
    
  } catch (error) {
    console.error('Quota update error:', error);
    res.status(500).json({ message: 'Failed to update quota' });
  }
});

router.post('/users/:id/notes', async (req, res) => {
  try {
    const { content, visibleToUser, type } = req.body;
    const user = await User.findById(req.params.id);
    const addedBy = await User.findById(req.user.userId);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    const note = {
      content,
      addedBy: req.user.userId,
      visibleToUser: visibleToUser || false,
      type: type || 'general'
    };
    
    user.notes.push(note);
    await user.save();
    

    await AdminAction.create({
      actionType: 'note_add',
      performedBy: req.user.userId,
      performedByUsername: addedBy.robloxUsername,
      targetUser: user._id,
      targetUsername: user.robloxUsername,
      details: {
        action: 'Added note',
        noteType: type,
        content: content,
        visibleToUser: visibleToUser
      }
    });
    
    res.json({ message: 'Note added successfully', note });
    
  } catch (error) {
    console.error('Note addition error:', error);
    res.status(500).json({ message: 'Failed to add note' });
  }
});

router.post('/users/:id/reward', async (req, res) => {
  try {
    const { amount, reason, type } = req.body;
    const user = await User.findById(req.params.id);
    const awardedBy = await User.findById(req.user.userId);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    const reward = {
      amount: parseFloat(amount),
      reason,
      type: type || 'bonus',
      awardedBy: awardedBy.robloxUsername,
      awardedDate: new Date()
    };
    
    if (!user.rewards) {
      user.rewards = [];
    }
    user.rewards.push(reward);
    

    if (!user.stats.termPay) {
      user.stats.termPay = 0;
    }
    user.stats.termPay += parseFloat(amount);
    
    await user.save();
    

    await AdminAction.create({
      actionType: 'reward_add',
      performedBy: req.user.userId,
      performedByUsername: awardedBy.robloxUsername,
      targetUser: user._id,
      targetUsername: user.robloxUsername,
      details: {
        action: 'Added reward',
        rewardType: type,
        amount: parseFloat(amount),
        reason: reason
      }
    });
    
    res.json({ message: 'Reward added successfully', reward });
    
  } catch (error) {
    console.error('Reward addition error:', error);
    res.status(500).json({ message: 'Failed to add reward' });
  }
});

router.post('/term/advance', async (req, res) => {
  try {

    if (req.user.fullUser.groupRank.rankId < 249) {
      return res.status(403).json({ message: 'Only Management Board (rank ID 249+) can advance terms' });
    }
    

    const users = await User.find({});
    

    for (const user of users) {
      user.stats.totalFlightsAttended += user.stats.termFlightsAttended || 0;
      user.stats.totalFlightsHosted += user.stats.termFlightsHosted || 0;
      user.stats.termFlightsAttended = 0;
      user.stats.termFlightsHosted = 0;
      user.stats.termPay = 0;
      await user.save();
      }
    

    await Flight.updateMany(
      { status: { $in: ['CONCLUDED', 'LOGGED'] } },
      { $set: { status: 'ARCHIVED' } }
    );
    

    await AdminAction.create({
      actionType: 'term_advance',
      performedBy: req.user.userId,
      performedByUsername: req.user.fullUser.robloxUsername,
      details: {
        action: 'Advanced term',
        usersProcessed: users.length,
        flightsArchived: await Flight.countDocuments({ status: 'ARCHIVED' })
      }
    });
    
    res.json({ message: 'Term advanced successfully' });
    
  } catch (error) {
    console.error('Term advance error:', error);
    res.status(500).json({ message: 'Failed to advance term' });
  }
});

router.get('/history', async (req, res) => {
  try {
    const { page = 1, limit = 50, actionType, targetUser } = req.query;
    const skip = (page - 1) * limit;
    
    let query = {};
    
    if (actionType && actionType !== 'all') {
      query.actionType = actionType;
    }
    
    if (targetUser) {

      query.$or = [
        { targetUsername: { $regex: targetUser, $options: 'i' } },
        { performedByUsername: { $regex: targetUser, $options: 'i' } }
      ];
    }
    
    const actions = await AdminAction.find(query)
      .populate('performedBy', 'robloxUsername groupRank')
      .populate('targetUser', 'robloxUsername groupRank')
      .sort('-timestamp')
      .skip(skip)
      .limit(parseInt(limit));
    
    const total = await AdminAction.countDocuments(query);
    
    res.json({
      actions,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
    
  } catch (error) {
    console.error('Admin history fetch error:', error);
    res.status(500).json({ message: 'Failed to fetch admin history' });
  }
});

module.exports = router; 