const express = require('express');
const axios = require('axios');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const router = express.Router();

const ROBLOX_GROUP_ID = process.env.ROBLOX_GROUP_ID || '13241826';

const getRobloxUserInfo = async (accessToken) => {
  try {
    const userResponse = await axios.get('https://apis.roblox.com/oauth/v1/userinfo', {
      headers: {
        'Authorization': `Bearer ${accessToken}`
      }
    });
    return {
      id: userResponse.data.sub,
      name: userResponse.data.preferred_username,
      displayName: userResponse.data.name
    };
  } catch (error) {
    console.error('Error fetching user info from Roblox:', error.response?.data || error.message);
    console.error('Status:', error.response?.status);
    console.error('Headers:', error.response?.headers);
    throw new Error('Failed to fetch user info from Roblox');
  }
};

const getRobloxUserGroups = async (userId) => {
  try {
    const groupsResponse = await axios.get(`https://groups.roblox.com/v1/users/${userId}/groups/roles`);
    return groupsResponse.data.data;
  } catch (error) {
    throw new Error('Failed to fetch user groups from Roblox');
  }
};

const getRobloxUserDetails = async (userId) => {
  try {
    const userResponse = await axios.get(`https://users.roblox.com/v1/users/${userId}`);
    return userResponse.data;
  } catch (error) {
    throw new Error('Failed to fetch user details from Roblox');
  }
};

const getRobloxUserAvatar = async (userId) => {
  try {
    const avatarResponse = await axios.get(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${userId}&size=420x420&format=Png&isCircular=false`);
    return avatarResponse.data.data[0]?.imageUrl || null;
  } catch (error) {
    return null;
  }
};

router.get('/roblox', (req, res) => {
  const clientId = process.env.ROBLOX_CLIENT_ID;
  const redirectUri = encodeURIComponent(process.env.ROBLOX_REDIRECT_URI);
  const scope = encodeURIComponent('openid profile');
  const state = jwt.sign({ timestamp: Date.now() }, process.env.JWT_SECRET, { expiresIn: '10m' });
  
  if (!clientId) {
    return res.redirect(`${process.env.FRONTEND_URL}/login?error=config_error`);
  }
  
  const authUrl = `https://apis.roblox.com/oauth/v1/authorize?client_id=${clientId}&redirect_uri=${redirectUri}&scope=${scope}&response_type=code&state=${state}`;
  res.redirect(authUrl);
});

router.get('/roblox/callback', async (req, res) => {
  try {
    const { code, state } = req.query;
    
    if (!code) {
      return res.redirect(`${process.env.FRONTEND_URL}/login?error=access_denied`);
    }
    
    try {
      jwt.verify(state, process.env.JWT_SECRET);
    } catch (error) {
      return res.redirect(`${process.env.FRONTEND_URL}/login?error=invalid_state`);
    }
    
    const tokenResponse = await axios.post('https://apis.roblox.com/oauth/v1/token', {
      client_id: process.env.ROBLOX_CLIENT_ID,
      client_secret: process.env.ROBLOX_CLIENT_SECRET,
      grant_type: 'authorization_code',
      code: code,
      redirect_uri: process.env.ROBLOX_REDIRECT_URI
    }, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });
    
    const accessToken = tokenResponse.data.access_token;
    
    const userInfo = await getRobloxUserInfo(accessToken);
    const userGroups = await getRobloxUserGroups(userInfo.id);
    const avatarUrl = await getRobloxUserAvatar(userInfo.id);
    
    const swissGroup = userGroups.find(group => group.group.id.toString() === ROBLOX_GROUP_ID);
    
    if (!swissGroup) {
      return res.redirect(`${process.env.FRONTEND_URL}/login?error=not_in_group`);
    }
    
    if (swissGroup.role.rank < 239) {
      return res.redirect(`${process.env.FRONTEND_URL}/login?error=insufficient_rank`);
    }
    
    let user = await User.findOne({ robloxId: userInfo.id.toString() });
    
    if (!user) {
      user = new User({
        robloxId: userInfo.id.toString(),
        robloxUsername: userInfo.name,
        robloxDisplayName: userInfo.displayName,
        robloxAvatarUrl: avatarUrl,
        groupRank: {
          rankId: swissGroup.role.rank,
          rankName: swissGroup.role.name,
          lastUpdated: new Date()
        }
      });
      
      user.role = user.getRole();
      
      user.rankHistory.push({
        rankId: swissGroup.role.rank,
        rankName: swissGroup.role.name,
        date: new Date(),
        type: 'promotion'
      });
      
      await user.save();
    } else {
      user.robloxUsername = userInfo.name;
      user.robloxDisplayName = userInfo.displayName;
      user.robloxAvatarUrl = avatarUrl;
      
      if (user.groupRank.rankId !== swissGroup.role.rank) {
        user.rankHistory.push({
          rankId: swissGroup.role.rank,
          rankName: swissGroup.role.name,
          date: new Date(),
          type: swissGroup.role.rank > user.groupRank.rankId ? 'promotion' : 'demotion'
        });
      }
      
      user.groupRank = {
        rankId: swissGroup.role.rank,
        rankName: swissGroup.role.name,
        lastUpdated: new Date()
      };
      
      user.role = user.getRole();
      user.lastLogin = new Date();
      
      await user.save();
    }
    
    const token = jwt.sign(
      { 
        userId: user._id,
        robloxId: user.robloxId,
        role: user.role
      },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );
    
    res.cookie('token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: 24 * 60 * 60 * 1000,
      sameSite: 'lax'
    });
    
    res.redirect(`${process.env.FRONTEND_URL}/profile`);
    
  } catch (error) {
    console.error('OAuth callback error:', error);
    res.redirect(`${process.env.FRONTEND_URL}/login?error=oauth_failed`);
  }
});

router.post('/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ message: 'Logged out successfully' });
});

router.get('/me', async (req, res) => {
  try {
    const token = req.cookies.token;
    
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.userId).select('-__v');
    
    if (!user) {
      return res.status(401).json({ message: 'User not found' });
    }
    
    res.json({
      user: {
        _id: user._id,
        robloxId: user.robloxId,
        robloxUsername: user.robloxUsername,
        robloxDisplayName: user.robloxDisplayName,
        robloxAvatarUrl: user.robloxAvatarUrl,
        groupRank: user.groupRank,
        role: user.role,
        qualifications: user.qualifications,
        stats: user.stats,
        sanctions: user.getActiveSanctions(),
        notes: user.notes.filter(note => note.visibleToUser),
        isOnLeave: user.isOnLeave,
        leaveDetails: user.leaveDetails,
        lastLogin: user.lastLogin
      }
    });
    
  } catch (error) {
    console.error('Auth verification error:', error);
    res.status(401).json({ message: 'Invalid token' });
  }
});

router.post('/refresh-rank', async (req, res) => {
  try {
    const token = req.cookies.token;
    
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.userId);
    
    if (!user) {
      return res.status(401).json({ message: 'User not found' });
    }
    
    const userGroups = await getRobloxUserGroups(user.robloxId);
    const swissGroup = userGroups.find(group => group.group.id.toString() === ROBLOX_GROUP_ID);
    
    if (!swissGroup) {
      return res.status(403).json({ message: 'User no longer in group' });
    }
    
    if (swissGroup.role.rank < 239) {
      return res.status(403).json({ message: 'Insufficient rank' });
    }
    
    if (user.groupRank.rankId !== swissGroup.role.rank) {
      user.rankHistory.push({
        rankId: swissGroup.role.rank,
        rankName: swissGroup.role.name,
        date: new Date(),
        type: swissGroup.role.rank > user.groupRank.rankId ? 'promotion' : 'demotion'
      });
      
      user.groupRank = {
        rankId: swissGroup.role.rank,
        rankName: swissGroup.role.name,
        lastUpdated: new Date()
      };
      
      user.role = user.getRole();
      await user.save();
    }
    
    res.json({
      message: 'Rank refreshed successfully',
      groupRank: user.groupRank,
      role: user.role
    });
    
  } catch (error) {
    console.error('Rank refresh error:', error);
    res.status(500).json({ message: 'Failed to refresh rank' });
  }
});

module.exports = router; 