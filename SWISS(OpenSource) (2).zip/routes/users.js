const express = require('express');
const User = require('../models/User');
const Flight = require('../models/Flight');
const auth = require('../middleware/auth');
const router = express.Router();

router.get('/profile', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId)
      .populate('rankHistory.promotedBy', 'robloxUsername')
      .populate('notes.addedBy', 'robloxUsername');
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    const upcomingFlights = await Flight.find({
      'roles.assigned.user': user._id,
      scheduledDate: { $gte: new Date() },
      status: { $in: ['SCHEDULED', 'AVAILABLE', 'BRIEFING'] }
    })
    .populate('roles.assigned.assignedBy', 'robloxUsername')
    .sort('scheduledDate').limit(5);
    
    const flightHistory = await Flight.find({
      'roles.assigned.user': user._id,
      status: { $in: ['CONCLUDED', 'LOGGED'] }
    })
    .populate('roles.assigned.assignedBy', 'robloxUsername')
    .sort('-scheduledDate').limit(10);
    

    const upcomingFlightsWithRoles = upcomingFlights.map(flight => {
      const userRole = flight.roles.find(role => 
        role.assigned.some(assignment => 
          assignment.user.toString() === user._id.toString()
        )
      );
      
      const userAssignment = userRole ? userRole.assigned.find(assignment => 
        assignment.user.toString() === user._id.toString()
      ) : null;
      
      return {
        ...flight.toObject(),
        userRole: userRole ? userRole.name : 'Unknown',
        assignedBy: userAssignment ? userAssignment.assignedBy : null
      };
    });


    const flightHistoryWithRoles = flightHistory.map(flight => {
      const userRole = flight.roles.find(role => 
        role.assigned.some(assignment => 
          assignment.user.toString() === user._id.toString()
        )
      );
      
      const userAssignment = userRole ? userRole.assigned.find(assignment => 
        assignment.user.toString() === user._id.toString()
      ) : null;
      
      return {
        ...flight.toObject(),
        userRole: userRole ? userRole.name : 'Unknown',
        assignedBy: userAssignment ? userAssignment.assignedBy : null
      };
    });

    const nextQuotaReset = new Date();
    nextQuotaReset.setMonth(nextQuotaReset.getMonth() + 1);
    nextQuotaReset.setDate(1);
    nextQuotaReset.setHours(2, 0, 0, 0);
    

    const currentTermStart = new Date();
    currentTermStart.setDate(1);
    currentTermStart.setHours(2, 0, 0, 0);
    
    const termFlights = await Flight.find({
      'roles.assigned.user': user._id,
      scheduledDate: { $gte: currentTermStart },
      status: { $in: ['CONCLUDED', 'LOGGED'] }
    });
    
    const termAttended = termFlights.length;
    const termHosted = termFlights.filter(flight => 
      flight.dispatcher.toString() === user._id.toString()
    ).length;
    
    const totalFlights = await Flight.countDocuments({
      'roles.assigned.user': user._id,
      status: { $in: ['CONCLUDED', 'LOGGED'] }
    });
    
    const totalHosted = await Flight.countDocuments({
      dispatcher: user._id,
      status: { $in: ['CONCLUDED', 'LOGGED'] }
    });
    

    const updatedStats = {
      ...user.stats,
      termFlightsAttended: termAttended,
      termFlightsHosted: termHosted,
      totalFlightsAttended: totalFlights,
      totalFlightsHosted: totalHosted
    };
    
    res.json({
      user: {
        _id: user._id,
        robloxId: user.robloxId,
        robloxUsername: user.robloxUsername,
        robloxDisplayName: user.robloxDisplayName,
        robloxAvatarUrl: user.robloxAvatarUrl,
        groupRank: user.groupRank,
        role: user.role,
        qualifications: user.qualifications,
        stats: updatedStats,
        sanctions: user.getActiveSanctions(),
        rankHistory: user.rankHistory,
        notes: user.notes.filter(note => note.visibleToUser),
        isOnLeave: user.isOnLeave,
        leaveDetails: user.leaveDetails,
        lastLogin: user.lastLogin
      },
      upcomingFlights: upcomingFlightsWithRoles,
      flightHistory: flightHistoryWithRoles,
      nextQuotaReset
    });
    
  } catch (error) {
    console.error('Profile fetch error:', error);
    res.status(500).json({ message: 'Failed to fetch profile' });
  }
});

router.get('/flight-history', auth, async (req, res) => {
  try {
    const { page = 1, limit = 20, term } = req.query;
    const skip = (page - 1) * limit;
    
    let query = {
      'roles.assigned.user': req.user.userId,
      status: { $in: ['CONCLUDED', 'LOGGED'] }
    };
    
    if (term === 'current') {
      const currentTermStart = new Date();
      currentTermStart.setDate(1);
      currentTermStart.setHours(2, 0, 0, 0);
      query.scheduledDate = { $gte: currentTermStart };
    }
    
    const flights = await Flight.find(query)
      .sort('-scheduledDate')
      .skip(skip)
      .limit(parseInt(limit))
      .populate('dispatcher', 'robloxUsername');
    
    const total = await Flight.countDocuments(query);
    
    const flightsWithUserRole = flights.map(flight => {
      const userRole = flight.roles.find(role => 
        role.assigned.some(assignment => 
          assignment.user.toString() === req.user.userId
        )
      );
      
      return {
        ...flight.toObject(),
        userRole: userRole ? userRole.name : 'Unknown'
      };
    });
    
    res.json({
      flights: flightsWithUserRole,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
    
  } catch (error) {
    console.error('Flight history fetch error:', error);
    res.status(500).json({ message: 'Failed to fetch flight history' });
  }
});

router.get('/stats', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    const currentTermStart = new Date();
    currentTermStart.setDate(1);
    currentTermStart.setHours(2, 0, 0, 0);
    
    const termFlights = await Flight.find({
      'roles.assigned.user': user._id,
      scheduledDate: { $gte: currentTermStart },
      status: { $in: ['CONCLUDED', 'LOGGED'] }
    });
    
    const termAttended = termFlights.length;
    const termHosted = termFlights.filter(flight => 
      flight.dispatcher.toString() === user._id.toString()
    ).length;
    
    const totalFlights = await Flight.countDocuments({
      'roles.assigned.user': user._id,
      status: { $in: ['CONCLUDED', 'LOGGED'] }
    });
    
    const totalHosted = await Flight.countDocuments({
      dispatcher: user._id,
      status: { $in: ['CONCLUDED', 'LOGGED'] }
    });
    
    res.json({
      term: {
        attended: termAttended,
        hosted: termHosted,
        pay: user.stats.termPay,
        quota: user.stats.requiredFlights
      },
      total: {
        attended: totalFlights,
        hosted: totalHosted
      },
      qualifications: user.qualifications,
      sanctions: user.getActiveSanctions()
    });
    
  } catch (error) {
    console.error('Stats fetch error:', error);
    res.status(500).json({ message: 'Failed to fetch stats' });
  }
});

router.put('/profile', auth, async (req, res) => {
  try {
    const allowedUpdates = ['robloxDisplayName'];
    const updates = {};
    
    Object.keys(req.body).forEach(key => {
      if (allowedUpdates.includes(key)) {
        updates[key] = req.body[key];
      }
    });
    
    const user = await User.findByIdAndUpdate(
      req.user.userId,
      { $set: updates },
      { new: true, runValidators: true }
    );
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    res.json({
      message: 'Profile updated successfully',
      user: {
        _id: user._id,
        robloxUsername: user.robloxUsername,
        robloxDisplayName: user.robloxDisplayName,
        robloxAvatarUrl: user.robloxAvatarUrl,
        groupRank: user.groupRank,
        role: user.role
      }
    });
    
  } catch (error) {
    console.error('Profile update error:', error);
    res.status(500).json({ message: 'Failed to update profile' });
  }
});

router.get('/search', auth, async (req, res) => {
  try {
    const { q } = req.query;
    
    if (!q || q.length < 2) {
      return res.json([]);
    }


    const user = await User.findById(req.user.userId);
    if (!user || !user.groupRank || user.groupRank.rankId < 244) {
      return res.status(403).json({ message: 'Insufficient permissions. Minimum rank ID 244 (Flight Dispatcher) required.' });
    }

    const searchRegex = new RegExp(q, 'i');
    
    const users = await User.find({
      $or: [
        { robloxUsername: searchRegex },
        { robloxId: q }
      ]
    })
    .select('robloxUsername robloxId robloxAvatarUrl groupRank')
    .limit(20)
    .sort('robloxUsername');

    res.json(users);

  } catch (error) {
    console.error('User search error:', error);
    res.status(500).json({ message: 'Failed to search users' });
  }
});

router.get('/leaderboard', auth, async (req, res) => {
  try {

    const users = await User.find({})
      .select('_id robloxId robloxUsername robloxDisplayName robloxAvatarUrl groupRank role stats lastLogin')
      .sort({ 'stats.termPay': -1 })
      .lean();
    
    res.json({ users });
    
  } catch (error) {
    console.error('Leaderboard fetch error:', error);
    res.status(500).json({ message: 'Failed to fetch leaderboard' });
  }
});

router.get('/:id', auth, async (req, res) => {
  try {
    const requestingUser = await User.findById(req.user.userId);
    const targetUser = await User.findById(req.params.id)
      .populate('rankHistory.promotedBy', 'robloxUsername')
      .populate('notes.addedBy', 'robloxUsername');
    
    if (!targetUser) {
      return res.status(404).json({ message: 'User not found' });
    }


    const canViewDetails = requestingUser.groupRank && requestingUser.groupRank.rankId >= 244;
    const canViewSensitive = requestingUser.groupRank && requestingUser.groupRank.rankId >= 247;


    const flightHistory = await Flight.find({
      'roles.assigned.user': targetUser._id,
      status: { $in: ['CONCLUDED', 'LOGGED'] }
    })
    .populate('dispatcher', 'robloxUsername')
    .populate('roles.assigned.assignedBy', 'robloxUsername')
    .sort('-scheduledDate')
    .limit(10);


    const upcomingFlights = await Flight.find({
      'roles.assigned.user': targetUser._id,
      scheduledDate: { $gte: new Date() },
      status: { $in: ['SCHEDULED', 'AVAILABLE', 'BRIEFING'] }
    })
    .populate('dispatcher', 'robloxUsername')
    .populate('roles.assigned.assignedBy', 'robloxUsername')
    .sort('scheduledDate')
    .limit(5);


    const flightHistoryWithRoles = flightHistory.map(flight => {
      const userRole = flight.roles.find(role => 
        role.assigned.some(assignment => 
          assignment.user.toString() === targetUser._id.toString()
        )
      );
      
      const userAssignment = userRole ? userRole.assigned.find(assignment => 
        assignment.user.toString() === targetUser._id.toString()
      ) : null;
      
      return {
        ...flight.toObject(),
        userRole: userRole ? userRole.name : 'Unknown',
        assignedBy: userAssignment ? userAssignment.assignedBy : null
      };
    });


    const upcomingFlightsWithRoles = upcomingFlights.map(flight => {
      const userRole = flight.roles.find(role => 
        role.assigned.some(assignment => 
          assignment.user.toString() === targetUser._id.toString()
        )
      );
      
      const userAssignment = userRole ? userRole.assigned.find(assignment => 
        assignment.user.toString() === targetUser._id.toString()
      ) : null;
      
      return {
        ...flight.toObject(),
        userRole: userRole ? userRole.name : 'Unknown',
        assignedBy: userAssignment ? userAssignment.assignedBy : null
      };
    });


    const response = {
      _id: targetUser._id,
      robloxId: targetUser.robloxId,
      robloxUsername: targetUser.robloxUsername,
      robloxDisplayName: targetUser.robloxDisplayName,
      robloxAvatarUrl: targetUser.robloxAvatarUrl,
      groupRank: targetUser.groupRank,
      role: targetUser.role,
      qualifications: targetUser.qualifications,
      stats: targetUser.stats,
      lastLogin: targetUser.lastLogin,
      isOnLeave: targetUser.isOnLeave,
      leaveDetails: targetUser.leaveDetails
    };


    if (canViewDetails) {
      response.rankHistory = targetUser.rankHistory;
      response.flightHistory = flightHistoryWithRoles;
      response.upcomingFlights = upcomingFlightsWithRoles;
      response.notes = targetUser.notes.filter(note => note.visibleToUser);
    }


    if (canViewSensitive) {
      response.sanctions = targetUser.sanctions;
      response.notes = targetUser.notes;
    }

    res.json(response);

  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch user' });
  }
});

router.get('/lookup/:identifier', auth, async (req, res) => {
  try {
    const { identifier } = req.params;
    

    const user = await User.findOne({
      $or: [
        { robloxUsername: new RegExp(`^${identifier}$`, 'i') },
        { robloxId: identifier }
      ]
    }).select('_id');
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({ userId: user._id });

  } catch (error) {
    console.error('User lookup error:', error);
    res.status(500).json({ message: 'Failed to lookup user' });
  }
});

module.exports = router; 