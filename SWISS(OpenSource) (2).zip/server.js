const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');

const compression = require('compression');
const morgan = require('morgan');
const cookieParser = require('cookie-parser');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const path = require('path');
require('dotenv').config();

const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const flightRoutes = require('./routes/flights');
const adminRoutes = require('./routes/admin');

const app = express();
const PORT = process.env.PORT || 5000;


app.set('trust proxy', 1);

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https://tr.rbxcdn.com", "https://www.roblox.com"],
      connectSrc: ["'self'", "https://api.roblox.com", "https://users.roblox.com", "https://groups.roblox.com"]
    }
  }
}));

app.use(compression());
app.use(morgan('combined'));
app.use(cors({
  origin: process.env.NODE_ENV === 'production' 
    ? process.env.FRONTEND_URL 
    : process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());

mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/swiss-airlines');

mongoose.connection.on('connected', () => {});

mongoose.connection.on('error', (err) => {
  console.error('MongoDB connection error:', err);
});

app.use(session({
  secret: process.env.SESSION_SECRET || 'swiss-airlines-secret-key',
  resave: false,
  saveUninitialized: false,
  store: MongoStore.create({
    mongoUrl: process.env.MONGODB_URI || 'mongodb://localhost:27017/swiss-airlines'
  }),
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000
  }
}));

app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/flights', flightRoutes);
app.use('/api/admin', adminRoutes);

if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, 'client/build')));
  
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'client/build', 'index.html'));
  });
}

app.use((err, req, res, next) => {
  res.status(500).json({ 
    message: 'Something went wrong!',
    error: process.env.NODE_ENV === 'development' ? err.message : 'Internal server error'
  });
});

app.listen(PORT, () => {});

const cron = require('node-cron');
const User = require('./models/User');

cron.schedule('0 2 1 * *', async () => {
  try {
    await User.updateMany(
      {},
      {
        $inc: {
          'stats.totalFlightsAttended': '$stats.termFlightsAttended',
          'stats.totalFlightsHosted': '$stats.termFlightsHosted'
        },
        $set: {
          'stats.termFlightsAttended': 0,
          'stats.termFlightsHosted': 0,
          'stats.termPay': 0
        }
      }
    );
  } catch (error) {
    console.error('Error during monthly reset:', error);
  }
}, {
  timezone: "UTC"
});

module.exports = app; 