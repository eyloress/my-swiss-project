const mongoose = require('mongoose');

const sanctionSchema = new mongoose.Schema({
  type: {
    type: String,
    enum: ['reminder', 'warning', 'suspension'],
    required: true
  },
  count: {
    type: Number,
    required: true
  },
  breach: {
    type: String,
    required: true
  },
  reason: {
    type: String,
    required: true
  },
  comment: String,
  issuer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  issuerUsername: String,
  issuedDate: {
    type: Date,
    default: Date.now
  },
  expiryDate: {
    type: Date,
    required: true
  },
  activeUntil: Date
});

const qualificationSchema = new mongoose.Schema({
  name: {
    type: String,
    enum: [
      'Ground Services Licence',
      'Cabin Crew Licence',
      'First Officer Licence',
      'Captain License',
      'Tarmac Supervisor Licence',
      'Maître de Cabine Licence',
      'Administrative Division',
      'Operations Division',
      'Network Division'
    ],
    required: true
  },
  grantedDate: {
    type: Date,
    default: Date.now
  },
  grantedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
});

const rankHistorySchema = new mongoose.Schema({
  rankId: Number,
  rankName: String,
  date: {
    type: Date,
    default: Date.now
  },
  promotedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  type: {
    type: String,
    enum: ['promotion', 'demotion', 'qualification'],
    default: 'promotion'
  }
});

const noteSchema = new mongoose.Schema({
  content: {
    type: String,
    required: true
  },
  addedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  addedDate: {
    type: Date,
    default: Date.now
  },
  visibleToUser: {
    type: Boolean,
    default: false
  },
  type: {
    type: String,
    enum: ['general', 'loa', 'performance'],
    default: 'general'
  }
});

const rewardSchema = new mongoose.Schema({
  amount: {
    type: Number,
    required: true
  },
  reason: {
    type: String,
    required: true
  },
  type: {
    type: String,
    enum: ['bonus', 'commission', 'incentive'],
    default: 'bonus'
  },
  awardedBy: {
    type: String,
    required: true
  },
  awardedDate: {
    type: Date,
    default: Date.now
  }
});

const userSchema = new mongoose.Schema({
  robloxId: {
    type: String,
    required: true,
    unique: true
  },
  robloxUsername: {
    type: String,
    required: true
  },
  robloxDisplayName: String,
  robloxAvatarUrl: String,
  groupRank: {
    rankId: Number,
    rankName: String,
    lastUpdated: {
      type: Date,
      default: Date.now
    }
  },
  role: {
    type: String,
    enum: ['Personnel', 'Flight Dispatcher', 'Corporate Board', 'Management Board'],
    default: 'Personnel'
  },
  qualifications: [qualificationSchema],
  stats: {
    requiredFlights: {
      type: Number,
      default: 2
    },
    termFlightsAttended: {
      type: Number,
      default: 0
    },
    termFlightsHosted: {
      type: Number,
      default: 0
    },
    termPay: {
      type: Number,
      default: 0
    },
    totalFlightsAttended: {
      type: Number,
      default: 0
    },
    totalFlightsHosted: {
      type: Number,
      default: 0
    }
  },
  sanctions: [sanctionSchema],
  rankHistory: [rankHistorySchema],
  notes: [noteSchema],
  rewards: [rewardSchema],
  isOnLeave: {
    type: Boolean,
    default: false
  },
  leaveDetails: {
    startDate: Date,
    endDate: Date,
    reason: String,
    approvedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    }
  },
  lastLogin: {
    type: Date,
    default: Date.now
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

userSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

userSchema.methods.getRole = function() {
  const rankId = this.groupRank.rankId;
  if (rankId >= 249) return 'Management Board';
  if (rankId >= 247) return 'Corporate Board';
  if (rankId >= 244) return 'Flight Dispatcher';
  if (rankId >= 239) return 'Personnel';
  return null;
};

userSchema.methods.hasPermission = function(requiredRole) {
  const roleHierarchy = {
    'Personnel': 1,
    'Flight Dispatcher': 2,
    'Corporate Board': 3,
    'Management Board': 4
  };
  
  const userLevel = roleHierarchy[this.role] || 0;
  const requiredLevel = roleHierarchy[requiredRole] || 0;
  
  return userLevel >= requiredLevel;
};

userSchema.methods.getActiveSanctions = function() {
  const now = new Date();
  return this.sanctions.filter(sanction => sanction.expiryDate > now);
};

userSchema.methods.hasQualification = function(qualificationName) {
  return this.qualifications.some(qual => qual.name === qualificationName);
};

module.exports = mongoose.model('User', userSchema); 