const mongoose = require('mongoose');

const roleSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  capacity: {
    type: Number,
    required: true,
    min: 1
  },
  assigned: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    username: String,
    assignedAt: {
      type: Date,
      default: Date.now
    },
    assignedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    }
  }]
});

const logEntrySchema = new mongoose.Schema({
  action: {
    type: String,
    required: true
  },
  performedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  performedByUsername: String,
  timestamp: {
    type: Date,
    default: Date.now
  },
  details: String
});

const flightSchema = new mongoose.Schema({
  flightCode: {
    type: String,
    required: true,
    unique: true
  },
  route: {
    departure: {
      type: String,
      required: true
    },
    arrival: {
      type: String,
      required: true
    }
  },
  aircraft: {
    type: String,
    required: true
  },
  gate: String,
  scheduledDate: {
    type: Date,
    required: true
  },
  times: {
    staffJoining: {
      type: Date,
      required: true
    },
    passengerJoining: {
      type: Date,
      required: true
    },
    boarding: {
      type: Date,
      required: true
    }
  },
  serviceCategory: String,
  notes: String,
  status: {
    type: String,
    enum: ['SCHEDULED', 'AVAILABLE', 'BRIEFING', 'IN PROGRESS', 'CONCLUDED', 'CANCELLED', 'LOGGED'],
    default: 'SCHEDULED'
  },
  approvalStatus: {
    type: String,
    enum: ['pending', 'approved', 'rejected'],
    default: 'pending'
  },
  dispatcher: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  dispatcherUsername: String,
  roles: [roleSchema],
  logs: [logEntrySchema],
  points: {
    attended: {
      type: Number,
      default: 1
    },
    hosted: {
      type: Number,
      default: 2
    }
  },
  pay: {
    base: {
      type: Number,
      default: 100
    },
    bonus: {
      type: Number,
      default: 0
    }
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  },
  approvedAt: Date,
  approvedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  concludedAt: Date,
  reviewedAt: Date,
  reviewedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
});

flightSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

flightSchema.methods.addLog = function(action, performedBy, performedByUsername, details = '') {
  this.logs.push({
    action,
    performedBy,
    performedByUsername,
    details,
    timestamp: new Date()
  });
};

flightSchema.methods.getTotalSlots = function() {
  return this.roles.reduce((total, role) => total + role.capacity, 0);
};

flightSchema.methods.getAssignedSlots = function() {
  return this.roles.reduce((total, role) => total + role.assigned.length, 0);
};

flightSchema.methods.isUserAssigned = function(userId) {
  return this.roles.some(role => 
    role.assigned.some(assignment => 
      assignment.user.toString() === userId.toString()
    )
  );
};

flightSchema.methods.canUserAllocate = function(userId, roleIndex) {
  if (this.isUserAssigned(userId)) return false;
  if (roleIndex >= this.roles.length) return false;
  
  const role = this.roles[roleIndex];
  return role.assigned.length < role.capacity;
};

flightSchema.methods.allocateUser = function(userId, username, roleIndex, assignedBy, assignedByUsername) {
  if (!this.canUserAllocate(userId, roleIndex)) {
    throw new Error('Cannot allocate user to this role');
  }
  
  this.roles[roleIndex].assigned.push({
    user: userId,
    username,
    assignedAt: new Date(),
    assignedBy
  });
  
  this.addLog(
    `User allocated to ${this.roles[roleIndex].name}`,
    assignedBy,
    assignedByUsername,
    `${username} assigned to ${this.roles[roleIndex].name}`
  );
};

flightSchema.methods.removeUserFromRole = function(userId, roleIndex, removedBy, removedByUsername) {
  if (roleIndex >= this.roles.length) return false;
  
  const role = this.roles[roleIndex];
  const assignmentIndex = role.assigned.findIndex(
    assignment => assignment.user.toString() === userId.toString()
  );
  
  if (assignmentIndex === -1) return false;
  
  const removedUser = role.assigned[assignmentIndex];
  role.assigned.splice(assignmentIndex, 1);
  
  this.addLog(
    `User removed from ${role.name}`,
    removedBy,
    removedByUsername,
    `${removedUser.username} removed from ${role.name}`
  );
  
  return true;
};

flightSchema.methods.updateStatus = function(newStatus, updatedBy, updatedByUsername) {
  const oldStatus = this.status;
  this.status = newStatus;
  
  this.addLog(
    'Status updated',
    updatedBy,
    updatedByUsername,
    `Status changed from ${oldStatus} to ${newStatus}`
  );
  
  if (newStatus === 'CONCLUDED') {
    this.concludedAt = new Date();
  }
};

flightSchema.methods.getDayOfWeek = function() {
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  return days[this.scheduledDate.getDay()];
};

flightSchema.statics.getFlightsByWeek = function(startDate) {
  const endDate = new Date(startDate);
  endDate.setDate(endDate.getDate() + 7);
  
  return this.find({
    scheduledDate: {
      $gte: startDate,
      $lt: endDate
    },
    approvalStatus: 'approved'
  }).populate('dispatcher', 'robloxUsername').sort('scheduledDate');
};

module.exports = mongoose.model('Flight', flightSchema); 