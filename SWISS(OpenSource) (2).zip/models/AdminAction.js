const mongoose = require('mongoose');

const adminActionSchema = new mongoose.Schema({
  actionType: {
    type: String,
    required: true,
    enum: ['sanction_add', 'sanction_delete', 'qualification_add', 'qualification_delete', 'note_add', 'reward_add', 'quota_update', 'term_advance']
  },
  performedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  performedByUsername: {
    type: String,
    required: true
  },
  targetUser: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  targetUsername: {
    type: String
  },
  details: {
    type: mongoose.Schema.Types.Mixed,
    required: true
  },
  timestamp: {
    type: Date,
    default: Date.now
  }
});

adminActionSchema.index({ timestamp: -1 });
adminActionSchema.index({ performedBy: 1 });
adminActionSchema.index({ targetUser: 1 });

module.exports = mongoose.model('AdminAction', adminActionSchema); 